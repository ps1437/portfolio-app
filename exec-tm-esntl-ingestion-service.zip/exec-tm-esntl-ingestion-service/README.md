![master](https://github.com/JDA-Product-Development/exec-tm-esntl-ingestion-service/workflows/master/badge.svg) ![Performance Tests](https://github.com/JDA-Product-Development/exec-tm-esntl-ingestion-service/workflows/Performance%20Tests%20(Staging)/badge.svg)
[![Codacy Badge](https://app.codacy.com/project/badge/Grade/18cb24631a414edc925a2c10c33c94e8)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=JDA-Product-Development/exec-tm-esntl-ingestion-service&amp;utm_campaign=Badge_Grade)
[![Codacy Badge](https://app.codacy.com/project/badge/Coverage/18cb24631a414edc925a2c10c33c94e8)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=JDA-Product-Development/exec-tm-esntl-ingestion-service&amp;utm_campaign=Badge_Coverage)

# exec-tm-esntl-ingestion-service

## Table of Contents

-   [Overview](#overview)
-   [Artifactory Requirements](#artifactory)
-   [IDE Requirements](#ide-requirements)
-   [Building](#building)
-   [Run Check](#runcheck)
-   [Running Service](#running)
-   [Data platform Communication](#apis)

<a name="overview"></a>
## Overview
This is an ETMS ingestion service which is used to bulk-ingest the data to Data Platform.

<a name="artifactory"></a>
## Artifactory Requirements

JFrog [artifactory](https://jdasoftware.jfrog.io/artifactory/libs-release-local/com/blueyonder/exec/tm/esntl/) server
requires authentication to consume artifacts.  Therefore, developers must configure local credentials to artifactory for
gradle to use. See the [Onboarding Doc](https://teams.microsoft.com/l/entity/com.microsoft.teamspace.tab.wiki/tab::0dc5dc2b-7ded-4f9d-b649-e9c61b0e03cd?context=%7B%22subEntityId%22%3A%22%7B%5C%22pageId%5C%22%3A21%2C%5C%22sectionId%5C%22%3A23%2C%5C%22origin%5C%22%3A2%7D%22%2C%22channelId%22%3A%2219%3A8cc65fc7b6434aadb44c099ffd5fb422%40thread.tacv2%22%7D&tenantId=2ac36cee-0617-4ac0-bebf-e1ce5dfab86c) for details.

<a name="ide-requirements"></a>
## IDE Requirements

This project uses [Lombok](https://projectlombok.org/) to automatically generate boilerplate such as POJO getters + setters. Lombok uses Annotation Processing, which
requires some [IntelliJ configuration](https://www.baeldung.com/lombok-ide).

<a name="building"></a>
## Building

This project uses gradle wrapper to prevent users from having to install gradle at a global level.  Make sure you use `gradlew` for execution calls _not_ `gradle`.  This also ensures that the same versions of the tooling are being used across deployments.

To build the project execute the following from the project root:

```shell
./gradlew build
```

<a name="runcheck"></a>
## Run check

Simply run:

```shell
./gradlew clean check.
```

The integration tests relies on docker being installed in your machine to startup a mssql container and runs the test in `dev-sql` profile.
If docker is not installed, the integration tests can be run against an H2 database by changing `integrationTestProfile` to `dev` in [gradle.properties](./gradle.properties) file or by running:
```shell
./gradlew clean check -PintegrationTestProfile=dev
```

<a name="running"></a>
## Running the service

The distribution service is a spring boot app and can be started using gradlew.

```shell
./gradlew bootrun
```

The default app location is `localhost:8080`.

If communication with Data Platform is required then we'll need to include an Authorization bearer token with requests.
The easiest way to get one is from the API Developer portal:
-   Navigate to https://apideveloper-tst.jdadelivers.com.  Open any API and click Try It.
-   Change the LIAM authentication from `No auth` to `implicit`.
-   Copy the bearer token from the sample HTTP request and add to your Postman request.

<a name="apis"></a>
## Data Platform Communication

Once deployed to staging/sandbox, this service relies upon the internal API Gateway endpoint to communicate with data platform.  End user uploads a CSV file with data
(normally through an MFE) which is consumed by this service will enter Azure through the public API Gateway, which requires authentication through
LIAM. Once authenticated, API Gateway forwards the request to this service while including an [identity context header](https://github.com/JDA-Product-Development/plat-apim-api-registry/blob/master/docs/IDENTITY-CONTEXT.md")
that identifies the user that made the request. This header is propagated on all outgoing requests initiated by this service to effectively
impersonate the original user making the request.

This method of communication does not work when running locally as the internal API Gateway endpoint is only accessible from resources
deployed in the same Azure VNET as APIM.  Instead, the dev profile uses the public API Gateway endpoint to communicate with data platform.  
This means that you must supply a LIAM token to authenticate with Gateway.  If using Postman for dev testing, see the instructions in the
[#development Teams wiki](https://teams.microsoft.com/l/entity/com.microsoft.teamspace.tab.wiki/tab::b096ae1d-76f5-4ebe-a694-985277685d1d?context=%7B%22subEntityId%22%3A%22%7B%5C%22pageId%5C%22%3A55%2C%5C%22sectionId%5C%22%3A57%2C%5C%22origin%5C%22%3A2%7D%22%2C%22channelId%22%3A%2219%3Ab138afbf7ce24e899efe413cd6f15747%40thread.tacv2%22%7D&tenantId=2ac36cee-0617-4ac0-bebf-e1ce5dfab86c).
If using GraphiQL, you can install a browser extension to include the Authentication header on your requests. If using this method, you'll
need to retrieve the LIAM token yourself to supply it to the extension.

NOTE: If you supply a LIAM token in the Authorization header, the BFF will NOT create an identity context from this token.  If a different
service requires an identity context on incoming requests, you will still need to supply this header, too.
