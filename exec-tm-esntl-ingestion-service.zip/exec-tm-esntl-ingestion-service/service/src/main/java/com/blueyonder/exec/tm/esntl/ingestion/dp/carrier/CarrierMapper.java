/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.exec.tm.esntl.ingestion.dp.CommunicationChannelUtils;
import com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationType;
import com.blueyonder.plat.dp.bydm.CarrierDetailsCharacteristicsType;
import com.blueyonder.plat.dp.bydm.FinancialDetails;
import com.blueyonder.plat.dp.bydm.PartyContactType;
import com.blueyonder.plat.dp.bydm.PartyRoleCode;
import com.blueyonder.plat.dp.bydm.PartyType;
import com.blueyonder.plat.dp.bydm.SegmentActionEnumerationType;
import com.blueyonder.plat.dp.bydm.ServiceDetailsType;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;

@Mapper(componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = PartyRoleCode.class
)
public interface CarrierMapper {

    @Mapping(source = "carrierId", target = "partyId")
    @Mapping(source = "carrierName", target = "basicParty.partyName")
    @Mapping(source = ".", target = "basicParty.additionalPartyId", qualifiedByName = "toAdditionalPartyId")
    @Mapping(expression = "java(null)", target = "avpList")
    @Mapping(source = "countryCode", target = "basicParty.partyAddress.countryCode")
    @Mapping(source = "state", target = "basicParty.partyAddress.state")
    @Mapping(source = "city", target = "basicParty.partyAddress.city")
    @Mapping(source = "streetAddressOne", target = "basicParty.partyAddress.streetAddressOne")
    @Mapping(source = "streetAddressTwo", target = "basicParty.partyAddress.streetAddressTwo")
    @Mapping(source = "streetAddressThree", target = "basicParty.partyAddress.streetAddressThree")
    @Mapping(source = "postalCode", target = "basicParty.partyAddress.postalCode")
    @Mapping(target = "basicParty.partyRole", expression = "java(PartyRoleCode.CARRIER)")
    @Mapping(source = ".", target = "basicParty.partyContact", qualifiedByName = "toContactModel")
    @Mapping(source = ".", target = "basicParty.financialInformation", qualifiedByName = "toFinancialInformation")
    @Mapping(source = ".", target = "carrierDetails.serviceDetails", qualifiedByName = "toServiceDetails")
    @Mapping(source = "currencyCode", target = "basicParty.partyAddress.currencyOfPartyCode")
    @Mapping(source = "pickupLeadTimeHrs", target = "carrierDetails.minimumPickUpTime")
    @Mapping(source = "tenderResponseTimeHrs", target = "carrierDetails.tenderResponseTime")
    PartyType mapToPartyType(CarrierEntity carrier);

    List<PartyType> mapToPartyTypes(List<CarrierEntity> carriers);

    @Named("toContactModel")
    default List<PartyContactType> mapCommunicationChannel(CarrierEntity carrier) {
        if (StringUtils.isAllEmpty(carrier.getEmail(), carrier.getTelefax(), carrier.getTelephone(), carrier.getPersonName(), carrier.getWebsite())) {
            return Collections.emptyList();
        }
        return CommunicationChannelUtils.getPartyContactTypes(carrier.getEmail(), carrier.getWebsite(), carrier.getTelephone(), carrier.getTelefax(), carrier.getPersonName());
    }

    @Named("toAdditionalPartyId")
    default List<AdditionalPartyIdentificationType> mapToAdditionalPartyId(CarrierEntity carrier) {
        if (Objects.nonNull(carrier)) {
            return CommunicationChannelUtils.getAdditionalPartyIdentificationTypes(carrier);
        }
        return Collections.emptyList();
    }

    @Named("toFinancialInformation")
    default FinancialDetails mapToFinancialInformation(CarrierEntity carrier) {
        if (StringUtils.isBlank(carrier.getApAccountNumber()) && StringUtils.isBlank(carrier.getArAccountNumber())) {
            return null;
        }
        FinancialDetails financialDetails = new FinancialDetails();
        financialDetails.withAccountNumberPayable(carrier.getApAccountNumber());
        financialDetails.withAccountNumberReceivable(carrier.getArAccountNumber());
        return financialDetails;
    }

    @Named("toServiceDetails")
    default List<ServiceDetailsType> mapToServiceDetails(CarrierEntity carrier) {
        if (Objects.nonNull(carrier.getCarrierService()) && !CollectionUtils.isEmpty(carrier.getCarrierService().getServiceDetails())) {
            return carrier.getCarrierService().getServiceDetails().stream()
                    .map(e -> {
                        ServiceDetailsType serviceDetails = new ServiceDetailsType();
                        serviceDetails.setActionCode(SegmentActionEnumerationType.ADD);
                        serviceDetails.setServiceLevelCode(e.getServiceLevelCode().getValue());
                        serviceDetails.setCarrierType(e.getCarrierType());
                        serviceDetails.setCharacteristics(mapToCarrierCharacteristics(e.getCarrierDetailsCharacteristics()));
                        serviceDetails.setAvpList(null);
                        return serviceDetails;
                    }).toList();
        }
        return Collections.emptyList();
    }

    CarrierDetailsCharacteristicsType mapToCarrierCharacteristics(CarrierDetailsCharacteristics carrierDetailsCharacteristics);

}
