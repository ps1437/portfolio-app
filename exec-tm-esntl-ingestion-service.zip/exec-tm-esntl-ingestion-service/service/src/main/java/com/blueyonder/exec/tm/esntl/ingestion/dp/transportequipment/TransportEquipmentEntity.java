/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

import javax.persistence.Id;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;
import com.blueyonder.plat.dp.bydm.EquipmentCategoryCodeEnumerationType;

@Getter
@Setter
@ToString
@Entity(name = "Transport Equipment")
public class TransportEquipmentEntity extends IngestionEntity {

    @Id
    @Column(name = "TRANSPORT_EQUIPMENT_ID")
    private String transportEquipmentId;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "LENGTH")
    private Double length;

    @Column(name = "WIDTH")
    private Double width;

    @Column(name = "HEIGHT")
    private Double height;

    @Column(name = "TARE_WEIGHT")
    private Double tareWeight;

    @Column(name = "MAX_LOADING_LENGTH")
    private Double maximumLoadingLength;

    @Column(name = "MAX_LOADING_HEIGHT")
    private Double maximumLoadingHeight;

    @Column(name = "MAX_LOADING_WIDTH")
    private Double maximumLoadingWidth;

    @Column(name = "MAX_LOADING_WEIGHT")
    private Double maximumLoadingWeight;

    @Column(name = "EQUIPMENT_CATEGORY")
    private EquipmentCategoryCodeEnumerationType equipmentCategory;

    @Column(name = "LOADING_TIME")
    private Double loadingDurationInHours;

    @Column(name = "UNLOADING_TIME")
    private Double unloadingDurationInHours;

    @OneToMany(joinColumnName = "TRANSPORT_EQUIPMENT_ID")
    private List<CommodityRestrictionEntity> commodityRestrictions;
}
