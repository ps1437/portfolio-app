/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.blueyonder.exec.ecom.boot.commons.web.error.BadRequestAppException;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileStorageService;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionProcessor {

    private final FileStorageService fileStorageService;

    private final IngestionFactory ingestionFactory;

    private final IngestionSourceFactory ingestionSourceFactory;

    private final IngestionEntityManager ingestionEntityManager;

    public void process(IngestionRequestEntity ingestionRequestEntity) {
        var filename = ingestionRequestEntity.getFileName();
        try {
            var ingestionService = ingestionFactory.getIngestionService(ingestionRequestEntity.getEntityType());
            var reader = ingestionSourceFactory.newIngestionRequestReader(filename, ingestionService);
            var inputStream = fileStorageService.downloadFile(ingestionRequestEntity.getFileId());
            var ingestionRequest = reader.read(inputStream);
            if (ingestionRequest.isEmpty()) {
                log.debug("Empty ingestion request {filename={}}", filename);
                throw new BadRequestAppException(false, "ltms.ingestion.invalidFile", "Invalid ingestion file " + filename);
            }
            ingestionRequest.setRequestId(ingestionRequestEntity.getRequestId());
            ingestionEntityManager.updateStatus(ingestionRequestEntity.getRequestId(), IngestionStatus.PROCESSING);
            ingestionService.ingest(ingestionRequest);
        }
        catch (IOException e) {
            log.error("Failed read ingestion request {filename={}}", filename, e);
            throw new BadRequestAppException(false, "ltms.ingestion.invalidFile", "Invalid ingestion file " + filename, e);
        }
    }

}
