/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import java.util.List;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.springframework.util.CollectionUtils;

import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.LocationType;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.EMAIL;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.TELEFAX;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.TELEPHONE;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.WEBSITE;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public abstract class ShipmentOriginLocationMapper {

    @Mapping(source = "basicLocation.locationName", target = "originLocationName")
    @Mapping(source = "basicLocation.address.countryCode", target = "originCountryCode")
    @Mapping(source = "basicLocation.address.state", target = "originState")
    @Mapping(source = "basicLocation.address.city", target = "originCity")
    @Mapping(source = "basicLocation.address.streetAddressOne", target = "originStreetAddressOne")
    @Mapping(source = "basicLocation.address.streetAddressTwo", target = "originStreetAddressTwo")
    @Mapping(source = "basicLocation.address.streetAddressThree", target = "originStreetAddressThree")
    @Mapping(source = "basicLocation.address.postalCode", target = "originPostalCode")
    @Mapping(source = "basicLocation.address.geographicalCoordinates.latitude", target = "originLatitude")
    @Mapping(source = "basicLocation.address.geographicalCoordinates.longitude", target = "originLongitude")
    public abstract void mapToOriginLocation(LocationType locationType, @MappingTarget ShipmentEntity shipment);

    @AfterMapping
    protected void mapShipToContact(LocationType locationType, @MappingTarget ShipmentEntity shipment) {
        LocationContactType shipToContact = !CollectionUtils.isEmpty(locationType.getBasicLocation().getContact()) ? locationType.getBasicLocation().getContact().get(0) : new LocationContactType();
        if (shipToContact != null) {
            List<CommunicationChannelType> communicationChannels = shipToContact.getCommunicationChannel();
            for (CommunicationChannelType channelType : communicationChannels) {
                if (channelType.getCommunicationChannelCode().value().equals(EMAIL)) {
                    shipment.setOriginEmail(channelType.getCommunicationValue());
                }
                else if (channelType.getCommunicationChannelCode().value().equals(TELEPHONE)) {
                    shipment.setOriginTelephone(channelType.getCommunicationValue());
                }
                else if (channelType.getCommunicationChannelCode().value().equals(TELEFAX)) {
                    shipment.setOriginTelefax(channelType.getCommunicationValue());
                }
                else if (channelType.getCommunicationChannelCode().value().equals(WEBSITE)) {
                    shipment.setOriginWebsite(channelType.getCommunicationValue());
                }
            }
            shipment.setOriginCompanyName(shipToContact.getCompanyName());
            shipment.setOriginContactName(shipToContact.getPersonName());
        }
    }
}
