/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import lombok.Getter;
import lombok.ToString;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntityMetadata;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.validation.EntityValidator.validate;
import static java.util.Objects.requireNonNull;
import static org.apache.commons.lang3.StringUtils.substringBefore;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

@Getter
@ToString
public class IngestionRequestEntityDef {

    private final IngestionEntityDef entityDef;

    // Key is actual header names of request page.
    // Value can be null if corresponding column definition is not found.
    private final Map<String, IngestionEntityColumnDef> requestColumnDefs = new LinkedHashMap<>();

    public IngestionRequestEntityDef(IngestionEntityDef entityDef) {
        this.entityDef = requireNonNull(entityDef);
    }

    public IngestionRequestEntityDef(IngestionEntityDef entityDef, boolean copyColumnDefs) {
        this.entityDef = requireNonNull(entityDef);
        if (copyColumnDefs) {
            this.requestColumnDefs.putAll(entityDef.getColumnDefs());
        }
    }

    public void addColumnDef(String columnName) {
        String s = trimToEmpty(columnName).replace('\n', ' ');

        IngestionEntityColumnDef columnDef = null;
        if (!requestColumnDefs.containsKey(s)) {
            // * is used to denote mandatory column
            // Extra hints, etc. is written inside brackets.
            String normalizedColumnName = substringBefore(substringBefore(s, '('), '*').trim();
            columnDef = entityDef.getColumnDef(normalizedColumnName);
        }

        if (null == columnDef) {
            s += "(INVALID_" + requestColumnDefs.size() + ")";
        }

        requestColumnDefs.put(s, columnDef);
    }

    public String getName() {
        return entityDef.getName();
    }

    public boolean isValid() {
        for (var o : requestColumnDefs.values()) {
            if (null != o) {
                return true;
            }
        }
        return false;
    }

    public <T extends IngestionEntity> T createEntity(List<String> row) {
        boolean containsData = false;
        T entity = entityDef.createEntity();
        IngestionEntityMetadata metadata = entity.getMetadata();

        Iterator<IngestionEntityColumnDef> itr = requestColumnDefs.values().iterator();
        for (int i = 0, n = row.size(); i < n && itr.hasNext(); ++i) {
            IngestionEntityColumnDef columnDef = itr.next();
            if (null == columnDef) {
                continue;
            }

            String value = trimToNull(row.get(i));
            if (null != value) {
                containsData = true;
                try {
                    columnDef.setColumnValue(entity, value);
                }
                catch (Exception ex) {
                    metadata.addErrorMessage(ex.getMessage());
                }
            }

            // TODO: Use javax validation and validate once entity fully constructed.
            //  Also, move this code from here to caller class
            metadata.addErrorMessages(validate(getName(), columnDef.getFieldName(), value));
        }

        return containsData ? entity : null;
    }
}
