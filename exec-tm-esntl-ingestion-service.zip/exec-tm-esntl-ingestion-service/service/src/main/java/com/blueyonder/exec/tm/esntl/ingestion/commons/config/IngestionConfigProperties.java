/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.config;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@EnableConfigurationProperties({ IngestionConfigProperties.class})
@ConfigurationProperties("ingestion")
public class IngestionConfigProperties {

    private BatchConfig batchConfig;

    private IngestionEventConfig eventConfig;

    @Getter
    @Setter
    public static class BatchConfig {

        private Integer noOfBatches;

        private Integer batchSize;

    }

    @Getter
    @Setter
    public static class IngestionEventConfig {

        private String eventName;

        private String topicName;

    }

}
