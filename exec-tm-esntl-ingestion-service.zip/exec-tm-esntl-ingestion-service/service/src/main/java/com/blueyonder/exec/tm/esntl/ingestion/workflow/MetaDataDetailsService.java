/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Objects;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.DataIngestionDetailsMapper;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageDataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryPaginationModel;
import com.blueyonder.exec.tm.esntl.ingestion.dp.PageDataIngestionDetailsModelMapper;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.DataIngestSpecification;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionMetadataRepository;

@Service
@RequiredArgsConstructor
public class MetaDataDetailsService {

    static final int DEFAULT_LIMIT = 10;

    static final int DEFAULT_PAGE = 0;

    private final IngestionMetadataRepository ingestionMetadataRepository;

    public PageDataIngestionDetailsModel queryIngestionMetaData(QueryModel query) {
        DataIngestSpecification specification = new DataIngestSpecification();
        Pageable pageable = withPageable(query.getPagination());
        query.getFilter().forEach(specification::add);

        Page<DataIngestionDetails> pageDataIngestionDetails = ingestionMetadataRepository.findAll(specification, pageable);
        List<DataIngestionDetailsModel> dataIngestionDetailsModels = pageDataIngestionDetails.get().map(DataIngestionDetailsMapper::mapToDataIngestModelDetails).toList();
        PageDataIngestionDetailsModel pageDataIngestionDetailsModel = PageDataIngestionDetailsModelMapper.mapToPageDataIngestionDetailsModel(pageable, pageDataIngestionDetails);
        pageDataIngestionDetailsModel.setContent(dataIngestionDetailsModels);
        return pageDataIngestionDetailsModel;
    }

    private Pageable withPageable(QueryPaginationModel pagination) {
        if (Objects.nonNull(pagination)) {
            return PageRequest.of(pagination.getOffset(), pagination.getLimit(), Sort.by("startDateTime").descending());
        }
        return PageRequest.of(DEFAULT_PAGE, DEFAULT_LIMIT);
    }

    public List<DataIngestionDetailsModel> loadAllIngestionMetaData() {
        return ingestionMetadataRepository.findAll(Sort.by(Sort.Direction.DESC, "startDateTime"))
                .stream()
                .map(DataIngestionDetailsMapper::mapToDataIngestModelDetails)
                .toList();
    }
}
