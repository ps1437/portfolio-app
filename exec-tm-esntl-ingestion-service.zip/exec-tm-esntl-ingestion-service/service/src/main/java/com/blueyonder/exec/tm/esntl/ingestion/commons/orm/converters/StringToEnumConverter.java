/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import java.util.Locale;

import static java.util.Objects.requireNonNull;

@SuppressWarnings("rawtypes")
class StringToEnumConverter<T extends Enum> implements DataConverter<T> {

    private final Class<T> type;

    StringToEnumConverter(Class<T> type) {
        this.type = requireNonNull(type);
    }

    @SuppressWarnings("unchecked")
    @Override
    public T convert(String value) {
        try {
            return (T) Enum.valueOf(type, value);
        }
        catch (IllegalArgumentException e1) {
            // See if same enumeration is available with uppercase.
            // Some flexibility for user input by assuming that same word is not used
            // in different cases to declare enumerations.
            var s = value.toUpperCase(Locale.getDefault());
            if (s.equals(value)) {
                throw e1;
            }
            try {
                return (T) Enum.valueOf(type, s);
            }
            catch (IllegalArgumentException e2) {
                throw e1;
            }
        }
    }
}
