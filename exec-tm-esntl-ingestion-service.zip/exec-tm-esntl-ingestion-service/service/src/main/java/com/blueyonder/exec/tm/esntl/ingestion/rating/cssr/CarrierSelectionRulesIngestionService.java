/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating.cssr;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.List;

import org.springframework.stereotype.Service;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceImpl;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.TenancyContextUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.rating.CssrIngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.rating.RatingClient;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionEntityManager;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.CarrierSelectionRulesModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.SelectionRulesModel;

import static java.util.Objects.requireNonNull;

@Slf4j
@Service
public class CarrierSelectionRulesIngestionService extends IngestionServiceImpl {

    private static final IngestionEntityDef CSSR = new IngestionEntityDef(CarrierSelectionRulesEntity.class);

    private static final IngestionEntitySchema ENTITY_SCHEMA = IngestionEntitySchema.of(CSSR);

    private final RatingClient ratingClient;

    private final DataStorageService dataStorageService;

    private final PostIngestionService postIngestionService;

    private final CarrierSelectionRulesMapper carrierSelectionRulesMapper;

    private final IngestionEntityManager ingestionEntityManager;

    public CarrierSelectionRulesIngestionService(RatingClient ratingClient,
            DataStorageService dataStorageService,
            PostIngestionService postIngestionService,
            CarrierSelectionRulesMapper carrierSelectionRulesMapper,
            IngestionEntityManager ingestionEntityManager) {
        this.ratingClient = requireNonNull(ratingClient);
        this.dataStorageService = requireNonNull(dataStorageService);
        this.postIngestionService = requireNonNull(postIngestionService);
        this.carrierSelectionRulesMapper = requireNonNull(carrierSelectionRulesMapper);
        this.ingestionEntityManager = requireNonNull(ingestionEntityManager);
    }

    @Override
    public IngestionType getType() {
        return IngestionType.CARRIER_SERVICES_SELECTION_RULES;
    }

    @Override
    public IngestionEntitySchema getEntitySchema() {
        return ENTITY_SCHEMA;
    }

    @Override
    protected DataIngestionDetails ingest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
        List<CarrierSelectionRulesEntity> validServiceSelectionRules = rootEntityPage.getValidEntities();
        log.info("Request to ingest service selection rules of size {}", validServiceSelectionRules.size());

        DataIngestionDetails dataIngestionDetails = dataStorageService.saveFileDetails(ingestionRequest.getSourceName(), getType().name());
        List<SelectionRulesModel> selectionRulesModels = carrierSelectionRulesMapper.mapToSelectionRulesModels(validServiceSelectionRules);

        ingestionEntityManager.updateStatus(ingestionRequest.getRequestId(), IngestionStatus.PROCESSING, selectionRulesModels.size());

        processCarrierServiceSelectionRules(ingestionRequest, selectionRulesModels);

        return dataIngestionDetails;
    }

    private void processCarrierServiceSelectionRules(IngestionRequest ingestionRequest, List<SelectionRulesModel> models) {
        if (!models.isEmpty()) {
            CarrierSelectionRulesModel carrierServiceRulesModel = new CarrierSelectionRulesModel();
            carrierServiceRulesModel.setCarrierServiceRules(models);
            TenancyContextUtils.runWithContext(ratingClient.createCarrierServicesSelectionRules(Mono.just(carrierServiceRulesModel)))
                    .doOnError(error -> {
                        log.error("error encountered while uploading to ratingservice", error);
                        dataStorageService.updateErrorFileDetails(ingestionRequest.getRequestId(),
                                IngestionStatus.FAILED,
                                ingestionRequest.getEntities(CSSR.getName()).size());
                    })
                    .subscribe(response -> postIngestionService.processIngestion(
                            new CssrIngestionResponse(ingestionRequest, response.getBody())));
        }
        else {
            postIngestionService.processIngestion(new IngestionResponse(ingestionRequest));
        }
    }
}
