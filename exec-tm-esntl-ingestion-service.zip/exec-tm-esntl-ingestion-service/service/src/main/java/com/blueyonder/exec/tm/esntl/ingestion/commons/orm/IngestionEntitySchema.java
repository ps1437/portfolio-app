/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;

@Getter
@ToString
public class IngestionEntitySchema {

    private final List<IngestionEntityDef> rootEntityDefs;

    private final Map<String, IngestionEntityDef> entityDefs;

    private IngestionEntitySchema(List<IngestionEntityDef> rootEntityDefs,
            Map<String, IngestionEntityDef> entityDefs) {
        this.rootEntityDefs = rootEntityDefs;
        this.entityDefs = entityDefs;
    }

    public static IngestionEntitySchema of(Class<? extends IngestionEntity> rootEntityType) {
        return of(new IngestionEntityDef(rootEntityType));
    }

    public static IngestionEntitySchema of(IngestionEntityDef rootEntityDef) {
        return of(Collections.singletonList(rootEntityDef));
    }

    public static IngestionEntitySchema of(List<IngestionEntityDef> rootEntityDefs) {
        Map<String, IngestionEntityDef> entityDefs = new LinkedHashMap<>();
        for (IngestionEntityDef o : rootEntityDefs) {
            if (null != o.getParentEntityDef()) {
                throw new IllegalArgumentException("Invalid root entity definition " + o.getName());
            }
            flattenEntityDefs(o, entityDefs);
        }
        return new IngestionEntitySchema(rootEntityDefs, entityDefs);
    }

    private static void flattenEntityDefs(IngestionEntityDef entityDef,
            Map<String, IngestionEntityDef> entityDefs) {
        if (null != entityDefs.put(entityDef.getName(), entityDef)) {
            throw new IllegalArgumentException("Duplicate entity definition " + entityDef.getName());
        }
        if (null != entityDef.getChildEntityDefs()) {
            for (IngestionEntityJoinColumnDef o : entityDef.getChildEntityDefs()) {
                flattenEntityDefs(o.getChildEntityDef(), entityDefs);
            }
        }
    }

    public IngestionEntityDef getEntityDef(String entityName) {
        return entityDefs.get(entityName);
    }
}
