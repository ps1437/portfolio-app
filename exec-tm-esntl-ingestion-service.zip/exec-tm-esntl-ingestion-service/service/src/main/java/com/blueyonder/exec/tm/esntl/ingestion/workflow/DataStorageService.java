/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionMetadataRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class DataStorageService {

    private final IngestionMetadataRepository repository;

    public void updateErrorFileDetails(
            UUID ingestionId,
            int totalRecords,
            FileUploadResponse fileUploadResponse,
            int totalSuccessRecords) {
        log.info("Updating the file details [ingestionId - {}], [totalRecords - {}], [totalSuccessRecords - {}] into ingestionMetadata", ingestionId, totalRecords, totalSuccessRecords);
        repository.findById(ingestionId).ifPresent(dataUploadDetails -> {
            IngestionStatus status = deriveStatus(totalRecords, totalSuccessRecords);
            if (Objects.nonNull(fileUploadResponse)) {
                dataUploadDetails.setErrorRecordsFileName(fileUploadResponse.getFileName());
                dataUploadDetails.setErrorRecordsFileId(fileUploadResponse.getFileId());
            }
            dataUploadDetails.setTotalSuccessRecords(totalSuccessRecords);
            dataUploadDetails.setTotalRecords(totalRecords);
            dataUploadDetails.setStatus(status.toString());
            dataUploadDetails.setEndDateTime(OffsetDateTime.now(ZoneOffset.UTC));
            repository.save(dataUploadDetails);
        });
    }

    public void updateErrorFileDetails(UUID recordId, int totalRecords, int totalSuccessRecords) {
        updateErrorFileDetails(recordId, totalRecords, null, totalSuccessRecords);
    }

    public void updateErrorFileDetails(UUID recordId, IngestionStatus status, int totalRecordCount) {
        repository.findById(recordId).ifPresent(dataUploadDetails -> {
            if (IngestionStatus.COMPLETED.equals(status)) {
                dataUploadDetails.setTotalSuccessRecords(totalRecordCount);
            }
            dataUploadDetails.setStatus(status.toString());
            dataUploadDetails.setTotalRecords(totalRecordCount);
            dataUploadDetails.setEndDateTime(OffsetDateTime.now(ZoneOffset.UTC));
            repository.save(dataUploadDetails);
        });
    }

    public DataIngestionDetails saveFileDetails(String fileName, String entityType) {
        DataIngestionDetails dataIngestionDetails = buildUploadDetails(fileName, entityType);
        return repository.save(dataIngestionDetails);
    }

    private DataIngestionDetails buildUploadDetails(String fileName, String entityType) {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setFileName(fileName);
        dataIngestionDetails.setStatus(IngestionStatus.PROCESSING.toString());
        dataIngestionDetails.setStartDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        dataIngestionDetails.setEntityType(entityType);
        return dataIngestionDetails;
    }

    private IngestionStatus deriveStatus(int totalRecordCount, int totalSuccessRecordCount) {
        return totalRecordCount - totalSuccessRecordCount == 0 ? IngestionStatus.COMPLETED : IngestionStatus.COMPLETED_WITH_ERRORS;
    }

}
