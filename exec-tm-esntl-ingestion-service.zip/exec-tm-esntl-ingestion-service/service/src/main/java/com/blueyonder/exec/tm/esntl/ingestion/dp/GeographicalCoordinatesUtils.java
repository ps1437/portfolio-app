/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import org.apache.commons.lang3.StringUtils;

import com.blueyonder.plat.dp.bydm.GeographicalCoordinatesType;
import com.blueyonder.plat.dp.bydm.LocationGeographicalCoordinatesType;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class GeographicalCoordinatesUtils {

    public static GeographicalCoordinatesType mapToGeographicalCoordinates(String latitude, String longitude) {
        if (StringUtils.isAllEmpty(latitude, longitude)) {
            return null;
        }
        return new GeographicalCoordinatesType().withLatitude(latitude)
                .withLongitude(longitude);
    }

    public static LocationGeographicalCoordinatesType mapToLocationGeographicalCoordinates(String latitude, String longitude) {
        if (StringUtils.isAllEmpty(latitude, longitude)) {
            return null;
        }
        return new LocationGeographicalCoordinatesType().withLatitude(latitude)
                .withLongitude(longitude);
    }
}
