/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionSourceType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionRequestReader;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.ERROR_MESSAGE;
import static org.apache.commons.lang3.StringUtils.trimToNull;

@Slf4j
@RequiredArgsConstructor
public class ExcelIngestionRequestReader implements IngestionRequestReader {

    private static final DataFormatter DATA_FORMATTER = new DataFormatter(Locale.US);

    private final String sourceName;

    private final IngestionEntitySchema entitySchema;

    private Workbook workbook;

    private IngestionRequest request;

    public IngestionRequest read(InputStream input) throws IOException {
        log.debug("Reading ingestion request from excel {sourceName={}}", sourceName);
        try (input) {
            workbook = WorkbookFactory.create(new BufferedInputStream(input));
            var requestSchema = readSchema();
            // Build ingestion pages, etc. as per prepared request schema...
            // Follow the order of entity schema to maintain relationships across entities...
            request = new IngestionRequest(IngestionSourceType.EXCEL, sourceName, requestSchema);
            requestSchema.forEach(this::readPage);
        }
        finally {
            IOUtils.closeQuietly(workbook);
        }
        // Let's perform require post construct activities like reclassification of entities, etc.
        request.getRequestPages().values().forEach(IngestionRequestPage::postConstruct);
        // Done!!!
        return request;
    }

    private List<IngestionRequestEntityDef> readSchema() {
        List<IngestionRequestEntityDef> result = new ArrayList<>();
        // Follow the order of entity schema to maintain relationships across entities...
        for (IngestionEntityDef entityDef : entitySchema.getEntityDefs().values()) {
            Sheet sheet = findValidSheet(entityDef);
            if (null != sheet) {
                Row row = sheet.getRow(sheet.getFirstRowNum());
                IngestionRequestEntityDef o = readPageSchema(entityDef, row);
                if (o.isValid()) {
                    result.add(o);
                }
            }
        }
        log.debug("Read ingestion request schema {sourceName={}, schema={}}", sourceName, result);
        return result;
    }

    private Sheet findValidSheet(IngestionEntityDef entityDef) {
        for (String s : entityDef.getNameWithAlias()) {
            Sheet sheet = workbook.getSheet(s);
            if (null != sheet && 0 != sheet.getPhysicalNumberOfRows()) {
                return sheet;
            }
        }
        log.debug("Valid sheet is not found by entity name or its alias {sourceName={}, names={}}",
                sourceName, entityDef.getNameWithAlias());
        return null;
    }

    private IngestionRequestEntityDef readPageSchema(IngestionEntityDef entityDef, Row header) {
        var requestEntityDef = new IngestionRequestEntityDef(entityDef);
        // Iterator based loop skips null value cells, and we read data from 0th index cell in sequence...
        for (int i = 0, n = header.getLastCellNum(); i < n; ++i) {
            String columnName = DATA_FORMATTER.formatCellValue(header.getCell(i));
            if (ERROR_MESSAGE.equals(columnName)) {
                // Let's assume this is last column...
                break;
            }
            requestEntityDef.addColumnDef(columnName);
        }
        return requestEntityDef;
    }

    private void readPage(IngestionRequestEntityDef requestEntityDef) {
        String name = requestEntityDef.getName();
        log.info("Reading the ingestion request page {sourceName={}, pageName={}}", sourceName, name);

        Sheet sheet = findValidSheet(requestEntityDef.getEntityDef());
        IngestionRequestPage requestPage = request.getRequestPages().get(name);
        int nbrOfColumns = requestEntityDef.getRequestColumnDefs().values().size();

        for (int i = sheet.getFirstRowNum() + 1, n = sheet.getPhysicalNumberOfRows(); i < n; ++i) {
            Row row = sheet.getRow(i);
            if (null != row) {
                List<String> list = readRow(row, nbrOfColumns);
                if (!list.isEmpty()) {
                    requestPage.addEntity(i, list);
                }
            }
        }
    }

    private List<String> readRow(Row row, int nbrOfColumns) {
        List<String> list = new ArrayList<>(nbrOfColumns);
        boolean containsData = false;
        for (int i = 0; i < nbrOfColumns; ++i) {
            String s = trimToNull(DATA_FORMATTER.formatCellValue(row.getCell(i)));
            containsData = containsData || null != s;
            list.add(s);
        }
        return containsData ? list : Collections.emptyList();
    }
}
