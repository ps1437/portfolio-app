/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.plat.dp.bydm.DescriptionType;
import com.blueyonder.plat.dp.bydm.LanguageCode;
import com.blueyonder.plat.dp.bydm.MeasurementType;
import com.blueyonder.plat.dp.bydm.MeasurementTypeCode;
import com.blueyonder.plat.dp.bydm.MeasurementUnitCode;
import com.blueyonder.plat.dp.bydm.TransportEquipmentTransportEquipmentType;
import com.blueyonder.plat.dp.bydm.UsageThresholdValuesType;
import com.blueyonder.plat.dp.bydm.commodityRestrictionsType;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.LENGTH;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.WEIGHT;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = {Arrays.class})
public interface TransportEquipmentMapper {

    String LENGTH_UOM = "mapToLengthUOM";

    @Mapping(source = "length", target = "length", qualifiedByName = LENGTH_UOM)
    @Mapping(source = "width", target = "width", qualifiedByName = LENGTH_UOM)
    @Mapping(source = "height", target = "height", qualifiedByName = LENGTH_UOM)
    @Mapping(source = "tareWeight", target = "tareWeight", qualifiedByName = "toWeightUOM")
    @Mapping(source = "maximumLoadingLength", target = "maximumLoadingLength", qualifiedByName = LENGTH_UOM)
    @Mapping(source = "maximumLoadingHeight", target = "maximumLoadingHeight", qualifiedByName = LENGTH_UOM)
    @Mapping(source = "maximumLoadingWidth", target = "maximumLoadingWidth", qualifiedByName = LENGTH_UOM)
    @Mapping(source = "description", target = "description", qualifiedByName = "toDescriptionType")
    @Mapping(source = "maximumLoadingWeight", target = "usageThresholdValues", qualifiedByName = "toUsageThresholdValues")
    @Mapping(expression = "java(null)", target = "avpList")
    TransportEquipmentTransportEquipmentType mapToTransportEquipmentType(TransportEquipmentEntity equipment, @Context Map<String, String> unitOfMeasures);

    @Named(LENGTH_UOM)
    default MeasurementType mapToLengthUOM(Double length, @Context Map<String, String> unitOfMeasures) {
        if (null != length) {
            MeasurementType measurementType = new MeasurementType();
            measurementType.setValue(length);
            if (StringUtils.isNotBlank(unitOfMeasures.get(LENGTH))) {
                measurementType.setMeasurementUnitCode(MeasurementUnitCode.fromValue(unitOfMeasures.get(LENGTH)));
            }
            return measurementType;
        }
        return null;
    }

    @Named("toWeightUOM")
    default MeasurementType mapToWeightUOM(Double weight, @Context Map<String, String> unitOfMeasures) {
        if (null != weight) {
            MeasurementType measurementType = new MeasurementType();
            measurementType.setValue(weight);
            if (StringUtils.isNotBlank(unitOfMeasures.get(WEIGHT))) {
                measurementType.setMeasurementUnitCode(MeasurementUnitCode.fromValue(unitOfMeasures.get(WEIGHT)));
            }
            return measurementType;
        }
        return null;
    }

    @Named("toDescriptionType")
    default DescriptionType mapToDescriptionType(String description) {
        if (StringUtils.isNotBlank(description)) {
            DescriptionType descriptionType = new DescriptionType();
            descriptionType.setValue(description);
            descriptionType.setLanguageCode(LanguageCode.EN);
            return descriptionType;
        }
        return null;
    }

    @Named("toUsageThresholdValues")
    default List<UsageThresholdValuesType> mapToUsageThresholdValues(Double maxLoadingWeight, @Context Map<String, String> unitOfMeasures) {
        if (null != maxLoadingWeight && StringUtils.isNotBlank(unitOfMeasures.get(WEIGHT))) {
            UsageThresholdValuesType usageThresholdValuesType = new UsageThresholdValuesType();
            usageThresholdValuesType.setMeasurementUnitCode(MeasurementUnitCode.fromValue(unitOfMeasures.get(WEIGHT)));
            usageThresholdValuesType.setMeasurementType(MeasurementTypeCode.WEIGHT);
            usageThresholdValuesType.setMaximumAllowableValue(maxLoadingWeight);
            return List.of(usageThresholdValuesType);
        }
        return Collections.emptyList();
    }

    @Mapping(source = "commodityRestrictionCode", target = "restrictionCode")
    @Mapping(source = "commodityType", target = "commodityCode")
    commodityRestrictionsType mapToCommodityRestrictionsType(CommodityRestrictionEntity commodityRestriction);
}
