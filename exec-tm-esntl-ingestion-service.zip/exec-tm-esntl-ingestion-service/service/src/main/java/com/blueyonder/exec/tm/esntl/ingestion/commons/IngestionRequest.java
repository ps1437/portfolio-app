/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;

import static java.util.Objects.requireNonNull;

@Getter
@ToString
public class IngestionRequest {

    @Setter
    private UUID requestId;

    private final IngestionSourceType sourceType;

    private final String sourceName;

    private final List<IngestionRequestEntityDef> requestSchema;

    private final Map<String, IngestionRequestPage> requestPages;

    public IngestionRequest(String sourceName, List<IngestionRequestEntityDef> requestSchema) {
        this(IngestionSourceType.EXCEL, sourceName, requestSchema);
    }

    public IngestionRequest(IngestionSourceType sourceType, String sourceName, List<IngestionRequestEntityDef> requestSchema) {
        this.sourceType = requireNonNull(sourceType);
        this.sourceName = requireNonNull(sourceName);
        this.requestSchema = requireNonNull(requestSchema);
        this.requestPages = new LinkedHashMap<>(requestSchema.size());
        for (IngestionRequestEntityDef requestEntityDef : requestSchema) {
            requestPages.put(requestEntityDef.getName(), new IngestionRequestPage(requestEntityDef, this));
        }
    }

    public IngestionRequestPage getFirstRequestPage() {
        return requestPages.get(requestSchema.get(0).getName());
    }

    public boolean isEmpty() {
        for (IngestionRequestPage page : requestPages.values()) {
            if (!page.getEntities().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public <T extends IngestionEntity> List<T> getEntities(String entityName) {
        var page = requestPages.get(entityName);
        return null != page ? page.getEntities() : Collections.emptyList();
    }

    public <T extends IngestionEntity> List<T> getValidEntities(String entityName) {
        var page = requestPages.get(entityName);
        return null != page ? page.getValidEntities() : Collections.emptyList();
    }

    public <T extends IngestionEntity> List<T> getInvalidEntities(String entityName) {
        var page = requestPages.get(entityName);
        return null != page ? page.getInvalidEntities() : Collections.emptyList();
    }
}
