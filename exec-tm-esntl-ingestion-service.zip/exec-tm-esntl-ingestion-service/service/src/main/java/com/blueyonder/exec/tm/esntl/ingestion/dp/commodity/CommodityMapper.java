/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.commodity;

import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.plat.dp.bydm.CommodityType;
import com.blueyonder.plat.dp.bydm.DescriptionType;
import com.blueyonder.plat.dp.bydm.LanguageCode;
import com.blueyonder.plat.dp.bydm.SegmentActionEnumerationType;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CommodityMapper {

    @Mapping(source = ".", target = "description", qualifiedByName = "toDescription")
    CommodityType mapToCommodityType(CommodityEntity commodity);

    List<CommodityType> mapToCommodityType(List<CommodityEntity> commodity);

    @Named("toDescription")
    default List<DescriptionType> mapToDescription(CommodityEntity commodity) {
        if (!StringUtils.isBlank(commodity.getValue())) {
            DescriptionType descriptionType = new DescriptionType().withValue(commodity.getValue())
                    .withActionCode(SegmentActionEnumerationType.ADD).withLanguageCode(LanguageCode.EN);
            return List.of(descriptionType);
        }
        return Collections.emptyList();
    }
}
