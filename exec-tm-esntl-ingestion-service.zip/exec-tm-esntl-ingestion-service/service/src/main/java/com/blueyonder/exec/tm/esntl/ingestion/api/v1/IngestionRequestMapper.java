/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.time.Instant;
import java.time.OffsetDateTime;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IngestionRequestMapper {

    @Mapping(source = "createdDate", target = "createdDate", qualifiedByName = "toOffsetDateTime", conditionExpression = "java(null != ingestionRequestEntity.getCreatedDate())")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate", qualifiedByName = "toOffsetDateTime", conditionExpression = "java(null != ingestionRequestEntity.getLastModifiedDate())")
    IngestionRequestModel toIngestionRequestModel(IngestionRequestEntity ingestionRequestEntity);

    @Named("toOffsetDateTime")
    default OffsetDateTime toOffsetDateTime(Instant instant) {
        return OffsetDateTime.parse(instant.toString());
    }

}
