/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Id;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ReflectionUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.DataConverter;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.DataConverterUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.NoOpConverter;

import static java.util.Objects.requireNonNull;

@Getter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class IngestionEntityDef {

    @EqualsAndHashCode.Include
    private final String name;

    private final Class<? extends IngestionEntity> type;

    private List<String> nameWithAlias;

    private IngestionEntityColumnDef idColumnDef;

    private Map<String, IngestionEntityColumnDef> columnDefs;

    private Map<String, IngestionEntityColumnDef> aliasColumnDefs;

    private IngestionEntityDef parentEntityDef;

    private IngestionEntityOneToManyDef parentEntityOneToManyDef;

    private Set<IngestionEntityJoinColumnDef> childEntityDefs;

    public IngestionEntityDef(Class<? extends IngestionEntity> type) {
        this.type = requireNonNull(type);

        String name = null;
        String[] alias = null;
        Entity entity = type.getAnnotation(Entity.class);
        if (null != entity) {
            name = entity.name();
            alias = entity.alias();
        }
        if (StringUtils.isEmpty(name)) {
            name = type.getSimpleName();
        }

        this.name = name;

        initialize(alias);
    }

    public IngestionEntityDef(String name, Class<? extends IngestionEntity> type) {
        this(name, type, (String[]) null);
    }

    public IngestionEntityDef(String name, Class<? extends IngestionEntity> type, String... alias) {
        this.name = requireNonNull(name);
        this.type = requireNonNull(type);
        initialize(alias);
    }

    private static List<String> joinNameAndAlias(String name, String[] alias) {
        if (null == alias || 0 == alias.length) {
            return List.of(name);
        }
        String[] a = new String[1 + alias.length];
        a[0] = name;
        System.arraycopy(alias, 0, a, 1, alias.length);
        return List.of(a);
    }

    private void initialize(String[] alias) {
        nameWithAlias = joinNameAndAlias(name, alias);

        processAnnotations();

        if (null != childEntityDefs && null == idColumnDef) {
            throw new IllegalArgumentException("Entity " + name + " has one to many relationships but ID column is undefined.");
        }
    }

    private void processAnnotations() {
        columnDefs = new LinkedHashMap<>();
        aliasColumnDefs = new HashMap<>();
        ReflectionUtils.doWithFields(type, (field) -> {
            Column column = field.getAnnotation(Column.class);
            if (null != column) {
                processColumnAnnotation(field, column);
            }
            OneToMany oneToMany = field.getAnnotation(OneToMany.class);
            if (null != oneToMany) {
                processOneToManyAnnotation(field, oneToMany);
            }
        });
    }

    private void processColumnAnnotation(Field field, Column column) {
        ReflectionUtils.makeAccessible(field);

        DataConverter<?> converter = getDataConverter(column);
        if (null == converter) {
            converter = DataConverterUtils.getDataConverter(field.getType());
        }

        String name = column.name();
        if (name.isEmpty()) {
            name = field.getName();
        }

        IngestionEntityColumnDef columnDef = new IngestionEntityColumnDef(name, field, converter);

        columnDefs.put(name, columnDef);

        for (String alias : column.alias()) {
            aliasColumnDefs.put(alias, columnDef);
        }

        if (null == idColumnDef && null != field.getAnnotation(Id.class)) {
            idColumnDef = columnDef;
        }
    }

    private DataConverter<?> getDataConverter(Column column) {
        var converterType = column.converter();
        if (converterType != NoOpConverter.class) {
            try {
                return converterType.getDeclaredConstructor().newInstance();
            }
            catch (Exception ex) {
                ReflectionUtils.handleReflectionException(ex);
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private void processOneToManyAnnotation(Field field, OneToMany oneToMany) {
        if (!field.getType().isAssignableFrom(List.class)) {
            throw new IllegalArgumentException("Field \"" + field + " \" is not List type.");
        }

        ReflectionUtils.makeAccessible(field);

        Class<? extends IngestionEntity> childEntityType = (Class<? extends IngestionEntity>)
                ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
        if (type == childEntityType) {
            throw new IllegalArgumentException("Self join is not supported " + type);
        }

        IngestionEntityDef childEntityDef = new IngestionEntityDef(childEntityType);
        IngestionEntityColumnDef refColumnDef = childEntityDef.columnDefs.get(oneToMany.joinColumnName());
        if (null == refColumnDef) {
            throw new IllegalArgumentException("Join column is not found in child entity "
                    + childEntityDef.name + " (" + oneToMany.joinColumnName() + ")");
        }

        childEntityDef.parentEntityDef = this;
        childEntityDef.parentEntityOneToManyDef = new IngestionEntityOneToManyDef(field, refColumnDef);

        if (null == childEntityDefs) {
            childEntityDefs = new LinkedHashSet<>(2);
        }

        childEntityDefs.add(new IngestionEntityJoinColumnDef(oneToMany.joinColumnName(), field, childEntityDef));
    }

    public IngestionEntityColumnDef getColumnDef(String columnName) {
        var o = columnDefs.get(columnName);
        return null != o ? o : aliasColumnDefs.get(columnName);
    }

    @SuppressWarnings("unchecked")
    public <T extends IngestionEntity> T createEntity() {
        try {
            return (T) type.getConstructor().newInstance();
        }
        catch (Exception ex) {
            ReflectionUtils.handleReflectionException(ex);
            return null;
        }
    }

    @Override
    public String toString() {
        return "IngestionEntityDef(nameWithAlias=" + nameWithAlias +
                ", type=" + type.getSimpleName() +
                ", idColumnDef=" + idColumnDef +
                ", columnDefs=" + columnDefs.values() +
                ", childEntityDefs=" + childEntityDefs +
                ")";
    }
}
