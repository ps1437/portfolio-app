/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceImpl;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.plat.dp.api.client.EntityDpClient;
import com.blueyonder.plat.dp.api.model.EntityErrorResponseModel;
import com.jda.security.tenancy.TenancyContextHolder;

import static java.util.Objects.requireNonNull;

@Slf4j
public abstract class DpIngestionServiceImpl extends IngestionServiceImpl {

    private final DpClient dpClient;

    private final EntityDpClient<?> entityDpClient;

    private final DataStorageService dataStorageService;

    private final PostIngestionService postIngestionService;

    private final IngestionConfigProperties ingestionConfigProperties;

    public DpIngestionServiceImpl(DpClient dpClient,
            EntityDpClient<?> entityDpClient,
            DataStorageService dataStorageService,
            PostIngestionService postIngestionService,
            IngestionConfigProperties ingestionConfigProperties) {
        this.entityDpClient = requireNonNull(entityDpClient);
        this.dataStorageService = requireNonNull(dataStorageService);
        this.postIngestionService = requireNonNull(postIngestionService);
        this.dpClient = requireNonNull(dpClient);
        this.ingestionConfigProperties = ingestionConfigProperties;
    }

    protected DataIngestionDetails ingest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
        List<?> entities = prepareEntitiesToIngest(ingestionRequest, rootEntityPage);
        log.info("Ingesting valid entities {name={}, size={}}", rootEntityPage.getName(), entities.size());
        var dataIngestionDetails = dataStorageService.saveFileDetails(ingestionRequest.getSourceName(), getType().name());
        if (null == ingestionRequest.getRequestId()) {
            //Not required once deprecated API is removed
            ingestionRequest.setRequestId(dataIngestionDetails.getId());
        }
        ingest(entities, ingestionRequest, rootEntityPage.getRequestEntityDef().getEntityDef());
        return dataIngestionDetails;
    }

    private void ingest(List<?> entities, IngestionRequest ingestionRequest, IngestionEntityDef entityDef) {
        if (!entities.isEmpty()) {
            var requestId = ingestionRequest.getRequestId();
            AtomicInteger batchSeq = new AtomicInteger(1);
            UUID batchId = UUID.randomUUID();
            Flux.fromIterable(entities)
                    .buffer(ingestionConfigProperties.getBatchConfig().getBatchSize())
                    .flatMap(entitiesBatch -> syncIngest(batchId, batchSeq.getAndIncrement(), ingestionRequest, entitiesBatch))
                    .transform(batchIngestionResponseFlux -> {
                        BatchIngestionResponseAggregator aggregator = new BatchIngestionResponseAggregator();
                        return batchIngestionResponseFlux.map(aggregator::aggregate).last();
                    })
                    .doOnNext(postIngestionService::processIngestion)
                    .doOnError(error -> {
                        log.error("Exception occurred while using create API. Falling back to ingest API", error);
                        asyncIngest(requestId, entities, ingestionRequest, entityDef);
                    })
                    .subscribe();
        }
        else {
            postIngestionService.processIngestion(new IngestionResponse(ingestionRequest));
        }
    }

    /**
     * Uses dp interactive APIs which are synchronous
     *
     * @param batchId
     * @param batchSeq
     * @param ingestionRequest
     * @param entities
     * @return
     */
    private Mono<BatchIngestionResponse> syncIngest(UUID batchId, Integer batchSeq, IngestionRequest ingestionRequest, List<?> entities) {
        log.info("Ingesting batch: {}, seq: {} using create api, tenantId: {}", batchId.toString(), batchSeq, TenancyContextHolder.getContext().getTenantId());
        return entityDpClient.create(entities)
                .transformDeferredContextual((postEntityResponseModelMono, contextView) -> postEntityResponseModelMono
                        .doOnEach(postEntityResponseModelSignal -> TenancyContextHolder.setContext(contextView.get("tenancyContext")))
                        .map(response -> new BatchIngestionResponse(batchId, batchSeq, ingestionRequest, response))
                        .onErrorResume(e -> {
                            if (e instanceof WebClientResponseException ex) {
                                EntityErrorResponseModel errorResponse = JsonUtils.fromJson(ex.getResponseBodyAsByteArray(), EntityErrorResponseModel.class);
                                return Mono.just(new BatchIngestionResponse(batchId, batchSeq, ingestionRequest, errorResponse));
                            }
                            return Mono.error(e);
                        })).contextWrite(Context.of("tenancyContext", TenancyContextHolder.getContext()));
    }

    private void asyncIngest(UUID requestId, List<?> entities, IngestionRequest ingestionRequest, IngestionEntityDef entityDef) {
        log.info("Using dp ingest API");
        dpClient.ingest(entityDpClient, entities)
                .doOnError(throwable -> {
                    log.error("Exception encountered while ingesting/retrieving {} upload data", getType());
                    dataStorageService.updateErrorFileDetails(requestId,
                            IngestionStatus.FAILED,
                            ingestionRequest.getEntities(entityDef.getName()).size());
                })
                .subscribe(response -> postIngestionService.processIngestion(
                        new DpIngestionResponse(ingestionRequest, response)
                ));
    }

    protected abstract List<?> prepareEntitiesToIngest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage);

}
