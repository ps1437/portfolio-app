/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ServiceLevelCodeModel;
import com.blueyonder.plat.dp.bydm.CarrierCharacteristicsEnumerationType;

@Getter
@Setter
@ToString
@Entity(name = "Carrier Services")
public class CarrierServiceEntity extends IngestionEntity {

    @Column(name = "CARRIER_ID")
    private String carrierId;

    @Column(name = "SERVICE_LEVEL_CODE")
    private ServiceLevelCodeModel serviceLevelCode;

    @Column(name = "SERVICE_TYPE")
    private String serviceType;

    @Column(name = "LABELING")
    private CarrierCharacteristicsEnumerationType labellingType;

    @Column(name = "TRACKING")
    private CarrierCharacteristicsEnumerationType trackingType;

    @Column(name = "APPOINTMENTS")
    private CarrierCharacteristicsEnumerationType appointmentsType;

    @Column(name = "BOOKING_OR_TENDERING")
    private CarrierCharacteristicsEnumerationType bookingOrTenderingType;

    @Column(name = "BOOKING_CUTOFF_TIME_OF_DAY")
    private String bookingCutoffTimeOfDay;

    @Column(name = "PICKUP_LEAD_TIME")
    private Double pickupLeadTime;
}
