/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.JsonUtils;
import com.blueyonder.exec.ecom.boot.commons.core.utils.BusinessIdUtils;
import com.blueyonder.plat.dp.bydm.SegmentActionEnumerationType;
import com.blueyonder.plat.dp.bydm.StopActivityTypeCode;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import static java.util.Objects.requireNonNull;

@Slf4j
@Component
public class ShipmentMapper {

    private static final Chainr SHIPMENT_TRANSFORMER = Chainr.fromSpec(JsonUtils.classpathToObject("/specs/create-shipment-spec.json"));

    private static final String REFERENCE_NAME = "referenceName";

    private static final String REFERENCE_VALUE = "referenceValue";

    private static final String DOCUMENT_REFERENCE = "documentReference";

    private static final String LOGISTIC_UNIT_ID = "logisticUnitId";

    private static final String SHIPMENT_REFERENCE_NAME = "SHIPMENT_REFERENCE_NAME";

    private final ObjectMapper objectMapper;

    public ShipmentMapper(ObjectMapper objectMapper) {
        this.objectMapper = requireNonNull(objectMapper);
        this.objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
    }

    //Todo : Replace with MapStruct or java mapper code
    public ObjectNode mapToShipmentForCreate(ShipmentEntity shipment) {
        String shipmentId = BusinessIdUtils.generateBase32();
        shipment.getMetadata().setExternalReferenceId(shipmentId);

        Map<String, Object> inputJson = objectMapper.convertValue(shipment, new TypeReference<>() {
        });
        String currentDateTime = Instant.now().truncatedTo(ChronoUnit.MILLIS).toString();
        inputJson.put("shipmentId", shipmentId);
        inputJson.put("currentDateTime", currentDateTime);
        inputJson.put("legUUID", UUID.randomUUID());

        Object mappedObject = SHIPMENT_TRANSFORMER.transform(inputJson);

        ObjectNode jsonNodes = objectMapper.convertValue(mappedObject, ObjectNode.class);
        if (ShipmentType.LOAD_BASED.equals(shipment.getShipmentType())) {
            jsonNodes.remove("shipmentLeg");
        }
        setDocReferencesWithReferenceNumberAndType(jsonNodes, shipment);

        //TODO: need to remove shipmentLine when it's structure is finalized
        ArrayNode shipmentLine = objectMapper.createArrayNode();
        jsonNodes.set("shipmentLine", shipmentLine);
        JsonNode logisticUnitNodes = jsonNodes.get("plannedLogisticUnit");
        if (logisticUnitNodes != null && !logisticUnitNodes.isNull()) {
            Double totalGrossWeight = 0.0;
            ArrayNode arrayNode = objectMapper.createArrayNode();
            for (JsonNode logisticUnitNode : logisticUnitNodes) {
                ObjectNode node = logisticUnitNode.deepCopy();
                node.put(LOGISTIC_UNIT_ID, BusinessIdUtils.generateBase32());
                node.put("weightUom", "MGM");
                ObjectNode totalGrossDimensions = logisticUnitNode.get("totalGrossDimensions").deepCopy();
                totalGrossDimensions.put("dimensionUom", "FOT");
                node.set("totalGrossDimensions", totalGrossDimensions);
                Double grossWeight = logisticUnitNode.get("totalGrossWeight") != null ? logisticUnitNode.get("totalGrossWeight").doubleValue() : 0.0;
                totalGrossWeight = totalGrossWeight + grossWeight;
                arrayNode.add(node);
            }
            ((ArrayNode) logisticUnitNodes).removeAll();
            ((ArrayNode) logisticUnitNodes).addAll(arrayNode);
            ObjectNode freightTotalNode = objectMapper.createObjectNode();
            freightTotalNode.put("totalGrossWeight", totalGrossWeight);
            freightTotalNode.put("weightUom", logisticUnitNodes.get(0).get("weightUom").textValue());
            jsonNodes.set("freightTotal", freightTotalNode);
        }
        return mapStop(jsonNodes, currentDateTime, shipment.getOriginLocationName(), shipment.getDestinationLocationName());
    }

    private void setDocReferencesWithReferenceNumberAndType(ObjectNode jsonNodes, ShipmentEntity shipment) {
        ArrayNode documentReferences = objectMapper.createArrayNode();
        addReferenceNumber(shipment.getReferenceNumberType(), shipment.getReferenceNumber(), documentReferences);
        addReferenceNumber(SHIPMENT_REFERENCE_NAME, shipment.getShipmentReferenceId(), documentReferences);
        jsonNodes.set(DOCUMENT_REFERENCE, documentReferences);
    }

    private void addReferenceNumber(String referenceType, String value, ArrayNode documentReferences) {
        if (StringUtils.isNoneBlank(referenceType, value)) {
            ObjectNode docReference = objectMapper.createObjectNode();
            docReference.put(REFERENCE_NAME, referenceType);
            docReference.put(REFERENCE_VALUE, value);
            documentReferences.add(docReference);
        }
    }

    public ObjectNode mapStop(ObjectNode node, String currentDateTime, String pickLocationName, String dropLocationName) {
        JsonNode logisticUnitNodes = node.get("plannedLogisticUnit");
        JsonNode stop = node.get("stop");
        ((ObjectNode) stop.get(0)).put("stopLocationName", pickLocationName);
        ((ObjectNode) stop.get(1)).put("stopLocationName", dropLocationName);
        if (logisticUnitNodes != null && !logisticUnitNodes.isNull()) {
            ArrayNode actList = objectMapper.createArrayNode();
            for (int i = 0; i < logisticUnitNodes.size(); i++) {
                ObjectNode stopActivity = objectMapper.createObjectNode();
                stopActivity.put("actionCode", SegmentActionEnumerationType.ADD.value());
                stopActivity.put("activityTypeCode", StopActivityTypeCode.OPEN.value());
                stopActivity.put("activityDateTime", currentDateTime);
                stopActivity.put(LOGISTIC_UNIT_ID, logisticUnitNodes.get(i).get(LOGISTIC_UNIT_ID).asText());
                actList.add(stopActivity);
            }
            ((ObjectNode) stop.get(0)).set("stopActivity", actList);
            ((ObjectNode) stop.get(1)).set("stopActivity", actList);
        }
        return node;
    }
}
