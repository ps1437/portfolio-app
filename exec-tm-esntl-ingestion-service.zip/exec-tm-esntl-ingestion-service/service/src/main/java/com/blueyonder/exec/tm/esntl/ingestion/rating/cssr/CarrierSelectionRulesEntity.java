/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating.cssr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.FreightTermsModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ServiceLevelCodeModel;

@Getter
@Setter
@ToString
@Entity(name = "Carrier Service Selection Rules")
public class CarrierSelectionRulesEntity extends IngestionEntity {

    @Column(name = "RULE_ID")
    private String ruleId;

    @Column(name = "CARRIER_ID")
    private String carrierId;

    @Column(name = "SERVICE_LEVEL_CODE")
    private ServiceLevelCodeModel serviceLevelCode;

    @Column(name = "MAXIMUM_WEIGHT")
    private Double maxWeight;

    @Column(name = "MINIMUM_WEIGHT")
    private Double minWeight;

    @Column(name = "MINIMUM_LENGTH")
    private Double minLength;

    @Column(name = "MAXIMUM_LENGTH")
    private Double maxLength;

    @Column(name = "MINIMUM_WIDTH")
    private Double minWidth;

    @Column(name = "MAXIMUM_WIDTH")
    private Double maxWidth;

    @Column(name = "MINIMUM_HEIGHT")
    private Double minHeight;

    @Column(name = "MAXIMUM_HEIGHT")
    private Double maxHeight;

    @Column(name = "INCLUDE_FREIGHT_CLASS")
    private String includeFreightClasses;

    @Column(name = "EXCLUDE_FREIGHT_CLASS")
    private String excludeFreightClasses;

    @Column(name = "INCLUDE_FREIGHT_TERMS")
    private FreightTermsModel includeFreightTerms;

    @Column(name = "EXCLUDE_FREIGHT_TERMS")
    private FreightTermsModel excludeFreightTerms;

    @Column(name = "INCLUDE_COMMODITY_ID")
    private String includeCommodityTypes;

    @Column(name = "EXCLUDE_COMMODITY_ID")
    private String excludeCommodityTypes;

    @Column(name = "INCLUDE_ORIGIN_ZONE")
    private String includeOriginZone;

    @Column(name = "EXCLUDE_ORIGIN_ZONE")
    private String excludeOriginZone;

    @Column(name = "INCLUDE_DESTINATION_ZONE")
    private String includeDestinationZone;

    @Column(name = "EXCLUDE_DESTINATION_ZONE")
    private String excludeDestinationZone;

    @Column(name = "INCLUDE_CUSTOMER")
    private String includeCustomers;

    @Column(name = "EXCLUDE_CUSTOMER")
    private String excludeCustomers;

    @Override
    public void postConstruct() {
        super.getMetadata().setReferenceId(ruleId);
    }
}
