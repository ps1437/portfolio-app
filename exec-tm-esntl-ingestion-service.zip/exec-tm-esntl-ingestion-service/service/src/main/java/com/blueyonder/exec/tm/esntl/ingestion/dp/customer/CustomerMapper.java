/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.customer;

import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.exec.tm.esntl.ingestion.dp.CommunicationChannelUtils;
import com.blueyonder.exec.tm.esntl.ingestion.dp.GeographicalCoordinatesUtils;
import com.blueyonder.plat.dp.bydm.FinancialDetails;
import com.blueyonder.plat.dp.bydm.GeographicalCoordinatesType;
import com.blueyonder.plat.dp.bydm.PartyContactType;
import com.blueyonder.plat.dp.bydm.PartyIdentificationType;
import com.blueyonder.plat.dp.bydm.PartyRoleCode;
import com.blueyonder.plat.dp.bydm.PartyType;

@Mapper(componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = PartyRoleCode.class
)
public interface CustomerMapper {

    @Mapping(source = "customerId", target = "partyId")
    @Mapping(source = "customerName", target = "basicParty.partyName")
    @Mapping(source = "countryCode", target = "basicParty.partyAddress.countryCode")
    @Mapping(source = "state", target = "basicParty.partyAddress.state")
    @Mapping(source = "city", target = "basicParty.partyAddress.city")
    @Mapping(source = "streetAddressOne", target = "basicParty.partyAddress.streetAddressOne")
    @Mapping(source = "streetAddressTwo", target = "basicParty.partyAddress.streetAddressTwo")
    @Mapping(source = "streetAddressThree", target = "basicParty.partyAddress.streetAddressThree")
    @Mapping(source = "postalCode", target = "basicParty.partyAddress.postalCode")
    @Mapping(source = ".", target = "basicParty.partyAddress.geographicalCoordinates", qualifiedByName = "toGeographicalCoordinatesModel")
    @Mapping(source = ".", target = "extensions")
    @Mapping(expression = "java(null)", target = "avpList")
    @Mapping(source = "customerType", target = "customerDetails.customerClass")
    @Mapping(target = "basicParty.partyRole", expression = "java(PartyRoleCode.CUSTOMER)")
    @Mapping(source = ".", target = "basicParty.partyContact", qualifiedByName = "toContactModel")
    @Mapping(source = ".", target = "basicParty.financialInformation", qualifiedByName = "mapToFinancialInformation")
    PartyType mapToParties(CustomerEntity customer);

    List<PartyType> mapToParties(List<CustomerEntity> customer);

    @Named("toContactModel")
    default List<PartyContactType> mapCommunicationChannel(CustomerEntity customer) {
        if (StringUtils.isAllEmpty(customer.getEmail(), customer.getTelefax(), customer.getTelephone(), customer.getPersonName(), customer.getWebsite())) {
            return Collections.emptyList();
        }
        return CommunicationChannelUtils.getPartyContactTypes(customer.getEmail(),
                customer.getWebsite(), customer.getTelephone(), customer.getTelefax(), customer.getPersonName());
    }

    @Named("toGeographicalCoordinatesModel")
    default GeographicalCoordinatesType mapToGeographicalCoordinates(CustomerEntity customer) {
        return GeographicalCoordinatesUtils.mapToGeographicalCoordinates(customer.getLatitude(), customer.getLongitude());
    }

    @Named("mapToFinancialInformation")
    default FinancialDetails mapToFinancialInformation(CustomerEntity customer) {
        if (null != customer.getDefaultBillToCustomerCode()) {
            FinancialDetails financialDetails = new FinancialDetails();
            PartyIdentificationType partyIdentificationType = new PartyIdentificationType().withPrimaryId(customer.getDefaultBillToCustomerCode());
            financialDetails.setBillTo(partyIdentificationType);
            return financialDetails;
        }
        return null;
    }
}
