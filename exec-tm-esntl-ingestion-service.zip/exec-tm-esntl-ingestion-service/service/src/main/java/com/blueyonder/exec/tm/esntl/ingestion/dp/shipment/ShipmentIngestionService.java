/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.extern.slf4j.Slf4j;

import java.util.List;

import org.springframework.stereotype.Service;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpIngestionServiceImpl;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.ShipmentDpClient;

import static java.util.Objects.requireNonNull;

@Slf4j
@Service
public class ShipmentIngestionService extends DpIngestionServiceImpl {

    private static final IngestionEntitySchema ENTITY_SCHEMA = IngestionEntitySchema.of(ShipmentEntity.class);

    private final ShipmentMapper shipmentMapper;

    private final ShipmentLocationDnfService shipmentLocationDnfService;

    private final ShipmentPartyDnfService shipmentPartyDnfService;

    public ShipmentIngestionService(DpClient dpClient,
            ShipmentDpClient shipmentDpClient,
            DataStorageService dataStorageService,
            PostIngestionService postIngestionService,
            ShipmentMapper shipmentMapper,
            ShipmentLocationDnfService shipmentLocationDnfService,
            ShipmentPartyDnfService shipmentPartyDnfService,
            IngestionConfigProperties ingestionConfigProperties) {
        super(dpClient, shipmentDpClient, dataStorageService, postIngestionService, ingestionConfigProperties);
        this.shipmentMapper = requireNonNull(shipmentMapper);
        this.shipmentLocationDnfService = requireNonNull(shipmentLocationDnfService);
        this.shipmentPartyDnfService = requireNonNull(shipmentPartyDnfService);
    }

    @Override
    public IngestionType getType() {
        return IngestionType.SHIPMENT;
    }

    @Override
    public IngestionEntitySchema getEntitySchema() {
        return ENTITY_SCHEMA;
    }

    @Override
    protected List<?> prepareEntitiesToIngest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
        List<ShipmentEntity> shipments = rootEntityPage.getValidEntities();
        // TODO: Eliminate overall multiple looping..
        shipmentPartyDnfService.denormalizeShipments(shipments);
        shipmentLocationDnfService.denormalizeShipments(shipments);
        return shipments.stream().map(shipmentMapper::mapToShipmentForCreate).toList();
    }
}
