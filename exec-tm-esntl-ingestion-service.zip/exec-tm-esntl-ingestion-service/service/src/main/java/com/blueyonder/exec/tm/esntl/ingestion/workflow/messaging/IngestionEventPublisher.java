/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.messaging;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blueyonder.exec.ecom.boot.outbox.publisher.EventEntityPublisher;
import com.blueyonder.exec.ecom.boot.outbox.publisher.domain.AggregateEvent;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionEventPublisher {

    private final EventEntityPublisher publisher;

    private final IngestionConfigProperties ingestionConfigProperties;

    @Transactional
    public void publish(IngestionRequestEntity ingestionRequestEntity) {
        log.info("Publishing event via outbox, ingestion request id: {}", ingestionRequestEntity.getRequestId());

        AggregateEvent aggregateEvent = AggregateEvent.builder()
                .applicationInstanceId("${spring.application.name}")
                .eventName(ingestionConfigProperties.getEventConfig().getEventName())
                .aggregateName(ingestionConfigProperties.getEventConfig().getEventName())
                .aggregate(ingestionRequestEntity)
                .msgSysTopic(ingestionConfigProperties.getEventConfig().getTopicName())
                .build();
        publisher.saveAndPublishEvent(aggregateEvent);
    }

}
