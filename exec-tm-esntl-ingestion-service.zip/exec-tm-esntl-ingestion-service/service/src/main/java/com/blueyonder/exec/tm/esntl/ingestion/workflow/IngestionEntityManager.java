/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.blueyonder.exec.ecom.boot.commons.web.error.ConflictAppException;
import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;
import com.blueyonder.exec.ecom.boot.commons.web.error.NotFoundAppException;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionErrorEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestStatusEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionErrorRepository;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionRequestRepository;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionRequestStatusRepository;
import com.google.common.annotations.VisibleForTesting;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionEntityManager {

    public static final String INGESTION_REQUEST_CREATE_CONFLICT = "Ingestion request is already created";

    public static final String INGESTION_REQUEST_NOT_FOUND = "Ingestion request with id: {0} doesn't exist";

    private final IngestionRequestRepository ingestionRequestRepository;

    private final IngestionRequestStatusRepository ingestionRequestStatusRepository;

    private final IngestionErrorRepository ingestionErrorRepository;

    public IngestionRequestEntity createIngestionRequest(IngestionType entityType, String fileId, String fileName) {
        ingestionRequestRepository.findByFileId(fileId)
                .ifPresent(r -> {
                    throw new ConflictAppException(false, IngestionErrorCode.INVALID_INGESTION_REQUEST.getErrorCode(), IngestionErrorCode.INVALID_INGESTION_REQUEST.getDefaultMessage());
                });
        IngestionRequestEntity ingestionRequestEntity = ingestionRequestRepository.save(buildIngestionRequest(entityType, fileId, fileName));
        ingestionRequestStatusRepository.save(buildIngestionRequestStatus(ingestionRequestEntity, IngestionStatus.QUEUED, 0, 0));
        return ingestionRequestEntity;
    }

    public Page<IngestionRequestEntity> getIngestionRequests(Pageable pageable) {
        return ingestionRequestRepository.findAll(pageable);
    }

    public IngestionRequestEntity getIngestionRequestById(UUID requestId) {
        return ingestionRequestRepository
                .findByRequestId(requestId)
                .orElseThrow(() -> new NotFoundAppException(false, IngestionErrorCode.INVALID_INGESTION_REQUEST.getErrorCode(), IngestionErrorCode.INVALID_INGESTION_REQUEST.getDefaultMessage(), requestId));
    }

    public IngestionRequestStatusEntity getIngestionRequestStatusById(UUID requestId) {
        return ingestionRequestStatusRepository
                .findByRequestId(requestId)
                .orElseThrow(() -> new NotFoundAppException(false, IngestionErrorCode.INVALID_INGESTION_REQUEST.getErrorCode(), IngestionErrorCode.INVALID_INGESTION_REQUEST.getDefaultMessage(), requestId));
    }

    public Page<IngestionRequestStatusEntity> getIngestionRequestStatuses(Pageable pageable) {
        return ingestionRequestStatusRepository.findAll(pageable);
    }

    public IngestionErrorEntity getIngestionError(UUID requestId) {
        return ingestionErrorRepository
                .findByRequestId(requestId)
                .orElseThrow(() -> new NotFoundAppException(false, IngestionErrorCode.INVALID_INGESTION_REQUEST.getErrorCode(), IngestionErrorCode.INVALID_INGESTION_REQUEST.getDefaultMessage(), requestId));
    }

    public void createIngestionError(UUID requestId, FileUploadResponse file, List<ErrorInfo> errors) {
        IngestionRequestEntity ingestionRequestEntity = getIngestionRequestById(requestId);
        ingestionErrorRepository.save(buildIngestionError(ingestionRequestEntity, file, errors));
    }

    public void updateStatus(UUID requestId, IngestionStatus status) {
        updateStatus(requestId, status, 0, 0);
    }

    public void updateStatus(UUID requestId, IngestionStatus status, int totalRecords) {
        updateStatus(requestId, status, totalRecords, 0);
    }

    public void updateStatus(UUID requestId, IngestionStatus status, int totalRecords, int successRecords) {
        log.info("Updating ingestion request status, requestId: {}, status: {}", requestId, status.name());
        IngestionRequestEntity ingestionRequestEntity = getIngestionRequestById(requestId);
        ingestionRequestStatusRepository.findByRequestId(requestId).ifPresentOrElse(ingestionStatus -> {
            ingestionStatus.setStatus(status);
            if (status == IngestionStatus.PROCESSING) {
                ingestionStatus.setProcessingStartDate(OffsetDateTime.now(ZoneOffset.UTC));
            } else {
                ingestionStatus.setProcessingEndDate(OffsetDateTime.now(ZoneOffset.UTC));
            }
            ingestionStatus.setTotalRecordsCount(totalRecords);
            ingestionStatus.setSuccessRecordsCount(successRecords);
            ingestionRequestStatusRepository.save(ingestionStatus);
        }, () -> ingestionRequestStatusRepository.save(buildIngestionRequestStatus(ingestionRequestEntity, status, totalRecords, successRecords)));
    }

    @VisibleForTesting
    IngestionRequestEntity buildIngestionRequest(IngestionType entityType, String fileId, String fileName) {
        IngestionRequestEntity ingestionRequestEntity = new IngestionRequestEntity();
        ingestionRequestEntity.setFileId(fileId);
        ingestionRequestEntity.setFileName(fileName);
        ingestionRequestEntity.setEntityType(entityType);
        return ingestionRequestEntity;
    }

    @VisibleForTesting
    IngestionRequestStatusEntity buildIngestionRequestStatus(IngestionRequestEntity ingestionRequestEntity, IngestionStatus status, int totalRecords, int successRecords) {
        IngestionRequestStatusEntity ingestionRequestStatusEntity = new IngestionRequestStatusEntity();
        ingestionRequestStatusEntity.setRequestId(ingestionRequestEntity.getRequestId());
        ingestionRequestStatusEntity.setStatus(status);
        if (totalRecords > 0) {
            ingestionRequestStatusEntity.setTotalRecordsCount(totalRecords);
            ingestionRequestStatusEntity.setSuccessRecordsCount(successRecords);
        }
        return ingestionRequestStatusEntity;
    }

    @VisibleForTesting
    IngestionErrorEntity buildIngestionError(IngestionRequestEntity ingestionRequestEntity, FileUploadResponse file, List<ErrorInfo> errors) {
        IngestionErrorEntity ingestionErrorEntity = new IngestionErrorEntity();
        ingestionErrorEntity.setRequestId(ingestionRequestEntity.getRequestId());
        ingestionErrorEntity.setErrorFileId(file.getFileId());
        ingestionErrorEntity.setErrorFileName(file.getFileName());
        ingestionErrorEntity.setErrors(errors);
        ingestionErrorEntity.setErrorRecordsCount(errors.size());
        return ingestionErrorEntity;
    }

}
