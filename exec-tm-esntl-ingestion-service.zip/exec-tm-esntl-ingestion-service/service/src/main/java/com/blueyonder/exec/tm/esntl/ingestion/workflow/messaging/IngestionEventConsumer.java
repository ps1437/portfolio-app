/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.messaging;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionProcessor;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionEventConsumer {

    private final IngestionConfigProperties ingestionConfigProperties;

    private final IngestionProcessor ingestionProcessor;

    @KafkaListener(containerFactory = "${ecom-outbox.subscribers.ltms.factoryBeanName}", topics = "#{ingestionConfigProperties.eventConfig.topicName}")
    public void consume(Message<byte[]> eventMessage) {
        IngestionRequestEntity ingestionRequestEntity = JsonUtils.fromJson(eventMessage.getPayload(), IngestionRequestEntity.class);
        log.info("Received ingestion request event, request id: {}", ingestionRequestEntity.getRequestId());
        ingestionProcessor.process(ingestionRequestEntity);
    }

}
