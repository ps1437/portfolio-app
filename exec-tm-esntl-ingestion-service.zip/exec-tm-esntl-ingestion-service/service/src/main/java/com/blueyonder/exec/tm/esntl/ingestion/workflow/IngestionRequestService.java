/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.blueyonder.exec.ecom.boot.commons.web.error.ConflictAppException;
import com.blueyonder.exec.ecom.boot.commons.web.error.InternalServerAppException;
import com.blueyonder.exec.ecom.boot.commons.web.error.NotFoundAppException;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.messaging.IngestionEventPublisher;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionRequestService {

    private final FileStorageService fileStorageService;

    private final IngestionEntityManager ingestionEntityManager;

    private final IngestionEventPublisher ingestionEventPublisher;

    public IngestionRequestEntity createIngestion(IngestionType entityType, String fileId) {
        log.info("Creating ingestion");
        try {
            var fileQueryResponseModel = fileStorageService.getFileDetails(fileId).block();
            return createIngestionEvent(entityType, fileId, fileQueryResponseModel.getFileName());
        } catch (WebClientResponseException.NotFound e) {
            throw new NotFoundAppException(false, "", "File with id: " + fileId + ", is not found");
        } catch (WebClientRequestException | WebClientResponseException e) {
            throw new InternalServerAppException("", "Unable to reach upload service to retrieve file with id: " + fileId, e);
        } catch (ConflictAppException e) {
            throw e;
        } catch (Exception e) {
            throw new InternalServerAppException("", "Unknown internal error occurred " + fileId, e);
        }
    }

    @Transactional
    public IngestionRequestEntity createIngestionEvent(IngestionType entityType, String fileId, String fileName) {
        IngestionRequestEntity ingestionRequestEntity = ingestionEntityManager.createIngestionRequest(entityType, fileId, fileName);
        ingestionEventPublisher.publish(ingestionRequestEntity);
        return ingestionRequestEntity;
    }

}
