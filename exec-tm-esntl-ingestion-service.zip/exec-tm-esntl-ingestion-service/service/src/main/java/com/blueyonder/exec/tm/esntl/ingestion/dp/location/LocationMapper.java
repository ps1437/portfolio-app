/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.exec.tm.esntl.ingestion.dp.CommunicationChannelUtils;
import com.blueyonder.exec.tm.esntl.ingestion.dp.GeographicalCoordinatesUtils;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.LocationGeographicalCoordinatesType;
import com.blueyonder.plat.dp.bydm.LocationTransportEquipmentRestrictionType;
import com.blueyonder.plat.dp.bydm.LocationType;
import com.blueyonder.plat.dp.bydm.OperatingHours;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = { Arrays.class})
public interface LocationMapper {

    @Mapping(source = "locationType", target = "basicLocation.locationTypeCode")
    @Mapping(source = "locationName", target = "basicLocation.locationName")
    @Mapping(source = "countryCode", target = "basicLocation.address.countryCode")
    @Mapping(source = "city", target = "basicLocation.address.city")
    @Mapping(source = "state", target = "basicLocation.address.state")
    @Mapping(source = "postalCode", target = "basicLocation.address.postalCode")
    @Mapping(source = "streetAddressOne", target = "basicLocation.address.streetAddressOne")
    @Mapping(source = "streetAddressTwo", target = "basicLocation.address.streetAddressTwo")
    @Mapping(source = "streetAddressThree", target = "basicLocation.address.streetAddressThree")
    @Mapping(source = "fixedLoadingTimeHrs", target = "logisticDetails.fixedLoadingDurationInHours")
    @Mapping(source = "minVariableLoadingTimeHrs", target = "logisticDetails.minimumVariableLoadingDurationInHours")
    @Mapping(source = "maxVariableLoadingTimeHrs", target = "logisticDetails.maximumVariableLoadingDurationInHours")
    @Mapping(source = ".", target = "basicLocation.address.geographicalCoordinates", qualifiedByName = "toGeographicalCoordinates")
    @Mapping(source = ".", target = "basicLocation.contact", qualifiedByName = "toContact")
    @Mapping(source = "operationalHrs", target = "basicLocation.operatingHours", qualifiedByName = "mapOperationalHours")
    @Mapping(source = "equipmentRestrictions", target = "logisticDetails.transportEquipmentRestriction")
    @Mapping(expression = "java(null)", target = "avpList")
    LocationType mapToLocationType(LocationEntity location);

    List<LocationType> mapToLocationTypes(List<LocationEntity> location);

    @Mapping(source = "equipmentRestrictionCode", target = "restrictionCode")
    @Mapping(source = "equipmentType", target = "transportEquipmentTypeCode")
    LocationTransportEquipmentRestrictionType mapToTransportEquipmentRestriction(EquipmentRestrictionEntity equipmentRestrictionEntity);

    @Named("toGeographicalCoordinates")
    default LocationGeographicalCoordinatesType mapToLocationGeographicalCoordinates(LocationEntity location) {
        return GeographicalCoordinatesUtils.mapToLocationGeographicalCoordinates(location.getLatitude(), location.getLongitude());
    }

    @Named("mapOperationalHours")
    default OperatingHours mapOperationalHours(OperationalHours operationalHrs) {
        return OperationalHoursHelper.mapToOperatingHours(operationalHrs);
    }

    @Named("toContact")
    default List<LocationContactType> mapCommunicationChannel(LocationEntity location) {
        if (StringUtils.isAllEmpty(location.getEmail(), location.getTelefax(), location.getTelephone(), location.getPersonName(), location.getWebsite())) {
            return Collections.emptyList();
        }
        return CommunicationChannelUtils.getLocationContactTypes(location.getEmail(),
                location.getWebsite(), location.getTelephone(), location.getTelefax(), location.getPersonName());
    }
}
