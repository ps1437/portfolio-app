/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.ErrorInfoModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestStatusEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IngestionRequestStatusMapper {

    @Mapping(source = "status", target = "status", qualifiedByName = "toIngestionStatusModel")
    @Mapping(source = "createdDate", target = "createdDate", qualifiedByName = "toOffsetDateTime", conditionExpression = "java(null != ingestionRequestStatusEntity.getCreatedDate())")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate", qualifiedByName = "toOffsetDateTime", conditionExpression = "java(null != ingestionRequestStatusEntity.getLastModifiedDate())")
    @Mapping(source = "ingestionErrorEntity.errorFileId", target = "errorFileId")
    @Mapping(source = "ingestionErrorEntity.errors", target = "errors", qualifiedByName = "toErrorInfoModelList", conditionExpression = "java(null != ingestionRequestStatusEntity.getIngestionErrorEntity())")
    IngestionRequestStatusModel toIngestionRequestStatusModel(IngestionRequestStatusEntity ingestionRequestStatusEntity);

    @Named("toErrorInfoModelList")
    default List<ErrorInfoModel> toErrorInfoModelList(List<ErrorInfo> errorInfos) {
        /*return errorInfos.stream().map(errorInfo -> {
            var errorInfoModel = new ErrorInfoModel();
            errorInfoModel.setErrorCode(errorInfo.getErrorCode());
            errorInfoModel.setUserMessage(errorInfo.getLocalizedUserMessage());
            return errorInfoModel;
        }).toList();*/
        return Arrays.asList(JsonUtils.fromJson(JsonUtils.toJson(errorInfos), ErrorInfoModel[].class));
    }

    @Named("toIngestionStatusModel")
    default IngestionStatusModel toIngestionStatusModel(IngestionStatus ingestionStatus) {
        return IngestionStatusModel.valueOf(ingestionStatus.name());
    }

    @Named("toOffsetDateTime")
    default OffsetDateTime toOffsetDateTime(Instant instant) {
        return OffsetDateTime.parse(instant.toString());
    }

}
