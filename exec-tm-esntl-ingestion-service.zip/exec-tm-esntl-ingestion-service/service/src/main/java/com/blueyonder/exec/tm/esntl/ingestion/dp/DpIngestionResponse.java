/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.Getter;
import lombok.ToString;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.plat.dp.api.model.v1.ErrorMessageModel;
import com.blueyonder.plat.dp.api.model.v1.EventTypeModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;
import com.google.common.annotations.VisibleForTesting;

@Getter
@ToString(callSuper = true)
public class DpIngestionResponse extends IngestionResponse {

    private static final Pattern PRIMARY_ID_PATTERN = Pattern.compile("\\s+primaryId\\s+([\\w\\s\\d-_]*)[.\\s]+");

    private final IngestionQueryResponseModel ingestionResponseModel;

    public DpIngestionResponse(IngestionRequest ingestionRequest, IngestionQueryResponseModel ingestionResponseModel) {
        super(ingestionRequest, buildErrorResponse(ingestionResponseModel));
        this.ingestionResponseModel = ingestionResponseModel;
    }

    @VisibleForTesting
    static Map<String, List<String>> buildErrorResponse(IngestionQueryResponseModel ingestionResponseModel) {
        return ingestionResponseModel.getEvents().stream()
                .filter(EventTypeModel::isValidationFailed)
                .flatMap(e -> e.getErrors().stream())
                .collect(Collectors.groupingBy(error -> extractPrimaryId(error.getErrorMessage()),
                        Collectors.mapping(ErrorMessageModel::getErrorMessage, Collectors.toList())));
    }

    @VisibleForTesting
    static String extractPrimaryId(String errorMessage) {
        var m = PRIMARY_ID_PATTERN.matcher(errorMessage);
        return m.find() ? m.group(1) : "";
    }

}
