/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.validation;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;

@Getter
@Setter
@ToString
public class ValidationEntity extends IngestionEntity {

    @Column(name = "FIELD")
    private String field;

    @Column(name = "IS_MANDATORY")
    private Boolean mandatory;

    @Column(name = "REGEX_VALIDATION")
    private String regex;
}
