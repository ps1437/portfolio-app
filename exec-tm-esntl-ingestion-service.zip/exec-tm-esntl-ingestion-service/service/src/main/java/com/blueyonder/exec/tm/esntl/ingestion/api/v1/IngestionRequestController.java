/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import lombok.RequiredArgsConstructor;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionEntityManager;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionRequestService;

@RestController
@RequiredArgsConstructor
public class IngestionRequestController implements IngestionRequestApi {

    private final IngestionRequestService ingestionRequestService;

    private final IngestionRequestMapper ingestionRequestMapper;

    private final IngestionRequestStatusMapper ingestionRequestStatusMapper;

    private final IngestionEntityManager ingestionEntityManager;

    @Override
    public ResponseEntity<IngestionRequestModel> createIngestionRequest(IngestionRequestDetailsModel ingestionRequestDetailsModel) {
        var entityType = IngestionType.valueOf(ingestionRequestDetailsModel.getEntityType().name());
        var ingestion = ingestionRequestService.createIngestion(entityType, ingestionRequestDetailsModel.getFileId());
        return ResponseEntity.ok(ingestionRequestMapper.toIngestionRequestModel(ingestion));
    }

    @Override
    public ResponseEntity<Page> getIngestionRequestPage(Integer page, Integer size, String sort, Pageable pageable) {
        return ResponseEntity.ok(ingestionEntityManager.getIngestionRequests(pageable).map(ingestionRequestMapper::toIngestionRequestModel));
    }

    @Override
    public ResponseEntity<IngestionRequestStatusModel> getIngestionRequestStatus(UUID ingestionId) {
        return ResponseEntity.ok(ingestionRequestStatusMapper.toIngestionRequestStatusModel(ingestionEntityManager.getIngestionRequestStatusById(ingestionId)));
    }

    @Override
    public ResponseEntity<Page> getIngestionRequestStatusPage(Integer page, Integer size, String sort, Pageable pageable) {
        return ResponseEntity.ok(ingestionEntityManager.getIngestionRequestStatuses(pageable).map(ingestionRequestStatusMapper::toIngestionRequestStatusModel));
    }

}
