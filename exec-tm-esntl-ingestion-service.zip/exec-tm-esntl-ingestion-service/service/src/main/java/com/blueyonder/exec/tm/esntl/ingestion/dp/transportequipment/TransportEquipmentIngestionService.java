/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpIngestionServiceImpl;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.TransportEquipmentDpClient;
import com.blueyonder.plat.dp.bydm.TransportEquipmentTransportEquipmentType;
import com.blueyonder.plat.lui.api.client.v1.UIConfigurationClient;
import com.fasterxml.jackson.databind.JsonNode;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.CURRENCY;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.LENGTH;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.LTMS;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.UOM;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.WEIGHT;
import static java.util.Objects.requireNonNull;

@Slf4j
@Service
public class TransportEquipmentIngestionService extends DpIngestionServiceImpl {

    private static final IngestionEntitySchema ENTITY_SCHEMA = IngestionEntitySchema.of(TransportEquipmentEntity.class);

    private final TransportEquipmentMapper transportEquipmentMapper;

    private final UIConfigurationClient uiConfigurationClient;

    public TransportEquipmentIngestionService(DpClient dpClient,
            TransportEquipmentDpClient transportEquipmentDpClient,
            DataStorageService dataStorageService,
            PostIngestionService postIngestionService,
            TransportEquipmentMapper transportEquipmentMapper,
            UIConfigurationClient uiConfigurationClient,
            IngestionConfigProperties ingestionConfigProperties) {
        super(dpClient, transportEquipmentDpClient, dataStorageService, postIngestionService, ingestionConfigProperties);
        this.transportEquipmentMapper = requireNonNull(transportEquipmentMapper);
        this.uiConfigurationClient = requireNonNull(uiConfigurationClient);
    }

    @Override
    public IngestionType getType() {
        return IngestionType.TRANSPORT_EQUIPMENT;
    }

    @Override
    public IngestionEntitySchema getEntitySchema() {
        return ENTITY_SCHEMA;
    }

    @Override
    protected List<?> prepareEntitiesToIngest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
        return mapToTransportEquipmentType(rootEntityPage.getValidEntities());
    }

    private List<TransportEquipmentTransportEquipmentType> mapToTransportEquipmentType(List<TransportEquipmentEntity> transportEquipmentEntities) {
        if (!CollectionUtils.isEmpty(transportEquipmentEntities)) {
            JsonNode jsonNode = getUiAppConfiguration().block();
            Map<String, String> unitOfMeasures = populateUOMFromJsonNode(jsonNode);

            return transportEquipmentEntities.stream()
                    .map(equipmentRec -> transportEquipmentMapper.mapToTransportEquipmentType(equipmentRec, unitOfMeasures))
                    .toList();
        }
        return Collections.emptyList();
    }

    private Map<String, String> populateUOMFromJsonNode(JsonNode jsonNode) {
        Map<String, String> unitOfMeasures = new HashMap<>();
        if (Objects.nonNull(jsonNode) && Objects.nonNull(jsonNode.get(UOM))) {
            unitOfMeasures.put(WEIGHT, jsonNode.get(UOM).get(WEIGHT).textValue());
            unitOfMeasures.put(LENGTH, jsonNode.get(UOM).get(LENGTH).textValue());
            unitOfMeasures.put(CURRENCY, jsonNode.get(UOM).get(CURRENCY).textValue());
        }
        return unitOfMeasures;
    }

    private Mono<JsonNode> getUiAppConfiguration() {
        log.info("Inside getUiAppConfiguration");
        return uiConfigurationClient.getTenantPreferences()
                .filter(preferenceResponseModel -> Objects.nonNull(preferenceResponseModel.getRealm()))
                .map(preferenceResponseModel -> preferenceResponseModel.getRealm().get(LTMS));
    }
}
