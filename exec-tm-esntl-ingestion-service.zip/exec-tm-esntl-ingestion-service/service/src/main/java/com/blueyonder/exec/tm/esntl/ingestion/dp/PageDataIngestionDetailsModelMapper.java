package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageDataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageableModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.SortModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PageDataIngestionDetailsModelMapper {

    public static PageDataIngestionDetailsModel mapToPageDataIngestionDetailsModel(Pageable pageable, Page<DataIngestionDetails> dataIngestionDetails) {
        PageDataIngestionDetailsModel pageDataIngestionDetailsModel = new PageDataIngestionDetailsModel();
        pageDataIngestionDetailsModel.setTotalPages(dataIngestionDetails.getTotalPages());
        pageDataIngestionDetailsModel.setSize(dataIngestionDetails.getSize());
        pageDataIngestionDetailsModel.setNumber(dataIngestionDetails.getNumber());
        SortModel sortModel = new SortModel();
        sortModel.setSorted(dataIngestionDetails.getSort().isSorted());
        sortModel.setUnsorted(dataIngestionDetails.getSort().isUnsorted());
        sortModel.setEmpty(dataIngestionDetails.getSort().isEmpty());
        pageDataIngestionDetailsModel.setSort(sortModel);
        pageDataIngestionDetailsModel.setNumberOfElements(dataIngestionDetails.getNumberOfElements());
        pageDataIngestionDetailsModel.setFirst(dataIngestionDetails.isFirst());
        pageDataIngestionDetailsModel.setLast(dataIngestionDetails.isLast());
        PageableModel pageableModel = new PageableModel();
        pageableModel.setPaged(pageable.isPaged());
        pageableModel.setOffset(pageable.getOffset());
        pageableModel.setPageNumber(pageable.getPageNumber());
        pageableModel.paged(pageable.isPaged());
        pageableModel.unpaged(pageable.isUnpaged());
        pageableModel.setPageSize(pageable.getPageSize());
        pageDataIngestionDetailsModel.setPageable(pageableModel);
        pageDataIngestionDetailsModel.setTotalElements(dataIngestionDetails.getTotalElements());
        return pageDataIngestionDetailsModel;
    }
}
