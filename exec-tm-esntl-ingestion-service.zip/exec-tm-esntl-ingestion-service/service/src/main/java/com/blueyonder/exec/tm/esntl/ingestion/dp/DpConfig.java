/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.RequiredArgsConstructor;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.blueyonder.plat.dp.api.client.DpClientConfig;
import com.blueyonder.plat.dp.api.client.v1.CommodityDpClient;
import com.blueyonder.plat.dp.api.client.v1.CommonDpClient;
import com.blueyonder.plat.dp.api.client.v1.LocationDpClient;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;
import com.blueyonder.plat.dp.api.client.v1.ShipmentDpClient;
import com.blueyonder.plat.dp.api.client.v1.TransportEquipmentDpClient;
import com.blueyonder.plat.dp.api.client.v1.ZoneDpClient;
import com.blueyonder.service.common.liam.testing.LiamAuthClientConfig;

@Configuration
@EnableConfigurationProperties({ DpConfig.DpConfigProperties.class })
@Import({ DpClientConfig.class, LiamAuthClientConfig.class })
@RequiredArgsConstructor
public class DpConfig {

    private final DpClientConfig dpClientConfig;

    @Bean
    public CommonDpClient commonDpClient() {
        return new CommonDpClient(dpClientConfig.dpWebClient());
    }

    @Bean
    public LocationDpClient locationDpClient() {
        return new LocationDpClient(dpClientConfig.dpWebClient());
    }

    @Bean
    public PartyDpClient partyDpClient() {
        return new PartyDpClient(dpClientConfig.dpWebClient());
    }

    @Bean
    public ShipmentDpClient shipmentDpClient() {
        return new ShipmentDpClient(dpClientConfig.dpWebClient());
    }

    @Bean
    public CommodityDpClient commodityDpClient() {
        return new CommodityDpClient(dpClientConfig.dpWebClient());
    }

    @Bean
    public ZoneDpClient zoneDpClient() {
        return new ZoneDpClient(dpClientConfig.dpWebClient());
    }

    @Bean
    public TransportEquipmentDpClient equipmentDpClient() {
        return new TransportEquipmentDpClient(dpClientConfig.dpWebClient());
    }

    @ConfigurationProperties("web-client.data-platform")
    static class DpConfigProperties extends DpClientConfig.DpConfigProperties {

    }
}
