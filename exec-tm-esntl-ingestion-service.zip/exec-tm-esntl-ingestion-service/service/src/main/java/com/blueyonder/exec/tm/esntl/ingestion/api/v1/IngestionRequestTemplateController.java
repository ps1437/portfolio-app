/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import lombok.RequiredArgsConstructor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.blueyonder.exec.ecom.boot.commons.web.error.BadRequestAppException;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.TemplateService;

@RestController
@RequiredArgsConstructor
public class IngestionRequestTemplateController implements IngestionRequestTemplateApi {

    private final TemplateService templateService;

    @Override
    public ResponseEntity<List<EntityTypeModel>> getSupportedEntityTypes() {
        return ResponseEntity.ok(Arrays.asList(EntityTypeModel.values()));
    }

    @Override
    public ResponseEntity<Resource> getUploadTemplates(@NotNull @Valid Set<TemplateTypeModel> requiredTemplates) {
        if (requiredTemplates.isEmpty()) {
            throw new BadRequestAppException(false, "invalid.template.types", "Required templates cannot be Empty");
        }
        try {
            List<Resource> resources = templateService.getResources(requiredTemplates.stream().map(templateTypeModel -> templateTypeModel.getValue()).toList());
            if (1 == resources.size()) {
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + resources.get(0).getFilename())
                        .header(HttpHeaders.CONTENT_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                        .body(resources.get(0));
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            templateService.zipResources(resources, baos);
            ByteArrayResource resource = new ByteArrayResource(baos.toByteArray());
            try {
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=templates.zip")
                        .header(HttpHeaders.CONTENT_TYPE, "application/zip")
                        .body(resource);

            } finally {
                baos.close();
            }
        } catch (IOException e) {
            throw new BadRequestAppException(false, "invalid.template.types", "Invalid template types provided. " + requiredTemplates);
        }
    }

}
