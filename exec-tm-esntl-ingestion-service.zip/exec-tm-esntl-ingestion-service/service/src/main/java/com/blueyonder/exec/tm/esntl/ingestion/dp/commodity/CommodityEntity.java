/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.commodity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.fasterxml.jackson.annotation.JsonInclude;

@AllArgsConstructor
@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity(name = "Commodity")
public class CommodityEntity extends IngestionEntity {

    @Id
    @Column(name = "COMMODITY_ID")
    private String commodityId;

    @Column(name = "FREIGHT_CLASS_CODE")
    private String freightClassCode;

    @Column(name = "IS_DANGEROUS_SUBSTANCE")
    private Boolean isDangerousSubstance;

    @Column(name = "DESCRIPTION")
    private String value;
}
