/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import com.blueyonder.exec.ecom.boot.commons.data.dao.AuditableEntity;
import com.blueyonder.exec.ecom.boot.commons.data.dao.hibernate.SequentialUUIDGenerator;

@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString
@Entity
@Table(name = "ingestion_metadata")
public class DataIngestionDetails extends AuditableEntity {

    @Id
    @GenericGenerator(name = SequentialUUIDGenerator.ID, strategy = SequentialUUIDGenerator.CLASS_NAME)
    @GeneratedValue(generator = SequentialUUIDGenerator.ID)
    @Type(type = "uuid-char")
    @Column(name = "id", updatable = false, nullable = false)
    @EqualsAndHashCode.Include
    private UUID id;

    @Column(name = "entity_type", nullable = false)
    private String entityType;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "start_date_time", nullable = false)
    private OffsetDateTime startDateTime;

    @Column(name = "end_date_time")
    private OffsetDateTime endDateTime;

    @Column(name = "total_records")
    private int totalRecords;

    @Column(name = "total_success_records")
    private int totalSuccessRecords;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "error_records_file_name")
    private String errorRecordsFileName;

    @Column(name = "error_records_file_id")
    private String errorRecordsFileId;
}
