/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import org.springframework.util.NumberUtils;

import static java.util.Objects.requireNonNull;

class StringToNumberConverter<T extends Number> implements DataConverter<T> {

    private final Class<T> type;

    StringToNumberConverter(Class<T> type) {
        this.type = requireNonNull(type);
    }

    @Override
    public T convert(String value) {
        return NumberUtils.parseNumber(value, type);
    }
}
