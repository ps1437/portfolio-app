/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

class StringToOffsetDateTimeConverter implements DataConverter<OffsetDateTime> {

    // yyyy-MM-dd'T'HH:mm:ss
    private static final int LOCAL_DATE_TIME_LENGTH = 19;

    @Override
    public OffsetDateTime convert(String value) {
        return LOCAL_DATE_TIME_LENGTH == value.length() ?
                OffsetDateTime.of(LocalDateTime.parse(value), ZoneOffset.UTC) :
                OffsetDateTime.parse(value, DateTimeFormatter.ISO_DATE_TIME);
    }
}
