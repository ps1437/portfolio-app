/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.blueyonder.exec.ecom.boot.commons.web.error.BadRequestAppException;
import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionFactory;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionSourceFactory;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.TemplateService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

import static java.util.stream.Collectors.toMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class FileProcessService {

    private static final String LTMS_INGESTION_INVALID_FILE = "ltms.ingestion.invalidFile";

    private final TemplateService templateService;

    private final HttpServletResponse response;

    private final IngestionFactory ingestionFactory;

    private final IngestionSourceFactory ingestionSourceFactory;

    /**
     * @deprecated
     * @param file
     * @param ingestionType
     * @return
     */
    @Deprecated
    public DataIngestionDetails process(MultipartFile file, IngestionType ingestionType) {
        if (file.isEmpty()) {
            throw new BadRequestAppException(false, LTMS_INGESTION_INVALID_FILE, "Invalid ingestion file");
        }

        try {
            IngestionService ingestionService = ingestionFactory.getIngestionService(ingestionType);
            IngestionRequest ingestionRequest = readIngestionRequest(file, ingestionService);
            return ingestionService.ingest(ingestionRequest);
        }
        catch (ResponseErrorMarkerException ex) {
            // TODO: Use *AppException in business layer instead of ResponseErrorMarkerException
            log.error("Exception encountered : FileProcessService.process: ", ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    public Map<String, String> getEntitiesList() {
        return Arrays.stream(TemplateTypeModel.values()).filter(template -> !TemplateTypeModel.ALL.equals(template)).collect(toMap(TemplateTypeModel::getValue, TemplateTypeModel::getValue));
    }

    public void downloadEntityTemplates(Set<TemplateTypeModel> templates) {
        String zipTemplateName = "templates";
        try {
            List<Resource> resources = templateService.getResources(templates.stream().map(templateTypeModel -> templateTypeModel.getValue()).toList());
            if (1 == resources.size()) {
                response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + resources.get(0).getFilename());
                response.setStatus(HttpServletResponse.SC_OK);
                StreamUtils.copy(resources.get(0).getInputStream(), response.getOutputStream());
                response.flushBuffer();
                return;
            }
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, String.format("attachment;filename=%s.zip", zipTemplateName));
            response.setStatus(HttpServletResponse.SC_OK);
            templateService.zipResources(resources, response.getOutputStream());
        }
        catch (IOException exception) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            log.error("Exception encountered :FileProcessService.downloadEntityTemplates ", exception);
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    String.format("Invalid entity type %s ", templates)
            );
        }
    }

    private IngestionRequest readIngestionRequest(MultipartFile file, IngestionService ingestionService) {
        String filename = file.getOriginalFilename();
        var reader = ingestionSourceFactory.newIngestionRequestReader(filename, ingestionService);

        IngestionRequest ingestionRequest;
        try {
            ingestionRequest = reader.read(file.getInputStream());
        }
        catch (IOException e) {
            log.error("Failed read ingestion request {filename={}}", filename, e);
            throw new BadRequestAppException(false, LTMS_INGESTION_INVALID_FILE, "Invalid ingestion file " + filename, e);
        }

        if (ingestionRequest.isEmpty()) {
            log.debug("Empty ingestion request {filename={}}", filename);
            throw new BadRequestAppException(false, LTMS_INGESTION_INVALID_FILE, "Invalid ingestion file " + filename);
        }

        return ingestionRequest;
    }

}
