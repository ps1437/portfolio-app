/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;
import com.blueyonder.plat.dp.api.model.query.Query;
import com.blueyonder.plat.dp.bydm.PartyRoleCode;
import com.blueyonder.plat.dp.bydm.PartyType;

@Service
@RequiredArgsConstructor
public class ShipmentPartyDnfService implements ShipmentDnfService {

    private final PartyDpClient partyDpClient;

    @Override
    public void denormalizeShipments(List<ShipmentEntity> shipments) {
        Map<Integer, String> rowNumberWithBuyerIds = retrieveBuyerIdsWithRowNumberFromShipment(shipments);
        List<String> buyerIds = new ArrayList<>(rowNumberWithBuyerIds.values());
        if (!CollectionUtils.isEmpty(rowNumberWithBuyerIds.values())) {
            Map<String, String> partyIdWithBillToIdMap = populatePartyBillToId(buyerIds);
            shipments.stream()
                    .filter(shipment -> rowNumberWithBuyerIds.containsKey(shipment.getMetadata().getRowNumber()))
                    .forEach(shipment -> {
                        if (partyIdWithBillToIdMap.containsKey(shipment.getCustomerId())) {
                            shipment.setBillTo(partyIdWithBillToIdMap.get(shipment.getCustomerId()));
                        }
                        else {
                            shipment.setBillTo(shipment.getCustomerId());
                        }
                    });
        }
    }

    private Map<Integer, String> retrieveBuyerIdsWithRowNumberFromShipment(List<ShipmentEntity> shipments) {
        return shipments.stream()
                .filter(shipment -> (StringUtils.isBlank(shipment.getBillTo()) && StringUtils.isNotBlank(shipment.getCustomerId())))
                .collect(Collectors.toMap(e -> e.getMetadata().getRowNumber(), ShipmentEntity::getCustomerId));
    }

    public Map<String, String> populatePartyBillToId(List<String> buyerIds) {
        List<PartyType> partyTypes = queryParty(buyerIds).block();
        if (CollectionUtils.isEmpty(partyTypes)) {
            return Collections.emptyMap();
        }
        return partyTypes
                .stream()
                .collect(Collectors.toMap(PartyType::getPartyId, this::getBillToId));
    }

    private Mono<List<PartyType>> queryParty(List<String> buyerIds) {
        Query query = Query.builder().and()
                .eq("basicParty.partyRole", PartyRoleCode.CUSTOMER.value())
                .in("partyId", buyerIds)
                .includeSourceFields("basicParty.financialInformation.billTo.primaryId", "partyId")
                .excludeSourceFields("meta.*", "customerDetails.*").build();
        return partyDpClient.getByQuery(query);
    }

    private String getBillToId(PartyType partyType) {
        if (Objects.nonNull(partyType) && Objects.nonNull(partyType.getBasicParty()) &&
                Objects.nonNull(partyType.getBasicParty().getFinancialInformation())
                && Objects.nonNull(partyType.getBasicParty().getFinancialInformation().getBillTo())) {
            return partyType.getBasicParty().getFinancialInformation().getBillTo().getPrimaryId();
        }
        return StringUtils.EMPTY;
    }
}
