/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;

@Component
public class WebMvcConfigurerImpl implements WebMvcConfigurer {

    @Override
    public void addFormatters(FormatterRegistry registry) {
        // Used by upload API to convert query parameter into Enum EntityTypeModel
        registry.addConverter(new StringToEntityTypeModelConverter());
        registry.addConverter(new StringToTemplateTypeModelConverter());
    }

    // Explicit class definition to let spring find out about generics parameter of this converter.
    static class StringToEntityTypeModelConverter implements Converter<String, EntityTypeModel> {
        @Override
        public EntityTypeModel convert(String source) {
            return EntityTypeModel.fromValue(source);
        }
    }

    static class StringToTemplateTypeModelConverter implements Converter<String, TemplateTypeModel> {
        @Override
        public TemplateTypeModel convert(String source) {
            return TemplateTypeModel.fromValue(source);
        }
    }
}
