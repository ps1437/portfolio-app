/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.compress.utils.FileNameUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadRequest;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileStorageService;
import com.google.common.annotations.VisibleForTesting;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.TenancyContextUtils.runWithContext;

@Slf4j
@Service
@RequiredArgsConstructor
public class PostIngestionService {

    private final DataStorageService dataStorageService;

    private final IngestionSourceFactory ingestionSourceFactory;

    private final FileStorageService fileStorageService;

    private final IngestionEntityManager ingestionEntityManager;

    public void processIngestion(IngestionResponse ingestionResponse) {
        UUID requestId = ingestionResponse.getIngestionRequest().getRequestId();

        IngestionRequestPage rootEntityPage = ingestionResponse.getIngestionRequest().getFirstRequestPage();
        List<IngestionEntity> entities = rootEntityPage.getEntities();
        int totalRecordsCount = entities.size();

        if (!rootEntityPage.hasError() && ingestionResponse.getErrorResponse().isEmpty()) {
            dataStorageService.updateErrorFileDetails(requestId, IngestionStatus.COMPLETED, totalRecordsCount);
            ingestionEntityManager.updateStatus(requestId, IngestionStatus.COMPLETED, totalRecordsCount, totalRecordsCount);
        }
        else {
            int dpErrorCount = invalidateEntities(rootEntityPage, ingestionResponse.getErrorResponse());
            int errorRecordsCount = dpErrorCount + rootEntityPage.getInvalidEntities().size();
            int successRecordsCount = totalRecordsCount - errorRecordsCount;

            runWithContext(writeIngestionErrorAndUpload(ingestionResponse.getIngestionRequest()))
                    .doOnNext(fileUploadResponse -> {
                        dataStorageService.updateErrorFileDetails(requestId, totalRecordsCount, fileUploadResponse, successRecordsCount);
                        ingestionEntityManager.updateStatus(requestId, IngestionStatus.COMPLETED_WITH_ERRORS, totalRecordsCount, successRecordsCount);
                        ingestionEntityManager.createIngestionError(requestId, fileUploadResponse, buildErrorInfo(ingestionResponse.getErrorResponse()));
                    })
                    .subscribe();
        }
    }

    //TODO simplify ingestion response to avoid multiple back and forth conversions of error messages
    private List<ErrorInfo> buildErrorInfo(Map<String, List<String>> errorResponse) {
        return errorResponse.entrySet().stream()
                .flatMap(entry -> entry.getValue().stream())
                .map(errorMessage -> new ErrorInfo("by.dp.validation.error", errorMessage))
                .toList();
    }

    private int invalidateEntities(IngestionRequestPage requestPage, Map<String, List<String>> errorResponse) {
        int count = 0;
        for (IngestionEntity entity : requestPage.getValidEntities()) {
            List<String> errors = errorResponse.get(entity.getMetadata().normalizedReferenceId());
            if (!CollectionUtils.isEmpty(errors)) {
                entity.getMetadata().addErrorMessages(errors);
                var childEntityDefs = requestPage.getRequestEntityDef()
                        .getEntityDef().getChildEntityDefs();
                if (null != childEntityDefs) {
                    invalidateChildEntities(requestPage, entity);
                }
                ++count;
            }
        }
        return count;
    }

    @SuppressWarnings("unchecked")
    private void invalidateChildEntities(IngestionRequestPage requestPage, IngestionEntity parentEntity) {
        var childEntityDefs = requestPage.getRequestEntityDef()
                .getEntityDef().getChildEntityDefs();
        if (null != childEntityDefs) {
            for (var def : childEntityDefs) {
                List<IngestionEntity> childEntities = null;
                try {
                    childEntities = (List<IngestionEntity>) def.getField().get(parentEntity);
                }
                catch (Exception ex) {
                    ReflectionUtils.handleReflectionException(ex);
                }
                if (null != childEntities) {
                    for (var child : childEntities) {
                        if (!child.getMetadata().hasError()) {
                            child.getMetadata().addErrorMessage(String.format(
                                    "Parent entity has error {joinColumn=%s, joinId=%s}",
                                    def.getName(), child.getMetadata().getReferenceId()));
                        }
                    }
                }
            }
        }
    }

    @VisibleForTesting
    Flux<FileUploadResponse> writeIngestionErrorAndUpload(IngestionRequest ingestionRequest) {
        log.info("Creating ingestion error file");
        byte[] fileContent = ingestionSourceFactory.newIngestionErrorWriter(ingestionRequest).writeBytes();
        String extension = FileNameUtils.getExtension(ingestionRequest.getSourceName());
        String errorFilename = FileNameUtils.getBaseName(ingestionRequest.getSourceName()) + "_ERROR." + extension;
        return fileStorageService.uploadFile(new FileUploadRequest(errorFilename, fileContent, extension));
    }

}
