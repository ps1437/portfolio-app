/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.zone;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.plat.dp.bydm.GeographyStateType;
import com.blueyonder.plat.dp.bydm.ZoneType;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ZoneMapper {

    @Mapping(source = "geographicAreas", target = "geographicArea")
    ZoneType mapToZoneType(ZoneEntity zone);

    List<ZoneType> mapToZoneTypes(List<ZoneEntity> zones);

    @Mapping(source = "postalCode", target = "fromPostalCode")
    @Mapping(source = "postalCode", target = "toPostalCode")
    GeographyStateType mapToGeographicArea(GeographicAreaEntity geographicArea);
}
