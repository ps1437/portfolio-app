/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;

import javax.persistence.Id;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;
import com.blueyonder.plat.dp.bydm.CountryCode;

@Getter
@Setter
@ToString
@Entity(name = "Shipment")
public class ShipmentEntity extends IngestionEntity {

    @Id
    @Column(name = "SHIPMENT_SEQ_NO", alias = "S. No.")
    private String shipmentNumber;

    @Column(name = "SHIPMENT_TYPE")
    private ShipmentType shipmentType;

    @Column(name = "SHIPMENT_REFERENCE_ID")
    private String shipmentReferenceId;

    @Column(name = "REFERENCE_NUMBER_TYPE")
    private String referenceNumberType;

    @Column(name = "REFERENCE_NUMBER")
    private String referenceNumber;

    @Column(name = "CUSTOMER_ID")
    private String customerId;

    @Column(name = "FREIGHT_TERMS")
    private FreightTerms freightTerms;

    @Column(name = "BILL_TO")
    private String billTo;

    @Column(name = "REQUIRED_CARRIER")
    private String requiredCarrier;

    @Column(name = "REQUIRED_SERVICE")
    private String requiredService;

    @Column(name = "ORIGIN_LOCATION")
    private String originLocation;

    @Column(name = "ORIGIN_COUNTRY_CODE")
    private CountryCode originCountryCode;

    @Column(name = "ORIGIN_STATE")
    private String originState;

    @Column(name = "ORIGIN_CITY")
    private String originCity;

    @Column(name = "ORIGIN_STREET_ADDRESS_ONE")
    private String originStreetAddressOne;

    @Column(name = "ORIGIN_STREET_ADDRESS_TWO")
    private String originStreetAddressTwo;

    @Column(name = "ORIGIN_STREET_ADDRESS_THREE")
    private String originStreetAddressThree;

    @Column(name = "ORIGIN_POSTAL_CODE")
    private String originPostalCode;

    @Column(name = "ORIGIN_LATITUDE")
    private String originLatitude;

    @Column(name = "ORIGIN_LONGITUDE")
    private String originLongitude;

    @Column(name = "ORIGIN_EMAIL")
    private String originEmail;

    @Column(name = "ORIGIN_TELEFAX")
    private String originTelefax;

    @Column(name = "ORIGIN_TELEPHONE")
    private String originTelephone;

    @Column(name = "ORIGIN_WEBSITE")
    private String originWebsite;

    @Column(name = "ORIGIN_CONTACT_NAME")
    private String originContactName;

    @Column(name = "ORIGIN_COMPANY_NAME")
    private String originCompanyName;

    @Column(name = "DESTINATION_LOCATION")
    private String destinationLocation;

    @Column(name = "DESTINATION_COUNTRY_CODE")
    private CountryCode destinationCountryCode;

    @Column(name = "DESTINATION_STATE")
    private String destinationState;

    @Column(name = "DESTINATION_CITY")
    private String destinationCity;

    @Column(name = "DESTINATION_STREET_ADDRESS_ONE")
    private String destinationStreetAddressOne;

    @Column(name = "DESTINATION_STREET_ADDRESS_TWO")
    private String destinationStreetAddressTwo;

    @Column(name = "DESTINATION_STREET_ADDRESS_THREE")
    private String destinationStreetAddressThree;

    @Column(name = "DESTINATION_POSTAL_CODE")
    private String destinationPostalCode;

    @Column(name = "DESTINATION_LATITUDE")
    private String destinationLatitude;

    @Column(name = "DESTINATION_LONGITUDE")
    private String destinationLongitude;

    @Column(name = "DESTINATION_EMAIL")
    private String destinationEmail;

    @Column(name = "DESTINATION_TELEFAX")
    private String destinationTelefax;

    @Column(name = "DESTINATION_TELEPHONE")
    private String destinationTelephone;

    @Column(name = "DESTINATION_WEBSITE")
    private String destinationWebsite;

    @Column(name = "DESTINATION_CONTACT_NAME")
    private String destinationContactName;

    @Column(name = "DESTINATION_COMPANY_NAME")
    private String destinationCompanyName;

    @Column(name = "REQUESTED_PICKUP_BEGIN_DATETIME")
    private OffsetDateTime plannedBeginDateTime;

    @Column(name = "REQUESTED_PICKUP_END_DATETIME")
    private OffsetDateTime plannedEndDateTime;

    @Column(name = "REQUESTED_DELIVERY_BEGIN_DATETIME")
    private OffsetDateTime dispatchBeginDateTime;

    @Column(name = "REQUESTED_DELIVERY_END_DATETIME")
    private OffsetDateTime dispatchEndDateTime;

    private String originLocationName;

    private String destinationLocationName;

    @OneToMany(joinColumnName = "SHIPMENT_SEQ_NO")
    private List<ShipmentLogisticUnit> logisticUnits;

    @Override
    public void postConstruct() {
        validateLocationDetails();
        validateBeginDateTime();
    }

    private void validateLocationDetails() {
        boolean blankOriginLocation = StringUtils.isBlank(originLocation);
        if (!blankOriginLocation && originLocation.equals(destinationLocation)) {
            metadata.addErrorMessage("Origin locationId can't be same as destination locationId.");
        }
        if (blankOriginLocation && (null == originCountryCode || StringUtils.isAnyBlank(originState, originCity, originPostalCode))) {
            metadata.addErrorMessage("Origin location or address (country, state, city and zip code) is mandatory.");
        }
        if (StringUtils.isBlank(destinationLocation) && (null == destinationCountryCode || StringUtils.isAnyBlank(destinationState, destinationCity, destinationPostalCode))) {
            metadata.addErrorMessage("Destination location or address (country, state, city and zip code) is mandatory.");
        }
    }

    private void validateBeginDateTime() {
        if (Objects.nonNull(plannedBeginDateTime) && Objects.nonNull(dispatchBeginDateTime) && plannedBeginDateTime.isAfter(dispatchBeginDateTime)) {
            metadata.addErrorMessage("Pickup begin date time should be less than delivery begin date time.");
        }
    }

    @Override
    public void postGraphConstruct() {
        if (CollectionUtils.isEmpty(logisticUnits)) {
            metadata.addErrorMessage("No Logistic Unit is associated with this shipment.");
        }
    }
}
