/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel;

import lombok.RequiredArgsConstructor;

import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntityMetadata;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionErrorWriter;

@RequiredArgsConstructor
public class ExcelIngestionErrorWriter implements IngestionErrorWriter {

    private final IngestionRequest request;

    private Workbook workbook;

    public void write(OutputStream output) throws IOException {
        workbook = new XSSFWorkbook();
        try {
            request.getRequestPages().values().forEach(this::writeErrorPage);
            try (output) {
                workbook.write(output);
            }
        }
        finally {
            IOUtils.closeQuietly(workbook);
        }
    }

    private void writeErrorPage(IngestionRequestPage page) {
        Sheet sheet = workbook.createSheet(page.getName());
        writePageHeader(page, sheet);

        int rownum = 1;
        for (IngestionEntity e : page.getEntities()) {
            IngestionEntityMetadata metadata = e.getMetadata();
            if (metadata.hasError()) {
                Row row = sheet.createRow(rownum++);
                int cellnum = 0;
                for (String s : metadata.getRow()) {
                    row.createCell(cellnum++).setCellValue(s);
                }
                for (String s : metadata.getErrorMessages()) {
                    row.createCell(cellnum++).setCellValue(s);
                }
            }
        }
    }

    private void writePageHeader(IngestionRequestPage page, Sheet sheet) {
        int cellnum = 0;
        Row row = sheet.createRow(0);
        for (String s : page.getColumnNames()) {
            row.createCell(cellnum++).setCellValue(s);
        }
        if (page.getEntities().size() > 0) {
            row.createCell(cellnum).setCellValue(IngestionServiceConstants.ERROR_MESSAGE);
        }
    }
}
