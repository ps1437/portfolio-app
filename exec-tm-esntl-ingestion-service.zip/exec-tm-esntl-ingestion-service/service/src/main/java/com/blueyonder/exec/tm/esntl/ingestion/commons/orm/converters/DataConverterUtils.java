/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.Map;

import org.springframework.util.ConcurrentReferenceHashMap;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DataConverterUtils {

    private static final NoOpConverter NOOP = new NoOpConverter();

    private static final Map<Class<?>, DataConverter<?>> CONVERTERS_CACHE = new ConcurrentReferenceHashMap<>();

    public static DataConverter<?> getDataConverter(Class<?> type) {
        return getDataConverter(type, NOOP);
    }

    @SuppressWarnings("unchecked")
    public static DataConverter<?> getDataConverter(Class<?> type, DataConverter<?> defaultConverter) {
        var converter = CONVERTERS_CACHE.get(type);
        if (null != converter) {
            return converter;
        }

        if (type == String.class) {
            return CONVERTERS_CACHE.computeIfAbsent(type, (key) -> NOOP);
        }
        if (type == Boolean.class) {
            return CONVERTERS_CACHE.computeIfAbsent(type, (key) -> new StringToBooleanConverter());
        }
        if (Number.class.isAssignableFrom(type)) {
            return CONVERTERS_CACHE.computeIfAbsent(type, (key) -> new StringToNumberConverter<>((Class<Number>) type));
        }
        if (type == LocalTime.class) {
            return CONVERTERS_CACHE.computeIfAbsent(type, (key) -> new StringToLocalTimeConverter());
        }
        if (type.isEnum()) {
            return CONVERTERS_CACHE.computeIfAbsent(type, (key) -> {
                Class<Enum<?>> t = (Class<Enum<?>>) type;
                var enumConverter = new StringToEnumFromValueConverter<>(t);
                return enumConverter.isValid() ? enumConverter : new StringToEnumConverter<>(t);
            });
        }
        if (type == OffsetDateTime.class) {
            return CONVERTERS_CACHE.computeIfAbsent(type, (key) -> new StringToOffsetDateTimeConverter());
        }

        return defaultConverter;
    }
}
