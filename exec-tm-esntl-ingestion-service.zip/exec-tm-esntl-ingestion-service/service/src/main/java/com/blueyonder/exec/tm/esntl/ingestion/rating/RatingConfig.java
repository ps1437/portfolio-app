/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
@EnableConfigurationProperties({ RatingConfig.RatingConfigProperties.class })
@RequiredArgsConstructor
public class RatingConfig {

    private final WebClient.Builder webClientBuilder;

    private final RatingConfigProperties ratingConfigProperties;

    @Bean
    public WebClient ratingWebClient() {
        return webClientBuilder.clone()
                .baseUrl(ratingConfigProperties.getBaseUrl())
                .build();
    }

    @Bean
    public RatingClient rateClient() {
        return new RatingClient(ratingWebClient());
    }

    @Getter
    @Setter
    @ConfigurationProperties("web-client.rating-service")
    public static class RatingConfigProperties {
        private String baseUrl;
    }
}
