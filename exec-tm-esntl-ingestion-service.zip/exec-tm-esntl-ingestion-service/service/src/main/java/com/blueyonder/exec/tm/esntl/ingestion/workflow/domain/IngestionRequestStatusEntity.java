/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.blueyonder.exec.ecom.boot.commons.data.dao.AuditableEntity;

@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString
@Entity
@Table(name = "ingestion_request_status")
public class IngestionRequestStatusEntity extends AuditableEntity {

    @Id
    @Type(type = "uuid-char")
    @Column(name = "request_id", updatable = false, nullable = false)
    @EqualsAndHashCode.Include
    private UUID requestId;

    @Column(name = "status", nullable = false)
    private IngestionStatus status;

    @Column(name = "processing_start_date", nullable = true)
    private OffsetDateTime processingStartDate;

    @Column(name = "processing_end_date", nullable = true)
    private OffsetDateTime processingEndDate;

    @Column(name = "total_records_count")
    private int totalRecordsCount;

    @Column(name = "success_records_count")
    private int successRecordsCount;

    @OneToOne(mappedBy = "ingestionRequestStatusEntity", cascade = CascadeType.ALL)
    private IngestionErrorEntity ingestionErrorEntity;

}
