package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ServiceLevelCodeModel;
import com.blueyonder.plat.dp.bydm.EcomStringAttributeValuePairListType;

@Getter
@Setter
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ServiceDetail {

    @EqualsAndHashCode.Include
    private ServiceLevelCodeModel serviceLevelCode;

    private String carrierType;

    private CarrierDetailsCharacteristics carrierDetailsCharacteristics;

    private List<EcomStringAttributeValuePairListType> avpList;
}
