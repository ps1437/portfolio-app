/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import org.apache.commons.compress.utils.FileNameUtils;
import org.springframework.stereotype.Component;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionSourceType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel.ExcelIngestionErrorWriter;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel.ExcelIngestionRequestReader;

@Component
public class IngestionSourceFactory {

    public IngestionRequestReader newIngestionRequestReader(String filename, IngestionService ingestionService) {
        return newIngestionRequestReader(IngestionSourceType.fromValue(FileNameUtils.getExtension(filename),
                ingestionService.getType()), filename, ingestionService.getEntitySchema());
    }

    public IngestionRequestReader newIngestionRequestReader(IngestionSourceType sourceType,
            String sourceName, IngestionEntitySchema entitySchema) {
        if (IngestionSourceType.EXCEL == sourceType) {
            return new ExcelIngestionRequestReader(sourceName, entitySchema);
        }
        throw new IllegalArgumentException("Unsupported ingestion source type " + sourceType);
    }

    public IngestionErrorWriter newIngestionErrorWriter(IngestionRequest request) {
        if (IngestionSourceType.EXCEL == request.getSourceType()) {
            return new ExcelIngestionErrorWriter(request);
        }
        throw new IllegalArgumentException("Unsupported ingestion source type " + request.getSourceType());
    }
}
