package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import java.time.LocalTime;

public class StringToLocalTimeConverter implements DataConverter<LocalTime> {

    @Override
    public LocalTime convert(String value) {
        return LocalTime.parse(value);
    }
}
