/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.lang.reflect.Field;

import static java.util.Objects.requireNonNull;

@Getter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class IngestionEntityJoinColumnDef {

    private final Field field;

    @EqualsAndHashCode.Include
    private final IngestionEntityDef childEntityDef;

    private final String name;

    IngestionEntityJoinColumnDef(String name, Field field, IngestionEntityDef childEntityDef) {
        this.name = requireNonNull(name);
        this.field = requireNonNull(field);
        this.childEntityDef = requireNonNull(childEntityDef);
    }

    @Override
    public String toString() {
        return field.getName() + '(' + name + ", " + childEntityDef.getName() + ')';
    }
}
