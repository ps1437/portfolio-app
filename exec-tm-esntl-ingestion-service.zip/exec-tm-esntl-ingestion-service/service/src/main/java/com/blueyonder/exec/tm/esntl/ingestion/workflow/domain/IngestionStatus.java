/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

public enum IngestionStatus {

    QUEUED,

    PROCESSING,

    COMPLETED,

    COMPLETED_WITH_ERRORS,

    FAILED;

}
