/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;

public class BatchIngestionResponseAggregator {

    private IngestionResponse ingestionResponse;

    public IngestionResponse aggregate(BatchIngestionResponse batchIngestionResponse) {
        if (null == ingestionResponse) {
            ingestionResponse = batchIngestionResponse;
        } else {
            ingestionResponse.getErrorResponse().putAll(batchIngestionResponse.getErrorResponse());
        }
        return ingestionResponse;
    }

}
