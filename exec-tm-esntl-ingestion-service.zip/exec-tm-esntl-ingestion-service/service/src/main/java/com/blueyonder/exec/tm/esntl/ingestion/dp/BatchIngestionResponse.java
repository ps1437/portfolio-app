/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.Getter;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.plat.dp.api.model.EntityErrorResponseModel;
import com.blueyonder.plat.dp.api.model.ErrorMessageTypeModel;
import com.blueyonder.plat.dp.api.model.PostEntityResponseModel;
import com.google.common.annotations.VisibleForTesting;

@Getter
public class BatchIngestionResponse extends IngestionResponse {

    private final UUID batchId;

    private final Integer batchSeq;

    private PostEntityResponseModel postEntityResponseModel;

    private EntityErrorResponseModel entityErrorResponseModel;

    public BatchIngestionResponse(UUID batchId, Integer batchSeq, IngestionRequest ingestionRequest, PostEntityResponseModel postEntityResponseModel) {
        super(ingestionRequest);
        this.batchId = batchId;
        this.batchSeq = batchSeq;
        this.postEntityResponseModel = postEntityResponseModel;
    }

    public BatchIngestionResponse(UUID batchId, Integer batchSeq, IngestionRequest ingestionRequest, EntityErrorResponseModel entityErrorResponseModel) {
        super(ingestionRequest, getEntityToErrorMap(entityErrorResponseModel.getErrors()));
        this.batchId = batchId;
        this.batchSeq = batchSeq;
        this.entityErrorResponseModel = entityErrorResponseModel;
    }

    @VisibleForTesting
    static Map<String, List<String>> getEntityToErrorMap(List<ErrorMessageTypeModel> errorModels) {
        return errorModels.stream()
                .collect(Collectors.groupingBy(error -> DpUtils.extractPrimaryId(error.getUserMessage()),
                        Collectors.mapping(ErrorMessageTypeModel::getUserMessage, Collectors.toList())));
    }

}
