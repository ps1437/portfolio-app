/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.Getter;

@Getter
public enum IngestionErrorCode {

    /**
     * Error code that indicates ingestion request is not
     * found. Requires ingestion request id for message formatting.
     */
    INVALID_INGESTION_REQUEST("error.ingestion.request.not.found", "Ingestion request with id {0} is not found");

    private String errorCode;

    private String defaultMessage;

    IngestionErrorCode(String errorCode, String defaultMessage) {
        this.errorCode = errorCode;
        this.defaultMessage = defaultMessage;
    }

}
