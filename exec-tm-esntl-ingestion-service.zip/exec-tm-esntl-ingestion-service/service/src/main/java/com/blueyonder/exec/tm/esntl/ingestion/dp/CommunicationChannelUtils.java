/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierEntity;
import com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationType;
import com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationTypeCode;
import com.blueyonder.plat.dp.bydm.CommunicationChannelCode;
import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.PartyContactType;

import static com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationTypeCode.BYN_IDENTIFIER;
import static com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationTypeCode.CARRIER_ASSIGNED_NUMBER;
import static com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationTypeCode.SCAC;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CommunicationChannelUtils {

    public static List<LocationContactType> getLocationContactTypes(String email, String website, String telephone, String telefax, String personName) {
        List<LocationContactType> contactTypes = new ArrayList<>();
        LocationContactType contactType = new LocationContactType();
        List<CommunicationChannelType> communicationChannel = getCommunicationChannelTypes(email, website, telephone, telefax);
        contactType.setCommunicationChannel(communicationChannel);
        contactType.setPersonName(personName);
        contactTypes.add(contactType);
        return contactTypes;
    }

    public static List<PartyContactType> getPartyContactTypes(String email, String website, String telephone, String telefax, String personName) {
        List<PartyContactType> contactTypes = new ArrayList<>();
        PartyContactType contactType = new PartyContactType();
        contactType.setCommunicationChannel(getCommunicationChannelTypes(email, website, telephone, telefax));
        contactType.setPersonName(personName);
        contactTypes.add(contactType);
        return contactTypes;
    }

    public static CommunicationChannelType buildCommunicationChannelType(CommunicationChannelCode communicationChannelCode, String communicationChannelCodeValue) {
        CommunicationChannelType communicationChannelType = new CommunicationChannelType();
        communicationChannelType.setCommunicationChannelCode(CommunicationChannelCode.fromValue(communicationChannelCode.value()));
        communicationChannelType.setCommunicationValue(communicationChannelCodeValue);
        return communicationChannelType;
    }

    public static List<AdditionalPartyIdentificationType> getAdditionalPartyIdentificationTypes(CarrierEntity carrier) {
        List<AdditionalPartyIdentificationType> additionalPartyIdentificationTypes = new ArrayList<>();
        if (StringUtils.isNotBlank(carrier.getScac())) {
            additionalPartyIdentificationTypes.add(populateAdditionalPartyIdTypes(SCAC, carrier.getScac()));
        }
        if (StringUtils.isNotBlank(carrier.getCarrierAccountNumber())) {
            additionalPartyIdentificationTypes.add(populateAdditionalPartyIdTypes(CARRIER_ASSIGNED_NUMBER, carrier.getCarrierAccountNumber()));
        }
        if (StringUtils.isNotBlank(carrier.getExternalCarrierCode())) {
            additionalPartyIdentificationTypes.add(populateAdditionalPartyIdTypes(BYN_IDENTIFIER, carrier.getExternalCarrierCode()));
        }
        return additionalPartyIdentificationTypes;
    }

    private static AdditionalPartyIdentificationType populateAdditionalPartyIdTypes(AdditionalPartyIdentificationTypeCode propertyType, String propertyValue) {
        return new AdditionalPartyIdentificationType()
                .withTypeCode(propertyType)
                .withValue(propertyValue);
    }

    public static List<CommunicationChannelType> getCommunicationChannelTypes(String email, String website, String telephone, String telefax) {
        List<CommunicationChannelType> communicationChannel = new ArrayList<>();
        if (StringUtils.isNotEmpty(email)) {
            communicationChannel.add(buildCommunicationChannelType(CommunicationChannelCode.EMAIL, email));
        }
        if (StringUtils.isNotEmpty(website)) {
            communicationChannel.add(buildCommunicationChannelType(CommunicationChannelCode.WEBSITE, website));
        }
        if (StringUtils.isNotEmpty(telephone)) {
            communicationChannel.add(buildCommunicationChannelType(CommunicationChannelCode.TELEPHONE, telephone));
        }
        if (StringUtils.isNotEmpty(telefax)) {
            communicationChannel.add(buildCommunicationChannelType(CommunicationChannelCode.TELEFAX, telefax));
        }
        return communicationChannel;
    }
}
