/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

@Repository
public interface IngestionMetadataRepository extends JpaRepository<DataIngestionDetails, UUID>, JpaSpecificationExecutor<DataIngestionDetails> {

    List<DataIngestionDetails> findByStatus(String status);

}
