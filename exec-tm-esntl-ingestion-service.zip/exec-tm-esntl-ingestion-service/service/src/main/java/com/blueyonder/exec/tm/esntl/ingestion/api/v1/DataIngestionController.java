/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageDataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.MetaDataDetailsService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileProcessService;

@Slf4j
@RequiredArgsConstructor
@RestController
public class DataIngestionController implements DataIngestionControllerApi {

    private final FileProcessService fileProcessService;

    private final MetaDataDetailsService metaDataDetailsService;

    @Override
    public ResponseEntity<DataIngestionDetailsModel> upload(@RequestParam("entityType") EntityTypeModel entityType, @RequestParam("file") MultipartFile multipartFile) {
        IngestionType ingestionType = IngestionType.valueOf(entityType.name());
        return new ResponseEntity<>(DataIngestionDetailsMapper.mapToDataIngestModelDetails(
                fileProcessService.process(multipartFile, ingestionType)), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> downloadEntityTemplate(@NotNull @Valid Set<TemplateTypeModel> templates) {
        if (templates.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "TemplateId cannot be Empty"
            );
        }
        fileProcessService.downloadEntityTemplates(templates);
        return null;
    }

    @Override
    public ResponseEntity<Map<String, String>> getEntitiesList() {
        return new ResponseEntity<>(fileProcessService.getEntitiesList(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<DataIngestionDetailsModel>> getIngestionMetadata() {
        return new ResponseEntity<>(metaDataDetailsService.loadAllIngestionMetaData(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<PageDataIngestionDetailsModel> search(@Valid QueryModel queryModel) {
        return new ResponseEntity<>(metaDataDetailsService.queryIngestionMetaData(queryModel), HttpStatus.OK);
    }
}
