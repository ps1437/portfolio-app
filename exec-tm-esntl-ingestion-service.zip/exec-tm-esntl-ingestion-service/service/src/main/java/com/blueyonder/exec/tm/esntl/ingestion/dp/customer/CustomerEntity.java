/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.customer;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Id;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.plat.dp.bydm.CountryCode;

@Getter
@Setter
@ToString
@Entity(name = "Customer")
public class CustomerEntity extends IngestionEntity {

    @Id
    @Column(name = "CUSTOMER_ID")
    private String customerId;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Column(name = "CUSTOMER_TYPE")
    private String customerType;

    @Column(name = "DEFAULT_BILL_TO_CUSTOMER_CODE")
    private String defaultBillToCustomerCode;

    @Column(name = "COUNTRY_CODE")
    private CountryCode countryCode;

    @Column(name = "STATE")
    private String state;

    @Column(name = "CITY")
    private String city;

    @Column(name = "STREET_ADDRESS_ONE")
    private String streetAddressOne;

    @Column(name = "STREET_ADDRESS_TWO")
    private String streetAddressTwo;

    @Column(name = "STREET_ADDRESS_THREE")
    private String streetAddressThree;

    @Column(name = "POSTAL_CODE")
    private String postalCode;

    @Column(name = "LATITUDE")
    private String latitude;

    @Column(name = "LONGITUDE")
    private String longitude;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "TELEFAX")
    private String telefax;

    @Column(name = "TELEPHONE")
    private String telephone;

    @Column(name = "WEBSITE")
    private String website;

    @Column(name = "CONTACT_PERSON")
    private String personName;
}
