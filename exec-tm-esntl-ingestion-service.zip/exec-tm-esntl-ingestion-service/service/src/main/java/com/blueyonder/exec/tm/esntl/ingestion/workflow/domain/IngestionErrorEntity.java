/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.blueyonder.exec.ecom.boot.commons.data.dao.AuditableEntity;
import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;

@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString
@Entity
@Table(name = "ingestion_error")
public class IngestionErrorEntity extends AuditableEntity {

    @Id
    @Type(type = "uuid-char")
    @Column(name = "request_id", updatable = false, nullable = false)
    @EqualsAndHashCode.Include
    private UUID requestId;

    @Column(name = "error_file_id", updatable = false, nullable = false)
    private String errorFileId;

    @Column(name = "error_file_name", nullable = false)
    private String errorFileName;

    @Column(name = "error_records_count")
    private int errorRecordsCount;

    @Column(name = "errors")
    @Lob
    @Convert(converter = ErrorInfoAttributeConverter.class)
    private List<ErrorInfo> errors;

    @OneToOne
    @JoinColumn(name = "request_id", nullable = false)
    private IngestionRequestStatusEntity ingestionRequestStatusEntity;

}
