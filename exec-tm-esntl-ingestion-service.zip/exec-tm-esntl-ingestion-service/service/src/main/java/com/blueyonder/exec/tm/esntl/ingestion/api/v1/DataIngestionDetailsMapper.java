/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Locale;

import org.springframework.beans.BeanUtils;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DataIngestionDetailsMapper {

    public static DataIngestionDetailsModel mapToDataIngestModelDetails(DataIngestionDetails dataIngestionDetails) {
        DataIngestionDetailsModel dataIngestionDetailsModel = new DataIngestionDetailsModel();
        BeanUtils.copyProperties(dataIngestionDetails, dataIngestionDetailsModel);
        dataIngestionDetailsModel.setEntityType(mapToEntityTypeModel(dataIngestionDetails.getEntityType()));
        dataIngestionDetailsModel.setStatus(IngestionStatusModel.PROCESSING);
        return dataIngestionDetailsModel;
    }

    static String mapToEntityTypeModel(String type) {
        if (null == type) {
            return null;
        }
        try {
            return EntityTypeModel.valueOf(type).getValue();
        }
        catch (Exception e) {
            // Backward compatibility...
            int n = type.indexOf("_EXCEL");
            String s = -1 != n ? type.substring(0, n) : type;
            try {
                return EntityTypeModel.valueOf(s.toUpperCase(Locale.getDefault())).getValue();
            }
            catch (Exception ee) {
                return null;
            }
        }
    }
}
