/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.blueyonder.plat.dp.api.client.v1.LocationDpClient;
import com.blueyonder.plat.dp.api.model.query.Query;
import com.blueyonder.plat.dp.bydm.LocationType;

@Service
@RequiredArgsConstructor
public class ShipmentLocationDnfService implements ShipmentDnfService {

    private final LocationDpClient locationDpClient;

    private final ShipmentLocationTypeMapper shipmentLocationTypeMapper;

    @Override
    public void denormalizeShipments(List<ShipmentEntity> shipments) {
        List<String> locationIds = filterLocationIds(shipments);
        Map<String, LocationType> locationsById = !locationIds.isEmpty() ?
                queryLocationAsMap(locationIds) : Collections.emptyMap();
        shipments.forEach(shipment -> shipmentLocationTypeMapper.mapShipmentAddress(shipment, locationsById));
    }

    private List<String> filterLocationIds(List<ShipmentEntity> shipments) {
        List<String> locationIds = new ArrayList<>();
        shipments.forEach(shipment -> {
            if (StringUtils.isNotEmpty(shipment.getOriginLocation())) {
                locationIds.add(shipment.getOriginLocation());
            }
            if (StringUtils.isNotEmpty(shipment.getDestinationLocation())) {
                locationIds.add(shipment.getDestinationLocation());
            }
        });
        return locationIds;
    }

    public Map<String, LocationType> queryLocationAsMap(List<String> locationIds) {
        List<LocationType> locationTypes = locationDpClient.getByQuery(buildLocationQuery(locationIds)).block();
        if (CollectionUtils.isEmpty(locationTypes)) {
            return Collections.emptyMap();
        }
        return locationTypes.stream().collect(Collectors.toMap(LocationType::getLocationId, entity -> entity));
    }

    public Query buildLocationQuery(List<String> locationIds) {
        return Query
                .builder()
                .in("locationId", locationIds.toArray())
                .includeSourceFields(List.of(
                        "locationId",
                        "basicLocation.locationName",
                        "basicLocation.address",
                        "basicLocation.contact"
                ))
                .excludeSourceFields("meta.*")
                .build();
    }
}
