/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.customer;

import lombok.extern.slf4j.Slf4j;

import java.util.List;

import org.springframework.stereotype.Service;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpIngestionServiceImpl;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;

import static java.util.Objects.requireNonNull;

@Slf4j
@Service
public class CustomerIngestionService extends DpIngestionServiceImpl {

    private static final IngestionEntitySchema ENTITY_SCHEMA = IngestionEntitySchema.of(CustomerEntity.class);

    private final CustomerMapper customerMapper;

    public CustomerIngestionService(DpClient dpClient,
            PartyDpClient partyDpClient,
            DataStorageService dataStorageService,
            PostIngestionService postIngestionService,
            CustomerMapper customerMapper,
            IngestionConfigProperties ingestionConfigProperties) {
        super(dpClient, partyDpClient, dataStorageService, postIngestionService, ingestionConfigProperties);
        this.customerMapper = requireNonNull(customerMapper);
    }

    @Override
    public IngestionType getType() {
        return IngestionType.CUSTOMER;
    }

    @Override
    public IngestionEntitySchema getEntitySchema() {
        return ENTITY_SCHEMA;
    }

    @Override
    protected List<?> prepareEntitiesToIngest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
        return customerMapper.mapToParties(rootEntityPage.getValidEntities());
    }
}
