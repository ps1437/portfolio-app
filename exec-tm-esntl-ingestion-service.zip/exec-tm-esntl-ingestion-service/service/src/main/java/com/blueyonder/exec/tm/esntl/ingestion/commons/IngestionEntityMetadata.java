/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
@Setter
@ToString
public class IngestionEntityMetadata {

    private int rowNumber;

    private List<String> row = Collections.emptyList();

    // Primary or foreign key...
    private String referenceId;

    // Generated unique ID for external system or provided by some other source...
    private String externalReferenceId;

    private List<String> errorMessages = new ArrayList<>();

    public String normalizedReferenceId() {
        return null != externalReferenceId ? externalReferenceId : referenceId;
    }

    public void addErrorMessages(List<String> errors) {
        this.errorMessages.addAll(errors);
    }

    public void addErrorMessage(String errors) {
        this.errorMessages.add(errors);
    }

    public boolean hasError() {
        return !errorMessages.isEmpty();
    }
}
