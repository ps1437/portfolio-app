/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import lombok.RequiredArgsConstructor;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

@Service
@RequiredArgsConstructor
public class TemplateService {

    private static final String XLSX_EXTENSION = ".xlsx";

    private static final String TEMPLATE_PATH = "classpath:templates";

    private final ResourceLoader resourceLoader;

    public List<Resource> getAllTemplates() throws IOException {
        return Arrays.asList(ResourcePatternUtils.getResourcePatternResolver(resourceLoader).getResources(TEMPLATE_PATH + "/*"));
    }

    public List<Resource> getTemplates(List<String> entityTypes) {
        return entityTypes.stream().map(this::getTemplate).toList();
    }

    private Resource getTemplate(String entityType) {
        return resourceLoader.getResource(TEMPLATE_PATH + "/" + entityType + XLSX_EXTENSION);
    }

    public void zipResources(List<Resource> resources, OutputStream os) throws IOException {
        try (ZipOutputStream zipOutputStream = new ZipOutputStream(os)) {
            for (Resource res : resources) {
                ZipEntry e = new ZipEntry(Objects.requireNonNull(res.getFilename()));
                e.setSize(res.contentLength());
                e.setTime(System.currentTimeMillis());
                zipOutputStream.putNextEntry(e);
                try (InputStream is = res.getInputStream()) {
                    StreamUtils.copy(is, zipOutputStream);
                }
                zipOutputStream.closeEntry();
            }
        }
    }

    public List<Resource> getResources(List<String> entityTypes) throws IOException {
        List<Resource> resources = null;
        if (entityTypes.contains("All")) {
            resources = getAllTemplates();
        } else {
            resources = getTemplates(entityTypes);
        }
        return resources;
    }
}
