/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import java.lang.reflect.Method;
import java.util.Locale;

import org.springframework.util.ReflectionUtils;

@SuppressWarnings("rawtypes")
class StringToEnumFromValueConverter<T extends Enum> implements DataConverter<T> {

    private final Class<T> type;

    private final Method fromValueMethod;

    StringToEnumFromValueConverter(Class<T> type) {
        this.type = type;
        this.fromValueMethod = ReflectionUtils.findMethod(type, "fromValue", String.class);
    }

    public boolean isValid() {
        return null != fromValueMethod;
    }

    @SuppressWarnings("unchecked")
    @Override
    public T convert(String value) {
        try {
            return (T) ReflectionUtils.invokeMethod(fromValueMethod, null, value);
        }
        catch (IllegalArgumentException e1) {
            // See if same enumeration is available with uppercase.
            // Some flexibility for user input by assuming that same word is not used
            // in different cases to declare enumerations.
            var s = value.toUpperCase(Locale.getDefault());
            if (s.equals(value)) {
                throw e1;
            }
            try {
                return (T) ReflectionUtils.invokeMethod(fromValueMethod, null, s);
            }
            catch (IllegalArgumentException e2) {
                throw new IllegalArgumentException("No " + type.getSimpleName() + " enum " + value, e2);
            }
        }
    }
}
