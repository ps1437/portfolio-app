/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import java.util.List;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.springframework.util.CollectionUtils;

import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.LocationType;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.EMAIL;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.TELEFAX;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.TELEPHONE;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.WEBSITE;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public abstract class ShipmentDestinationLocationMapper {

    @Mapping(source = "basicLocation.locationName", target = "destinationLocationName")
    @Mapping(source = "basicLocation.address.countryCode", target = "destinationCountryCode")
    @Mapping(source = "basicLocation.address.state", target = "destinationState")
    @Mapping(source = "basicLocation.address.city", target = "destinationCity")
    @Mapping(source = "basicLocation.address.streetAddressOne", target = "destinationStreetAddressOne")
    @Mapping(source = "basicLocation.address.streetAddressTwo", target = "destinationStreetAddressTwo")
    @Mapping(source = "basicLocation.address.streetAddressThree", target = "destinationStreetAddressThree")
    @Mapping(source = "basicLocation.address.postalCode", target = "destinationPostalCode")
    @Mapping(source = "basicLocation.address.geographicalCoordinates.latitude", target = "destinationLatitude")
    @Mapping(source = "basicLocation.address.geographicalCoordinates.longitude", target = "destinationLongitude")
    public abstract void mapToDestinationLocation(LocationType locationType, @MappingTarget ShipmentEntity shipment);

    @AfterMapping
    protected void mapShipToContact(LocationType locationType, @MappingTarget ShipmentEntity shipment) {
        LocationContactType shipToContact = !CollectionUtils.isEmpty(locationType.getBasicLocation().getContact()) ? locationType.getBasicLocation().getContact().get(0) : new LocationContactType();
        if (shipToContact != null) {
            List<CommunicationChannelType> communicationChannels = shipToContact.getCommunicationChannel();
            for (CommunicationChannelType channelType : communicationChannels) {
                if (channelType.getCommunicationChannelCode().value().equals(EMAIL)) {
                    shipment.setDestinationEmail(channelType.getCommunicationValue());
                }
                else if (channelType.getCommunicationChannelCode().value().equals(TELEPHONE)) {
                    shipment.setDestinationTelephone(channelType.getCommunicationValue());
                }
                else if (channelType.getCommunicationChannelCode().value().equals(TELEFAX)) {
                    shipment.setDestinationTelefax(channelType.getCommunicationValue());
                }
                else if (channelType.getCommunicationChannelCode().value().equals(WEBSITE)) {
                    shipment.setDestinationWebsite(channelType.getCommunicationValue());
                }
            }
            shipment.setDestinationCompanyName(shipToContact.getCompanyName());
            shipment.setDestinationContactName(shipToContact.getPersonName());
        }
    }
}
