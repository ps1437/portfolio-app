/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.lang.reflect.Field;

import org.springframework.util.ReflectionUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.DataConverter;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.NoOpConverter;

import static java.util.Objects.requireNonNull;

@Getter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class IngestionEntityColumnDef {

    @EqualsAndHashCode.Include
    private final String name;

    private final Field field;

    private final DataConverter<?> dataConverter;

    IngestionEntityColumnDef(String name, Field field, DataConverter<?> dataConverter) {
        this.name = requireNonNull(name);
        this.field = requireNonNull(field);
        this.dataConverter = requireNonNull(dataConverter);
    }

    public String getFieldName() {
        return field.getName();
    }

    public void setColumnValue(Object obj, String value) {
        try {
            field.set(obj, dataConverter.convert(value));
        }
        catch (Exception ex) {
            ReflectionUtils.handleReflectionException(ex);
        }
    }

    public Object getColumnValue(Object obj) {
        try {
            return field.get(obj);
        }
        catch (Exception ex) {
            ReflectionUtils.handleReflectionException(ex);
            return null;
        }
    }

    @Override
    public String toString() {
        var sb = new StringBuilder();
        sb.append(name).append('(').append(field.getName());
        if (NoOpConverter.class != dataConverter.getClass()) {
            sb.append(", ").append(dataConverter.getClass().getSimpleName());
        }
        sb.append(')');
        return sb.toString();
    }
}
