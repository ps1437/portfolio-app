/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.plat.dp.bydm.CountMeasurementUnitCode;

@Getter
@Setter
@ToString
@Entity(name = "Shipment Logistic Units")
public class ShipmentLogisticUnit extends IngestionEntity {

    @Column(name = "SHIPMENT_SEQ_NO", alias = "S. No.")
    private String serialNumber;

    @Column(name = "PACKAGE_TYPE")
    private String logisticUnitName;

    @Column(name = "DECLARED_VALUE")
    private Double declaredValue;

    @Column(name = "COMMODITY_ID")
    private String commodityId;

    @Column(name = "TOTAL_GROSS_WEIGHT")
    private Double totalGrossWeight;

    @Column(name = "LADEN_LENGTH")
    private Double ladenLength;

    @Column(name = "LENGTH")
    private Double length;

    @Column(name = "WIDTH")
    private Double width;

    @Column(name = "HEIGHT")
    private Double height;

    @Column(name = "QUANTITY_OF_PACKAGES")
    private Double quantity;

    @Column(name = "QUANTITY_UOM")
    private CountMeasurementUnitCode quantityUom;
}
