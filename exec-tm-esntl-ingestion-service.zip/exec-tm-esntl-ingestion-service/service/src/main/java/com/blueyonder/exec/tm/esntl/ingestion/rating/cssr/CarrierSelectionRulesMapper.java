/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating.cssr;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import com.blueyonder.exec.tm.esntl.rating.api.v1.model.SelectionRulesModel;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CarrierSelectionRulesMapper {

    String STRING_TO_SET = "stringToSet";

    @Mapping(source = "includeFreightClasses", target = "includeFreightClasses", qualifiedByName = STRING_TO_SET)
    @Mapping(source = "excludeFreightClasses", target = "excludeFreightClasses", qualifiedByName = STRING_TO_SET)
    @Mapping(source = "includeCommodityTypes", target = "includeCommodityTypes", qualifiedByName = STRING_TO_SET)
    @Mapping(source = "excludeCommodityTypes", target = "excludeCommodityTypes", qualifiedByName = STRING_TO_SET)
    @Mapping(source = "includeCustomers", target = "includeCustomers", qualifiedByName = STRING_TO_SET)
    @Mapping(source = "excludeCustomers", target = "excludeCustomers", qualifiedByName = STRING_TO_SET)
    SelectionRulesModel mapToSelectionRulesModel(CarrierSelectionRulesEntity source);

    List<SelectionRulesModel> mapToSelectionRulesModels(List<CarrierSelectionRulesEntity> source);

    @Named(STRING_TO_SET)
    default Set<String> stringToSet(String val) {
        if (val != null) {
            return Arrays.stream(val.split(",")).map(value -> value.trim()).collect(Collectors.toSet());
        }
        return Collections.EMPTY_SET;
    }
}
