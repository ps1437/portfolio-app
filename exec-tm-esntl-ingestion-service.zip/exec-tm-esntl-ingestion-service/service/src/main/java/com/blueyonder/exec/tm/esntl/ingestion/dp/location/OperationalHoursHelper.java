/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import com.blueyonder.plat.dp.bydm.DayOfTheWeekEnumerationType;
import com.blueyonder.plat.dp.bydm.OperatingHours;
import com.blueyonder.plat.dp.bydm.OperatingHoursType;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class OperationalHoursHelper {

    private static final String OPENING_TIME = "09:00:00";

    private static final String CLOSING_TIME = "17:00:00";

    private static final String OPENING_TIME_RANGE = "23:59:59";

    private static final String CLOSING_TIME_RANGE = "00:00:00";

    static OperatingHours mapToOperatingHours(OperationalHours operationalHrs) {
        List<DayOfTheWeekEnumerationType> days = List.of(DayOfTheWeekEnumerationType.values());
        List<DayOfTheWeekEnumerationType> weekDays = getWeekDays(days);
        if ((OperationalHours.OPERATIONAL_ALL_DAYS).equals(operationalHrs)) {
            return mapOperationalDays(days);
        }
        else if ((OperationalHours.OPERATIONAL_WEEKDAYS).equals(operationalHrs)) {
            return mapOperationalDays(weekDays);
        }
        else if ((OperationalHours.OPERATIONAL_ALL_DAYS_9_TO_5).equals(operationalHrs)) {
            return mapOperationalDaysTimeRange(days);
        }
        else if ((OperationalHours.OPERATIONAL_WEEKDAYS_9_TO_5).equals(operationalHrs)) {
            return mapOperationalDaysTimeRange(weekDays);
        }
        return null;
    }

    static List<DayOfTheWeekEnumerationType> getWeekDays(List<DayOfTheWeekEnumerationType> days) {
        return days.stream()
                .filter(sunday -> !DayOfTheWeekEnumerationType.SUNDAY.equals(sunday))
                .filter(saturday -> !DayOfTheWeekEnumerationType.SATURDAY.equals(saturday))
                .toList();
    }

    static OperatingHours mapOperationalDaysTimeRange(List<DayOfTheWeekEnumerationType> days) {
        return getOperatingHours(days, OPENING_TIME, CLOSING_TIME);
    }

    static OperatingHours mapOperationalDays(List<DayOfTheWeekEnumerationType> days) {
        return getOperatingHours(days, OPENING_TIME_RANGE, CLOSING_TIME_RANGE);
    }

    static OperatingHours getOperatingHours(List<DayOfTheWeekEnumerationType> days, String openingTime, String closingTime) {
        OperatingHours operatingHours = new OperatingHours();
        List<OperatingHoursType> regularOperatingHours = new ArrayList<>();
        for (DayOfTheWeekEnumerationType dayOfTheWeekEnumerationType : days) {
            OperatingHoursType operatingHoursType = new OperatingHoursType();
            operatingHoursType.setDayOfTheWeekCode(dayOfTheWeekEnumerationType);
            operatingHoursType.setIsOperational(true);
            operatingHoursType.setOpeningTime(openingTime);
            operatingHoursType.setClosingTime(closingTime);
            regularOperatingHours.add(operatingHoursType);
        }
        operatingHours.setRegularOperatingHours(regularOperatingHours);
        return operatingHours;
    }

}
