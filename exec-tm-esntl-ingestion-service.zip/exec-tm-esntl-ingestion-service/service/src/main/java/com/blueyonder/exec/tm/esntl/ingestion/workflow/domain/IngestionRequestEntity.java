/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import com.blueyonder.exec.ecom.boot.commons.data.dao.AuditableEntity;
import com.blueyonder.exec.ecom.boot.commons.data.dao.hibernate.SequentialUUIDGenerator;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;

@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString
@Entity
@Table(name = "ingestion_request")
public class IngestionRequestEntity extends AuditableEntity {

    @Id
    @GenericGenerator(name = SequentialUUIDGenerator.ID, strategy = SequentialUUIDGenerator.CLASS_NAME)
    @GeneratedValue(generator = SequentialUUIDGenerator.ID)
    @Type(type = "uuid-char")
    @Column(name = "request_id", updatable = false, nullable = false)
    @EqualsAndHashCode.Include
    private UUID requestId;

    @Column(name = "file_id", updatable = false, nullable = false)
    @EqualsAndHashCode.Include
    private String fileId;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "entity_type", nullable = false)
    private IngestionType entityType;

}
