/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.plat.dp.bydm.CarrierCharacteristicsEnumerationType;

@Getter
@Setter
@ToString
public class CarrierDetailsCharacteristics {

    private CarrierCharacteristicsEnumerationType labellingType;

    private CarrierCharacteristicsEnumerationType trackingType;

    private CarrierCharacteristicsEnumerationType appointmentsType;

    private CarrierCharacteristicsEnumerationType bookingOrTenderingType;

    private String bookingCutoffTimeOfDay;

    private Double pickupLeadTime;
}
