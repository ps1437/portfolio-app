/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.validation;

import lombok.RequiredArgsConstructor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ClassPathResource;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel.ExcelIngestionRequestReader;

@RequiredArgsConstructor
public class EntityValidator {

    private static final List<IngestionEntityDef> ENTITY_SCHEMA = List.of(
            new IngestionEntityDef("Shipment", ValidationEntity.class),
            new IngestionEntityDef("Location", ValidationEntity.class),
            new IngestionEntityDef("Equipment Restrictions", ValidationEntity.class),
            new IngestionEntityDef("Carrier", ValidationEntity.class),
            new IngestionEntityDef("Carrier Services", ValidationEntity.class),
            new IngestionEntityDef("Customer", ValidationEntity.class),
            new IngestionEntityDef("Commodity", ValidationEntity.class),
            new IngestionEntityDef("Shipment Logistic Units", ValidationEntity.class),
            new IngestionEntityDef("Zone", ValidationEntity.class),
            new IngestionEntityDef("GeoGraphic Area", ValidationEntity.class),
            new IngestionEntityDef("Transport Equipment", ValidationEntity.class),
            new IngestionEntityDef("Commodity Restrictions", ValidationEntity.class),
            new IngestionEntityDef("Carrier Service Selection Rules", ValidationEntity.class)
    );

    private static final Map<String, Map<String, ValidationEntity>> VALIDATION_RULES = new HashMap<>();

    static {
        retrieveValidations();
    }

    private static void retrieveValidations() {
        IngestionRequest request;
        try {
            request = new ExcelIngestionRequestReader("IngestionServiceValidations.xlsx",
                    IngestionEntitySchema.of(ENTITY_SCHEMA)).read(new ClassPathResource(
                    "validation/IngestionServiceValidations.xlsx").getInputStream());
        }
        catch (IOException e) {
            throw new IllegalArgumentException(e);
        }
        request.getRequestPages().forEach((k, v) -> VALIDATION_RULES.put(k, v.getEntities().stream()
                .map(ValidationEntity.class::cast)
                .collect(Collectors.toMap(ValidationEntity::getField, Function.identity()))));
    }

    public static List<String> validate(String entityName, String field, String value) {
        List<String> errors = new ArrayList<>();
        Map<String, ValidationEntity> entityValidationMap = VALIDATION_RULES.get(entityName);
        if (null != entityValidationMap) {
            ValidationEntity fieldValidation = entityValidationMap.get(field);
            if (fieldValidation != null) {
                if (BooleanUtils.toBoolean(fieldValidation.getMandatory()) && StringUtils.isBlank(value)) {
                    errors.add("Field " + field + " is mandatory. Please add appropriate value");
                }
                if (!validateRegex(fieldValidation.getRegex(), value)) {
                    errors.add("Regex for " + field + " is not in match. Please enter a valid value using regex " + fieldValidation.getRegex());
                }
            }
        }
        return errors;
    }

    private static boolean validateRegex(String regexPattern, String value) {
        if (StringUtils.isNoneBlank(regexPattern, value)) {
            return Pattern.matches(regexPattern, value);
        }
        return true;
    }
}
