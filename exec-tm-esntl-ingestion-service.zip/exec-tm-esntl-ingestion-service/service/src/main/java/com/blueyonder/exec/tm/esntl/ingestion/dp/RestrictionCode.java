/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

public enum RestrictionCode {

    IER_INCLUDE("INCLUDE"),
    IER_EXCLUDE("EXCLUDE");

    private String value;

    RestrictionCode(String value) {
        this.value = value;
    }

    public static RestrictionCode fromValue(String value) {
        for (RestrictionCode code : RestrictionCode.values()) {
            if (code.value.equals(value)) {
                return code;
            }
        }
        throw new IllegalArgumentException("Incorrect values entered.");
    }
}
