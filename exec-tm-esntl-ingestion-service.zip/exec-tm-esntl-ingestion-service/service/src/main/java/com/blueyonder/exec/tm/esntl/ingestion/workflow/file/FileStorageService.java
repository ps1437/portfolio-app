/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadRequest;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.plat.lui.api.client.v1.FileStorageClient;
import com.blueyonder.plat.lui.api.model.v1.FileQueryResponseModel;
import com.blueyonder.plat.lui.api.model.v1.FileUploadRequestModel;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.TenancyContextUtils.runWithContext;

@RequiredArgsConstructor
@Service
@Slf4j
public class FileStorageService {

    private final FileStorageClient fileStorageClient;

    public Flux<FileUploadResponse> uploadFile(FileUploadRequest request) {
        Instant instant = Instant.now();
        log.info("Uploading the file to file storage");
        return runWithContext(fileStorageClient.uploadFiles(buildFileUploadRequestModel(request)))
                .map(fileUploadResponseModel -> {
                    log.debug("Elapsed time is: {}", Duration.between(instant, Instant.now()));
                    return new FileUploadResponse(fileUploadResponseModel.getId(), fileUploadResponseModel.getFileName());
                })
                .switchIfEmpty(Flux.error(new ResponseErrorMarkerException(null, "No Document found for Upload", null)))
                .onErrorResume(error -> {
                    log.error("Exception while uploading file: {}", request.getFileName(), error);
                    return Flux.error(new ResponseErrorMarkerException(null, "Error encountered while uploading a Document", null));
                });
    }

    private FileUploadRequestModel buildFileUploadRequestModel(FileUploadRequest fileUploadRequest) {
        FileUploadRequestModel uploadRequest = new FileUploadRequestModel();
        uploadRequest.setReferenceId(String.valueOf(UUID.randomUUID()));
        uploadRequest.setReferenceName(fileUploadRequest.getFileName());
        uploadRequest.setExtFields(fileUploadRequest.getFileExtension());
        uploadRequest.setResourceToUpload(getResourceToUpload(fileUploadRequest, fileUploadRequest.getFileContent()));
        return uploadRequest;
    }

    private ByteArrayResource getResourceToUpload(FileUploadRequest fileUploadRequest, byte[] bytes) {
        return new ByteArrayResource(bytes) {
            @Override
            public String getFilename() {
                return fileUploadRequest.getFileName();
            }
        };
    }

    public InputStream downloadFile(String fileId) throws IOException {
        return fileStorageClient.downloadFileByIdAsStream(fileId);
    }

    public Mono<FileQueryResponseModel> getFileDetails(String fileId) {
        return fileStorageClient.getFileDetailsById(fileId);
    }

}
