/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.zone;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

import javax.persistence.Id;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;
import com.blueyonder.plat.dp.bydm.CountryCode;

@Getter
@Setter
@ToString
@Entity(name = "Zone")
public class ZoneEntity extends IngestionEntity {

    @Id
    @Column(name = "ZONE_IDENTIFICATION")
    private String zoneIdentification;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "COUNTRY_CODE")
    private CountryCode countryCode;

    @OneToMany(joinColumnName = "ZONE_IDENTIFICATION")
    private List<GeographicAreaEntity> geographicAreas;
}
