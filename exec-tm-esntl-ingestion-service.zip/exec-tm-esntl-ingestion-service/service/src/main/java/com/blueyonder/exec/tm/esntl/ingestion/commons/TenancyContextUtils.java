/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.function.Consumer;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.jda.security.tenancy.TenancyContextHolder;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TenancyContextUtils {

    private static final String TENANCY_CONTEXT = "tenancyContext";

    public static <T> Mono<T> runWithContext(Mono<T> in) {
        log.info("Printing the tenancyContext {}", JsonUtils.toJson(TenancyContextHolder.getContext()));
        log.debug("setting the tenancy context details");
        return in.doOnEach(data -> {
            if (!data.isOnNext()) {
                return;
            }
            TenancyContextHolder.setContext(data.getContextView().get(TENANCY_CONTEXT));
            log.info("Printing the tenancyContext after setting {}", JsonUtils.toJson(TenancyContextHolder.getContext()));
        }).contextWrite(Context.of(TENANCY_CONTEXT, TenancyContextHolder.getContext()));
    }

    public static <T> Flux<T> runWithContext(Flux<T> in) {
        log.info("Printing the tenancyContext {}", JsonUtils.toJson(TenancyContextHolder.getContext()));
        log.debug("setting the tenancy context details");
        return in.doOnEach(data -> {
            if (!data.isOnNext()) {
                return;
            }
            TenancyContextHolder.setContext(data.getContextView().get(TENANCY_CONTEXT));
        }).contextWrite(Context.of(TENANCY_CONTEXT, TenancyContextHolder.getContext()));
    }

    public static <T> void runWithContext(Mono<T> in, Consumer<T> consumer) {
        runWithContext(in).subscribe(consumer);
    }
}
