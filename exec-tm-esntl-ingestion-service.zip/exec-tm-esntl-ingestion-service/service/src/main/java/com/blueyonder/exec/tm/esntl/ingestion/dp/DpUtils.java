/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.regex.Pattern;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DpUtils {

    private static final Pattern PRIMARY_ID_PATTERN = Pattern.compile("\\s+primaryId\\s+([\\w\\s\\d-_]*)[.\\s]+");

    public static String extractPrimaryId(String errorMessage) {
        var m = PRIMARY_ID_PATTERN.matcher(errorMessage);
        return m.find() ? m.group(1) : "";
    }

}
