/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.Objects;

import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;

import com.blueyonder.exec.tm.esntl.rating.api.v1.model.CarrierSelectionResponseModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.CarrierSelectionRulesModel;

@Slf4j
public class RatingClient {

    private final WebClient ratingWebClient;

    public RatingClient(WebClient ratingWebClient) {
        this.ratingWebClient = Objects.requireNonNull(ratingWebClient);
    }

    public Mono<ResponseEntity<CarrierSelectionResponseModel>> createCarrierServicesSelectionRules(Mono<CarrierSelectionRulesModel> carrierSelectionRulesModel) {
        return ratingWebClient.post()
                .uri("/carrierServiceSelectionRules")
                .body(carrierSelectionRulesModel, CarrierSelectionRulesModel.class)
                .retrieve().toEntity(CarrierSelectionResponseModel.class);
    }
}
