/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import lombok.RequiredArgsConstructor;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.blueyonder.plat.dp.bydm.LocationType;

@Service
@RequiredArgsConstructor
public class ShipmentLocationTypeMapper {

    private final ShipmentOriginLocationMapper shipmentOriginLocationMapper;

    private final ShipmentDestinationLocationMapper shipmentDestinationLocationMapper;

    public void mapShipmentAddress(ShipmentEntity shipment, Map<String, LocationType> locationTypeMap) {
        LocationType locationTypeOrigin = locationTypeMap.get(shipment.getOriginLocation());
        LocationType locationTypeDestination = locationTypeMap.get(shipment.getDestinationLocation());

        mapShipFromLocation(locationTypeOrigin, shipment);
        mapShipToLocation(locationTypeDestination, shipment);
    }

    private void mapShipFromLocation(LocationType locationType, ShipmentEntity shipment) {
        if (locationType != null) {
            shipmentOriginLocationMapper.mapToOriginLocation(locationType, shipment);
        }
        else if (checkIfValidOriginLocationDataPresent(shipment)) {
            shipment.setOriginLocationName(Stream.of(shipment.getOriginStreetAddressOne(),
                            shipment.getOriginStreetAddressTwo(), shipment.getOriginStreetAddressThree(), shipment.getOriginCountryCode().value(),
                            shipment.getOriginState(), shipment.getOriginCity(), shipment.getOriginPostalCode())
                    .filter(StringUtils::isNotBlank)
                    .collect(Collectors.joining(",")));
        }
    }

    private void mapShipToLocation(LocationType shipToLocation, ShipmentEntity shipment) {
        if (shipToLocation != null && shipToLocation.getBasicLocation().getAddress() != null) {
            shipmentDestinationLocationMapper.mapToDestinationLocation(shipToLocation, shipment);
        }
        else if (checkIfValidDestinationLocationDataPresent(shipment)) {
            shipment.setDestinationLocationName(Stream.of(shipment.getDestinationStreetAddressOne(),
                            shipment.getDestinationStreetAddressTwo(), shipment.getDestinationStreetAddressThree(), shipment.getDestinationCountryCode().value(),
                            shipment.getDestinationState(), shipment.getDestinationCity(), shipment.getDestinationPostalCode())
                    .filter(StringUtils::isNotBlank)
                    .collect(Collectors.joining(",")));
        }
    }

    private boolean checkIfValidOriginLocationDataPresent(ShipmentEntity shipment) {
        return (StringUtils.isNotEmpty(shipment.getOriginCity()) && StringUtils.isNotEmpty(shipment.getOriginPostalCode()) && StringUtils.isNotEmpty(shipment.getOriginState())
                && StringUtils.isNotEmpty(shipment.getOriginCountryCode().value()));
    }

    private boolean checkIfValidDestinationLocationDataPresent(ShipmentEntity shipment) {
        return (StringUtils.isNotEmpty(shipment.getDestinationCity()) && StringUtils.isNotEmpty(shipment.getDestinationPostalCode()) && StringUtils.isNotEmpty(shipment.getDestinationState())
                && StringUtils.isNotEmpty(shipment.getDestinationCountryCode().value()));
    }

}
