/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.exec.tm.esntl.ingestion.commons.TenancyContextUtils;
import com.blueyonder.plat.dp.api.client.EntityDpClient;
import com.blueyonder.plat.dp.api.client.v1.CommonDpClient;
import com.blueyonder.plat.dp.api.model.IngestionResponseModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;

@Slf4j
@RequiredArgsConstructor
@Component
public class DpClient {

    private final CommonDpClient commonDpClient;

    @Value("${webclient.retry:3}")
    private long webclientRetry;

    @Value("${webclient.delay:500}")
    private long webclientDelay;

    public <U> Mono<IngestionQueryResponseModel> ingest(EntityDpClient<U> dpClient, Object data) {
        return TenancyContextUtils.runWithContext(dpClient.ingest(data))
                .map(IngestionResponseModel::getIngestionId)
                .flatMap(this::getIngestionStatus);
    }

    private Mono<IngestionQueryResponseModel> getIngestionStatus(String ingestionId) {
        return commonDpClient.getIngestionStatus(ingestionId)
                .map(this::validateStatus)
                .retryWhen(getRetrySpec());
    }

    private RetryBackoffSpec getRetrySpec() {
        return Retry.backoff(webclientRetry, Duration.ofSeconds(webclientDelay)).doBeforeRetry(retries -> log.info("retrying to get the ingestion status with retry count is {} ", retries.totalRetries() + 1))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) ->
                        new ResponseErrorMarkerException(
                                "Retries Exhausted: Incomplete ingestion status received, after max attempts of: "
                                        + retrySignal.totalRetries()));
    }

    private IngestionQueryResponseModel validateStatus(IngestionQueryResponseModel ingestionQueryResponseModel) {
        if (ingestionQueryResponseModel.getCreateOrIngestCompletedEvent().isPresent()) {
            log.debug("Complete Ingestion response obtained is - {},", ingestionQueryResponseModel);
            return ingestionQueryResponseModel;
        }
        else {
            log.debug("Incomplete Ingestion response obtained is - {},", ingestionQueryResponseModel);
            throw new ResponseErrorMarkerException("Incomplete status received from webclient");
        }
    }
}
