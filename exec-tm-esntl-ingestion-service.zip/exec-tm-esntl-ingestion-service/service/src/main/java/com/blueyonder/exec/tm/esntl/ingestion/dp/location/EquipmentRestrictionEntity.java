/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.RestrictionCode;

@Getter
@Setter
@ToString
@Entity(name = "Equipment Restrictions")
public class EquipmentRestrictionEntity extends IngestionEntity {

    @Column(name = "LOCATION_ID")
    private String locationId;

    @Column(name = "EQUIPMENT_RESTRICTION_CODE")
    private RestrictionCode equipmentRestrictionCode;

    @Column(name = "EQUIPMENT_TYPE")
    private String equipmentType;
}
