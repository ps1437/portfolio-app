/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.DataConverter;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.NoOpConverter;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface Column {

    /**
     * The name of the column.
     */
    String name() default "";

    /**
     * (Optional) One or more secondary names to accept as aliases to the official name.
     */
    String[] alias() default {};

    /**
     * Specifies the converter to be applied.
     */
    Class<? extends DataConverter<?>> converter() default NoOpConverter.class;
}
