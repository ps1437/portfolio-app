/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum LocationTypeCode {

    CROSS_DOCK("CROSS_DOCK"),

    DISTRIBUTION_CENTER("DISTRIBUTION_CENTER"),

    CONSIGNEE("CONSIGNEE"),

    SHIP_FROM("SHIP_FROM");

    private static final Map<String, LocationTypeCode> CONSTANTS = new HashMap<>();

    static {
        for (LocationTypeCode c : values()) {
            CONSTANTS.put(c.value, c);
        }
    }

    private final String value;

    LocationTypeCode(String value) {
        this.value = value;
    }

    @JsonCreator
    public static LocationTypeCode fromValue(String value) {
        LocationTypeCode constant = CONSTANTS.get(value);
        if (constant == null) {
            throw new IllegalArgumentException("No LocationType enum " + value);
        }
        else {
            return constant;
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    @JsonValue
    public String value() {
        return this.value;
    }
}
