/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating;

import lombok.Getter;
import lombok.ToString;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.CarrierSelectionResponseModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ErrorMessageModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ErrorModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.StatusModel;
import com.google.common.annotations.VisibleForTesting;

@Getter
@ToString(callSuper = true)
public class CssrIngestionResponse extends IngestionResponse {

    private final CarrierSelectionResponseModel carrierSelectionResponseModel;

    public CssrIngestionResponse(IngestionRequest ingestionRequest, CarrierSelectionResponseModel carrierSelectionResponseModel) {
        super(ingestionRequest, buildErrorResponse(carrierSelectionResponseModel));
        this.carrierSelectionResponseModel = carrierSelectionResponseModel;
    }

    @VisibleForTesting
    static Map<String, List<String>> buildErrorResponse(CarrierSelectionResponseModel carrierSelectionResponseModel) {
        if (StatusModel.COMPLETED_WITH_VALIDATION_ERRORS.equals(carrierSelectionResponseModel.getStatus())) {
            return carrierSelectionResponseModel.getErrors().stream()
                    .collect(Collectors.toMap(ErrorModel::getRuleId,
                            errorModel -> errorModel.getMessages().stream().map(ErrorMessageModel::getUserMessage).toList()));
        }
        return new HashMap<>();
    }
}
