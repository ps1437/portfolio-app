/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static java.util.Objects.requireNonNull;

@Getter
@ToString
public class IngestionResponse {

    private final IngestionRequest ingestionRequest;

    private final Map<String, List<String>> errorResponse;

    public IngestionResponse(IngestionRequest ingestionRequest) {
        this(ingestionRequest, Collections.emptyMap());
    }

    public IngestionResponse(IngestionRequest ingestionRequest, Map<String, List<String>> errorResponse) {
        this.ingestionRequest = requireNonNull(ingestionRequest);
        this.errorResponse = requireNonNull(errorResponse);
    }
}
