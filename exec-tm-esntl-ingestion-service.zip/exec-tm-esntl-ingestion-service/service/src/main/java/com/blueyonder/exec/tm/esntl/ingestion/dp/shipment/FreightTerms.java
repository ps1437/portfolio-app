/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum FreightTerms {

    COLLECT("CC"),

    PREPAID("PP");

    private final String value;

    FreightTerms(String value) {
        this.value = value;
    }

    @JsonCreator
    public static FreightTerms fromValue(String value) {
        for (FreightTerms freightTerms : values()) {
            if (freightTerms.name().equalsIgnoreCase(value)) {
                return freightTerms;
            }
        }
        throw new IllegalArgumentException("No FreightTerms enum " + value);
    }

    @Override
    public String toString() {
        return this.value;
    }

    @JsonValue
    public String value() {
        return this.value;
    }
}
