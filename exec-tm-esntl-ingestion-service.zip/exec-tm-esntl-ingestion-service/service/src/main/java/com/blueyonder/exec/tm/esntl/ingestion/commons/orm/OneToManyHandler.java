/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.springframework.util.ReflectionUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;

public class OneToManyHandler implements Consumer<IngestionEntity> {

    private final Field parentEntityField;

    private final IngestionEntityColumnDef childEntityJoinColumnDef;

    private final Map<?, ? extends IngestionEntity> parentEntitiesCache;

    public OneToManyHandler(IngestionEntityDef entityDef, Map<?, ? extends IngestionEntity> parentEntitiesCache) {
        IngestionEntityOneToManyDef o = entityDef.getParentEntityOneToManyDef();
        parentEntityField = o.parentEntityField();
        childEntityJoinColumnDef = o.childEntityJoinColumnDef();
        this.parentEntitiesCache = parentEntitiesCache;
    }

    @Override
    public void accept(IngestionEntity child) {
        IngestionEntity parent = null;
        Object joinId = childEntityJoinColumnDef.getColumnValue(child);
        if (null != joinId) {
            parent = parentEntitiesCache.get(joinId);
            // Foreign key as reference ID...
            child.getMetadata().setReferenceId(joinId.toString());
        }
        if (null == parent) {
            child.getMetadata().addErrorMessage(String.format(
                    "Undefined join id or parent entity {joinColumn=%s, joinId=%s}",
                    childEntityJoinColumnDef.getName(), joinId));
            return;
        }

        addChild(parent, child);

        if (child.getMetadata().hasError()) {
            parent.getMetadata().addErrorMessage(String.format(
                    "Child entity has error {joinColumn=%s, joinId=%s}",
                    childEntityJoinColumnDef.getName(), joinId));
        }
        else if (parent.getMetadata().hasError()) {
            child.getMetadata().addErrorMessage(String.format(
                    "Parent entity has error {joinColumn=%s, joinId=%s}",
                    childEntityJoinColumnDef.getName(), joinId));
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private void addChild(Object parent, Object child) {
        try {
            List list = (List) parentEntityField.get(parent);
            if (null == list) {
                list = new ArrayList();
                parentEntityField.set(parent, list);
            }
            list.add(child);
        }
        catch (Exception ex) {
            ReflectionUtils.handleReflectionException(ex);
        }
    }
}
