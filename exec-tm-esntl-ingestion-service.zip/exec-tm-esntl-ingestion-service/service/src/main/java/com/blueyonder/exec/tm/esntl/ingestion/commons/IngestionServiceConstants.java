/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class IngestionServiceConstants {

    public static final String XLSX_CONTENT_TYPE = "xlsx";

    public static final String XLS_CONTENT_TYPE = "xls";

    public static final String ERROR_MESSAGE = "ERROR_MESSAGE";

    public static final String EMAIL = "EMAIL";

    public static final String TELEPHONE = "TELEPHONE";

    public static final String TELEFAX = "TELEFAX";

    public static final String WEBSITE = "WEBSITE";

    public static final String WEIGHT = "weight";

    public static final String LENGTH = "length";

    public static final String LTMS = "ltms";

    public static final String UOM = "uom";

    public static final String CURRENCY = "currency";
}
