/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import java.util.Locale;
import java.util.Set;

public enum IngestionSourceType {

    EXCEL(Set.of("xlsx", "xls"), Set.of(IngestionType.values())),

    CSV(Set.of("csv"), Set.of());

    private final Set<String> sourceTypes;

    private final Set<IngestionType> supportedIngestionTypes;

    IngestionSourceType(Set<String> sourceTypes, Set<IngestionType> supportedIngestionTypes) {
        this.sourceTypes = sourceTypes;
        this.supportedIngestionTypes = supportedIngestionTypes;
    }

    public static IngestionSourceType fromValue(String sourceType) {
        if (null != sourceType) {
            String s = sourceType.toLowerCase(Locale.getDefault());
            for (IngestionSourceType o : values()) {
                if (o.sourceTypes.contains(s)) {
                    return o;
                }
            }
        }
        throw new IllegalArgumentException("Invalid ingestion source type " + sourceType);
    }

    public static IngestionSourceType fromValue(String sourceType, IngestionType ingestionType) {
        IngestionSourceType o = fromValue(sourceType);
        if (o.supportedIngestionTypes.contains(ingestionType)) {
            return o;
        }
        throw new IllegalArgumentException(String.format(
                "Ingestion source type %s (%s) is not supported by entity %s", o, sourceType, ingestionType));
    }

    public Set<String> getSourceTypes() {
        return sourceTypes;
    }

    public Set<IngestionType> getSupportedIngestionTypes() {
        return supportedIngestionTypes;
    }
}
