/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import java.util.Objects;

import org.springframework.util.CollectionUtils;

import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

public abstract class IngestionServiceImpl implements IngestionService {

    @Override
    public DataIngestionDetails ingest(IngestionRequest ingestionRequest) {
        return ingest(ingestionRequest, getRootEntityPage(ingestionRequest));
    }

    private IngestionRequestPage getRootEntityPage(IngestionRequest ingestionRequest) {
        String rootEntityName = getEntitySchema().getRootEntityDefs().get(0).getName();
        IngestionRequestPage rootEntityPage = ingestionRequest.getRequestPages().get(rootEntityName);
        if (Objects.isNull(rootEntityPage) || CollectionUtils.isEmpty(rootEntityPage.getEntities())) {
            throw new ResponseErrorMarkerException(null, "Invalid ingestion request. Data for entity "
                    + rootEntityName + " is not found", null);
        }
        return rootEntityPage;
    }

    protected abstract DataIngestionDetails ingest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage);
}
