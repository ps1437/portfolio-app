/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

import org.springframework.util.CollectionUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityColumnDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.OneToManyHandler;

import static java.util.Objects.requireNonNull;

@Getter
@ToString
public class IngestionRequestPage {

    private final IngestionRequestEntityDef requestEntityDef;

    private final IngestionEntityColumnDef idColumnDef;

    private final Map<Object, IngestionEntity> indexedEntities;

    private final List<IngestionEntity> entities = new ArrayList<>();

    private final List<IngestionEntity> invalidEntities = new ArrayList<>();

    private final Consumer<IngestionEntity> oneToManyHandler;

    private List<IngestionEntity> validEntities = new ArrayList<>();

    public IngestionRequestPage(IngestionRequestEntityDef requestEntityDef, IngestionRequest request) {
        this.requestEntityDef = requireNonNull(requestEntityDef);

        IngestionEntityDef entityDef = requestEntityDef.getEntityDef();
        this.idColumnDef = entityDef.getIdColumnDef();
        this.indexedEntities = null != idColumnDef ? new HashMap<>() : Collections.emptyMap();

        IngestionEntityDef parentEntityDef = entityDef.getParentEntityDef();
        if (null != parentEntityDef) {
            oneToManyHandler = new OneToManyHandler(entityDef, request.getRequestPages()
                    .get(parentEntityDef.getName()).getIndexedEntities());
        }
        else {
            oneToManyHandler = entity -> {
                // Nothing to do...
            };
        }
    }

    /**
     * Returns the name of request page. Its value is same as name of associated {@link IngestionRequestEntityDef}.
     *
     * @return the name of request page.
     */
    public String getName() {
        return requestEntityDef.getName();
    }

    /**
     * Returns the ordered set of column name.
     *
     * @return the ordered set of column name.
     */
    public Set<String> getColumnNames() {
        return requestEntityDef.getRequestColumnDefs().keySet();
    }

    /**
     * Returns the list of entities with its dependencies belonging to this request page.
     *
     * @return the list of entities.
     * @param <T> the {@link IngestionEntity} type.
     */
    @SuppressWarnings("unchecked")
    public <T extends IngestionEntity> List<T> getEntities() {
        return (List<T>) entities;
    }

    /**
     * Returns the list valid entities which are classified based on error while preparing entity graph.
     * <p/>
     * Note: If any valid entity is marked as invalid after entity graph preparation then
     * those will be still part of this list.
     *
     * @return the list of valid entities.
     * @param <T> the {@link IngestionEntity} type.
     */
    @SuppressWarnings("unchecked")
    public <T extends IngestionEntity> List<T> getValidEntities() {
        return (List<T>) validEntities;
    }

    /**
     * Returns the list invalid entities which are classified based on error while preparing entity graph.
     *
     * @return the list of invalid entities.
     * @param <T> the {@link IngestionEntity} type.
     */
    @SuppressWarnings("unchecked")
    public <T extends IngestionEntity> List<T> getInvalidEntities() {
        return (List<T>) invalidEntities;
    }

    public boolean hasError() {
        return !invalidEntities.isEmpty();
    }

    public <T extends IngestionEntity> T addEntity(int rowNumber, List<String> row) {
        T entity = requestEntityDef.createEntity(row);
        if (null != entity) {
            entity.getMetadata().setRowNumber(rowNumber);
            entity.getMetadata().setRow(row);
            entity.postConstruct();
            addEntity(entity);
        }
        return entity;
    }

    public void addEntity(IngestionEntity entity) {
        entities.add(entity);
        // Index and record errors...
        index(entity);
        // Build entity graph and record errors...
        oneToManyHandler.accept(entity);
        // Classify...
        if (!entity.getMetadata().hasError()) {
            validEntities.add(entity);
        }
        else {
            invalidEntities.add(entity);
        }
    }

    private void index(IngestionEntity entity) {
        if (null != idColumnDef) {
            Object id = idColumnDef.getColumnValue(entity);
            if (null != id) {
                var o = indexedEntities.put(id, entity);
                if (null != o) {
                    // Duplicate entity, lets keep the earlier one and mark current one as invalid.
                    indexedEntities.put(id, o);
                    entity.getMetadata().addErrorMessage("Duplicate entity " + id);
                }
                // Primary key as reference ID...
                entity.getMetadata().setReferenceId(id.toString());
            }
        }
    }

    public void postConstruct() {
        if (!CollectionUtils.isEmpty(requestEntityDef.getEntityDef().getChildEntityDefs())) {
            // Let's invoke post entity graph construct and
            // reclassify to handle errors during parent-child relationship, etc.
            List<IngestionEntity> list = new ArrayList<>(validEntities.size());
            for (IngestionEntity o : validEntities) {
                o.postGraphConstruct();
                if (!o.getMetadata().hasError()) {
                    list.add(o);
                }
                else {
                    invalidEntities.add(o);
                }
            }
            validEntities = list;
        }
    }
}
