/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import lombok.SneakyThrows;

import java.util.Arrays;
import java.util.List;

import javax.persistence.AttributeConverter;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;

public class ErrorInfoAttributeConverter implements AttributeConverter<List<ErrorInfo>, String> {

    static {
        JsonUtils.objectMapper().addMixIn(ErrorInfo.class, ErrorInfoMixin.class);
    }

    @SneakyThrows
    @Override
    public String convertToDatabaseColumn(List<ErrorInfo> attribute) {
        return JsonUtils.toJson(attribute);
    }

    @Override
    public List<ErrorInfo> convertToEntityAttribute(String dbData) {
        return Arrays.asList(JsonUtils.fromJson(dbData, ErrorInfo[].class));
    }
}
