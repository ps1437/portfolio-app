/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.RestrictionCode;

@Getter
@Setter
@ToString
@Entity(name = "Commodity Restrictions")
public class CommodityRestrictionEntity  extends IngestionEntity {

    @Column(name = "TRANSPORT_EQUIPMENT_ID")
    private String transportEquipmentId;

    @Column(name = "COMMODITY_RESTRICTION_CODE")
    private RestrictionCode commodityRestrictionCode;

    @Column(name = "COMMODITY_TYPE")
    private String commodityType;
}
