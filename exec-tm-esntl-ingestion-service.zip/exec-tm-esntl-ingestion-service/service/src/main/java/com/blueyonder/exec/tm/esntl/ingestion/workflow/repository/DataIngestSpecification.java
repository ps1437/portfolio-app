package com.blueyonder.exec.tm.esntl.ingestion.workflow.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryEntryModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.Operator;

public class DataIngestSpecification implements Specification<DataIngestionDetails> {

    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    private final List<QueryEntryModel> list = new ArrayList<>();

    public void add(QueryEntryModel criteria) {
        list.add(criteria);
    }

    /**
     * Creates a WHERE clause for a query of the referenced entity in form of a {@link Predicate} for the given
     * {@link Root} and {@link CriteriaQuery}.
     *
     * @param root            must not be {@literal null}.
     * @param query           must not be {@literal null}.
     * @param criteriaBuilder must not be {@literal null}.
     * @return a {@link Predicate}, may be {@literal null}.
     */
    @Override
    public Predicate toPredicate(Root<DataIngestionDetails> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();

        for (QueryEntryModel criteria : list) {
            if (Objects.equals(criteria.getOperation(), Operator.gte.name())) {
                if (criteria.getKey().equals("startDateTime")) {
                    OffsetDateTime offsetDateTime = formatToOffsetTime(criteria.getValue());
                    predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(criteria.getKey()), offsetDateTime));
                }
                else {
                    predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(criteria.getKey()), criteria.getValue()));
                }
            }
            else if (Objects.equals(criteria.getOperation(), Operator.lte.name())) {
                if (criteria.getKey().equals("endDateTime")) {
                    OffsetDateTime offsetDateTime = formatToOffsetTime(criteria.getValue());
                    predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get(criteria.getKey()), offsetDateTime));
                }
                else {
                    predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get(criteria.getKey()), criteria.getValue()));
                }
            }
            else if (Objects.equals(criteria.getOperation(), Operator.eq.name())) {
                if (criteria.getKey().equals("id")) {
                    predicates.add(criteriaBuilder.equal(
                            root.get(criteria.getKey()), UUID.fromString(criteria.getValue())));
                } else {
                    predicates.add(criteriaBuilder.equal(
                            root.get(criteria.getKey()), criteria.getValue()));
                }
            }
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    private OffsetDateTime formatToOffsetTime(String value) {
        LocalDate date = LocalDate.parse(value, DateTimeFormatter.ofPattern(YYYY_MM_DD));
        return OffsetDateTime.of(date, LocalTime.NOON, ZoneOffset.UTC);
    }
}
