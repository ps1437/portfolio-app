/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

import javax.persistence.Id;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;
import com.blueyonder.plat.dp.bydm.CountryCode;
import com.blueyonder.plat.dp.bydm.CurrencyCode;

@Getter
@Setter
@ToString
@Entity(name = "Carrier")
public class CarrierEntity extends IngestionEntity {

    @Id
    @Column(name = "CARRIER_ID")
    private String carrierId;

    @Column(name = "CARRIER_NAME")
    private String carrierName;

    @Column(name = "SCAC")
    private String scac;

    @Column(name = "COUNTRY_CODE")
    private CountryCode countryCode;

    @Column(name = "STATE")
    private String state;

    @Column(name = "CITY")
    private String city;

    @Column(name = "STREET_ADDRESS_ONE")
    private String streetAddressOne;

    @Column(name = "STREET_ADDRESS_TWO")
    private String streetAddressTwo;

    @Column(name = "STREET_ADDRESS_THREE")
    private String streetAddressThree;

    @Column(name = "POSTAL_CODE")
    private String postalCode;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "TELEFAX")
    private String telefax;

    @Column(name = "TELEPHONE")
    private String telephone;

    @Column(name = "WEBSITE")
    private String website;

    @Column(name = "CONTACT_PERSON")
    private String personName;

    @Column(name = "EXTERNAL_CARRIER_CODE")
    private String externalCarrierCode;

    @Column(name = "CARRIER_ACCOUNT_NUMBER")
    private String carrierAccountNumber;

    @Column(name = "AP_ACCOUNT_NUMBER")
    private String apAccountNumber;

    @Column(name = "AR_ACCOUNT_NUMBER")
    private String arAccountNumber;

    @Column(name = "PICKUP_LEAD_TIME")
    private Double pickupLeadTimeHrs;

    @Column(name = "TENDER_RESPONSE_TIME")
    private Double tenderResponseTimeHrs;

    @Column(name = "CURRENCY_CODE")
    private CurrencyCode currencyCode;

    @OneToMany(joinColumnName = "CARRIER_ID")
    private List<CarrierServiceEntity> carrierServiceEntities;

    private CarrierService carrierService;
}
