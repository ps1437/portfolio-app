/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;

@Component
public class IngestionFactory {

    private final Map<IngestionType, IngestionService> ingestionProviders;

    @Autowired
    public IngestionFactory(List<IngestionService> processors) {
        ingestionProviders = processors.stream().collect(Collectors.toUnmodifiableMap(IngestionService::getType, Function.identity()));
    }

    public IngestionService getIngestionService(IngestionType ingestionType) {
        return Optional.ofNullable(ingestionProviders.get(ingestionType)).orElseThrow(IllegalArgumentException::new);
    }
}
