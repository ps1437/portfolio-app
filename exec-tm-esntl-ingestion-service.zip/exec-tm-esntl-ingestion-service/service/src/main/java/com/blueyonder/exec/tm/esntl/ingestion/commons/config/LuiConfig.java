/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.config;

import lombok.RequiredArgsConstructor;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.blueyonder.plat.lui.api.client.LuiClientConfig;
import com.blueyonder.plat.lui.api.client.v1.FileStorageClient;
import com.blueyonder.plat.lui.api.client.v1.UIConfigurationClient;
import com.blueyonder.service.common.liam.testing.LiamAuthClientConfig;

@Configuration
@EnableConfigurationProperties({ LuiConfig.LuiConfigProperties.class })
@Import({ LuiClientConfig.class, LiamAuthClientConfig.class })
@RequiredArgsConstructor
public class LuiConfig {

    private final LuiClientConfig luiClientConfig;

    @Bean
    public FileStorageClient fileStorageClient() {
        return new FileStorageClient(luiClientConfig.luiWebClient(), luiClientConfig.downloadWebClient());
    }

    @Bean
    public UIConfigurationClient uiConfigurationClient() {
        return new UIConfigurationClient(luiClientConfig.luiWebClient());
    }

    @ConfigurationProperties("web-client.lui-platform")
    static class LuiConfigProperties extends LuiClientConfig.LuiConfigProperties {
    }
}
