/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorResponse;
import com.blueyonder.exec.tm.esntl.ingestion.IngestionServiceApplication;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestModel;
import com.blueyonder.service.common.liam.testing.IntegrationTestActiveProfileResolver;
import com.blueyonder.service.common.liam.testing.WithIdentity;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ActiveProfiles(resolver = IntegrationTestActiveProfileResolver.class)
@SpringBootTest(
        webEnvironment = WebEnvironment.RANDOM_PORT,
        classes = IngestionServiceApplication.class
)
@WithIdentity
@AutoConfigureWebTestClient(timeout = "20000")
class IngestionRequestIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void testEmptyIngestionRequest() {
        var bodyBuilder = new MultipartBodyBuilder();
        bodyBuilder.part("file", new ClassPathResource("Carrier_Empty.xlsx"),
                MediaType.MULTIPART_FORM_DATA);
        var body = bodyBuilder.build();

        var response = webTestClient.post()
                .uri(builder -> builder.path("/upload")
                        .queryParam("entityType", "Carrier")
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange();
        assertNotNull(response);

        response.expectStatus().isBadRequest()
                .expectBody(ErrorResponse.class)
                .value(e -> e.getErrors().get(0).getErrorCode(), equalTo("ltms.ingestion.invalidFile"));
    }

    @Test
    void testCreateIngestionRequest() {
        var ingestionRequestDetailsModel = new IngestionRequestDetailsModel();
        ingestionRequestDetailsModel.setEntityType(EntityTypeModel.CARRIER);
        ingestionRequestDetailsModel.setFileId("63cec1337b2d4bdd168c408c");
        var response = webTestClient.post()
                .uri(builder -> builder.path("/ingestions/requests")
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(ingestionRequestDetailsModel)
                .exchange();
        assertNotNull(response);
        response.expectBody(IngestionRequestModel.class)
                .value(ingestionRequestModel -> ingestionRequestModel.getRequestId(), notNullValue());
    }

}
