/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.blueyonder.exec.tm.esntl.ingestion.IngestionServiceApplication;
import com.blueyonder.service.common.liam.testing.IntegrationTestActiveProfileResolver;
import com.blueyonder.service.common.liam.testing.WithIdentity;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ActiveProfiles(resolver = IntegrationTestActiveProfileResolver.class)
@SpringBootTest(
        webEnvironment = WebEnvironment.RANDOM_PORT,
        classes = IngestionServiceApplication.class
)
@WithIdentity
class DataIngestionApiIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void testEntitiesList() {
        var response = webTestClient.get()
                .uri(builder -> builder.path("/entitiesList").build())
                .accept(MediaType.APPLICATION_JSON)
                .exchange();
        assertNotNull(response);

        response.expectStatus().isOk()
                .expectBody(Map.class)
                .value(e -> e.get("Carrier"), equalTo("Carrier"));
    }
}
