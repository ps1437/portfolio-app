/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating.cssr;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ExcludeOptionEnumTest {
    @Test
    void checkAllOptionValues() {
        assertEquals("INCLUDE", ExcludeOption.INCLUDE.name());
        assertEquals("EXCLUDE", ExcludeOption.EXCLUDE.name());
        assertFalse(ExcludeOption.INCLUDE.value());
        assertTrue(ExcludeOption.EXCLUDE.value());
    }

    @ParameterizedTest
    @ValueSource(strings = { "", "asdfsafsdf" })
    void testIncorrectOptionValue(String value) {
        assertThrows(IllegalArgumentException.class, () -> ExcludeOption.valueOf(value));
    }
}
