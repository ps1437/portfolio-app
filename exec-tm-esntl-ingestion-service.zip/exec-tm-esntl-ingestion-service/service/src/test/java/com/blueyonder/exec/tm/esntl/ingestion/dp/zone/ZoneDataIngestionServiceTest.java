/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.zone;

import reactor.core.publisher.Mono;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.TestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.ZoneDpClient;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

@ExtendWith(MockitoExtension.class)
class ZoneDataIngestionServiceTest {

    private final ZoneIngestionService ingestionService;

    private final DpClient dpClient;

    private final DataStorageService dataStorageService;

    private final IngestionConfigProperties ingestionConfigProperties;

    @Captor
    private ArgumentCaptor<String> fileNameCapture;

    @Captor
    private ArgumentCaptor<String> entityTypeCapture;

    ZoneDataIngestionServiceTest() {
        this.dpClient = mock(DpClient.class);
        ZoneDpClient zoneDpClient = mock(ZoneDpClient.class, withSettings().stubOnly());
        this.dataStorageService = mock(DataStorageService.class);
        PostIngestionService postIngestionService = mock(PostIngestionService.class);
        ZoneMapper zoneMapper = Mappers.getMapper(ZoneMapper.class);
        this.ingestionConfigProperties = mock(IngestionConfigProperties.class);
        this.ingestionService = new ZoneIngestionService(
                dpClient, zoneDpClient, dataStorageService, postIngestionService, zoneMapper, ingestionConfigProperties);
    }

    @Test
    void testGetType() {
        assertEquals(IngestionType.ZONE, ingestionService.getType());
        assertNotNull(ingestionService.getEntitySchema().getEntityDef("Zone"));
    }

    @Test
    void testFileBasedIngest() {
        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
        IngestionConfigProperties.BatchConfig batchConfig = new IngestionConfigProperties.BatchConfig();
        batchConfig.setBatchSize(25);
        when(ingestionConfigProperties.getBatchConfig()).thenReturn(batchConfig);

        ingestionService.ingest(TestUtils.buildIngestionRequest(ingestionService, "Zone.xlsx"));
        verify(dpClient, times(1)).ingest(any(), anyList());
    }

    //    @Test
    //    void testProcessZoneDpIngestError() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(zoneMapper.mapToZoneType(any())).thenReturn(TestUtils.buildZoneType());
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(dpClient.ingest(any(), any())).thenReturn(Mono.error(new RuntimeException("Something went wrong")));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(createDomainResultSetMap());
    //            MockMultipartFile mockMultipartFile = TestUtils.mockMultiPartReq();
    //
    //            DataIngestionDetails dataIngestionDetailsResponse = zoneIngestionService.process(mockMultipartFile);
    //
    //            assertNotNull(dataIngestionDetailsResponse);
    //            verify(dataStorageService, times(1)).updateErrorFileDetails(anyString(), anyString(), anyInt());
    //        }
    //    }

    //    @Test
    //    void testZoneProcess() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(createDomainResultSetMapErrors());
    //            MockMultipartFile mockMultipartFile = TestUtils.mockMultiPartReq();
    //
    //            DataIngestionDetails dataIngestionDetailsResponse = zoneIngestionService.process(mockMultipartFile);
    //
    //            verify(dataStorageService).saveFileDetails(fileNameCapture.capture(), entityTypeCapture.capture());
    //            assertEquals(dataIngestionDetails, dataIngestionDetailsResponse);
    //            assertEquals(mockMultipartFile.getOriginalFilename(), fileNameCapture.getValue());
    //            verify(postIngestionService, times(1)).processIngestion(any());
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessWithEmptyDomainSet() {
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(new HashMap<>());
    //
    //            assertThrows(ResponseErrorMarkerException.class, () -> zoneIngestionService.process(TestUtils.mockMultiPartReq()));
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessWithEmptyEntities() {
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //            IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //            ingestionRequestPage.setDomainType(DomainType.TRANSPORT_EQUIPMENT);
    //            ingestionRequestPage.setEntities(List.of());
    //            resultSetMap.put(DomainType.TRANSPORT_EQUIPMENT, ingestionRequestPage);
    //
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(new HashMap<>());
    //
    //            assertThrows(ResponseErrorMarkerException.class, () -> zoneIngestionService.process(TestUtils.mockMultiPartReq()));
    //        }
    //    }

    //    private Map<DomainType, IngestionRequestPage> createDomainResultSetMapErrors() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.ZONE);
    //        ZoneEntity zone = TestUtils.buildZone();
    //        zone.setErrorMessages(List.of("error1", "error2"));
    //        ingestionRequestPage.setEntities(List.of(zone));
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.ZONE, ingestionRequestPage);
    //        resultSetMap.put(DomainType.GEOGRAPHIC_AREA, TestUtils.buildGeoGraphicAreaDomainResultSet());
    //        return resultSetMap;
    //    }

    //    private Map<DomainType, IngestionRequestPage> createDomainResultSetMap() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.ZONE, TestUtils.buildZoneDomainResultSet());
    //        resultSetMap.put(DomainType.GEOGRAPHIC_AREA, TestUtils.buildGeoGraphicAreaDomainResultSet());
    //        return resultSetMap;
    //    }
}
