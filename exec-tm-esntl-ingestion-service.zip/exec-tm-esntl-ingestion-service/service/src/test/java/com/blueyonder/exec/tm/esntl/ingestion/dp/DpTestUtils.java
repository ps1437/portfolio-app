/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.mock.web.MockMultipartFile;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.commons.ErrorMessagesForRow;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierDetailsCharacteristics;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierServiceEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.commodity.CommodityEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.customer.CustomerEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.location.LocationEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.shipment.ShipmentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.shipment.ShipmentLogisticUnit;
import com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment.CommodityRestrictionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment.TransportEquipmentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.zone.GeographicAreaEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.zone.ZoneEntity;
import com.blueyonder.exec.tm.esntl.ingestion.rating.cssr.CarrierSelectionRulesEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ServiceLevelCodeModel;
import com.blueyonder.plat.dp.api.model.IngestionResponseModel;
import com.blueyonder.plat.dp.api.model.v1.ErrorMessageModel;
import com.blueyonder.plat.dp.api.model.v1.EventTypeModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;
import com.blueyonder.plat.dp.bydm.CarrierCharacteristicsEnumerationType;
import com.blueyonder.plat.dp.bydm.CarrierDetailsType;
import com.blueyonder.plat.dp.bydm.CommunicationChannelCode;
import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.CurrencyCode;
import com.blueyonder.plat.dp.bydm.DocumentActionEnumerationType;
import com.blueyonder.plat.dp.bydm.LocationType;
import com.blueyonder.plat.dp.bydm.MeasurementUnitCode;
import com.blueyonder.plat.dp.bydm.PartyType;
import com.blueyonder.plat.dp.bydm.ServiceDetailsType;
import com.blueyonder.plat.dp.bydm.ZoneType;

import static com.blueyonder.exec.tm.esntl.ingestion.TestUtils.PODAM_FACTORY;

public class DpTestUtils {

    public static final String ENTITY_SHIPMENT = "Shipment";

    public static final String ENTITY_SHIPMENT_LOGISTIC_UNITS = "Shipment Logistic Units";

    public static IngestionQueryResponseModel buildIngestionQueryResponseModel() {
        return buildIngestionQueryResponseModel("consume");
    }

    public static IngestionQueryResponseModel buildIngestionQueryResponseModel(String service) {
        IngestionQueryResponseModel model = new IngestionQueryResponseModel();
        model.setId("test001");
        EventTypeModel eventTypeModel = new EventTypeModel();
        eventTypeModel.setService(service);
        eventTypeModel.setStatus("COMPLETED_WITH_ERROR");
        ErrorMessageModel errorModel = new ErrorMessageModel();
        errorModel.setErrorMessage("Validation failed for primaryId test1113. Error: $[0].basicLocation.locationName: may only be 80 characters long");
        ErrorMessageModel errorModel2 = new ErrorMessageModel();
        errorModel2.setErrorMessage("Validation failed for primaryId test1113. Error: $[0].basicLocation.locationTypecode: may only be 80 characters long");
        ErrorMessageModel errorModel3 = new ErrorMessageModel();
        errorModel3.setErrorMessage("Validation failed for primaryId test1112. Error: $[0].basicLocation.locationTypecode: may only be 80 characters long");
        eventTypeModel.setErrors(Arrays.asList(errorModel, errorModel2, errorModel3));
        model.setEvents(List.of(eventTypeModel));
        return model;
    }

    public static IngestionQueryResponseModel buildIncompleteIngestionQueryResponse() {
        IngestionQueryResponseModel ingestionResponseModel = new IngestionQueryResponseModel();
        EventTypeModel eventTypeModel = new EventTypeModel();
        eventTypeModel.setStatus("COMPLETED");
        eventTypeModel.setService("validator");
        ingestionResponseModel.setEvents(List.of(eventTypeModel));
        return ingestionResponseModel;
    }

    public static IngestionResponseModel buildIngestionResponseModel() {
        IngestionResponseModel responseModel = new IngestionResponseModel();
        responseModel.setIngestionId("ingestionId");
        return responseModel;
    }

    public static DataIngestionDetails buildDataUploadDetails(String fileName, String entityType) {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setStartDateTime(OffsetDateTime.now());
        dataIngestionDetails.setFileName(fileName);
        dataIngestionDetails.setId(UUID.randomUUID());
        dataIngestionDetails.setEntityType(entityType);
        dataIngestionDetails.setStatus(IngestionStatusModel.PROCESSING.toString());
        return dataIngestionDetails;
    }

    public static CarrierServiceEntity buildCarrierServicesData() {
        return buildCarrierServicesData("carrierId", ServiceLevelCodeModel.GROUND, "parcel");
    }

    public static CarrierServiceEntity buildCarrierServicesData(String carrierId, ServiceLevelCodeModel serviceLevelCode, String serviceType) {
        CarrierServiceEntity carrierServices = new CarrierServiceEntity();
        carrierServices.setCarrierId(carrierId);
        carrierServices.setServiceLevelCode(serviceLevelCode);
        carrierServices.setBookingOrTenderingType(CarrierCharacteristicsEnumerationType.DISABLED);
        carrierServices.setAppointmentsType(CarrierCharacteristicsEnumerationType.DISABLED);
        carrierServices.setLabellingType(CarrierCharacteristicsEnumerationType.ENABLED);
        carrierServices.setTrackingType(CarrierCharacteristicsEnumerationType.DISABLED);
        carrierServices.setServiceType("Parcel");
        carrierServices.setServiceType(serviceType);
        return carrierServices;
    }

    public static CarrierSelectionRulesEntity buildServiceSelectionRuleData() {
        return PODAM_FACTORY.manufacturePojo(CarrierSelectionRulesEntity.class);
    }

    public static PartyType buildPartyTypeData(String carrierId) {
        PartyType partyType = PODAM_FACTORY.manufacturePojo(PartyType.class);
        partyType.setPartyId(carrierId);
        partyType.setDocumentActionCode(DocumentActionEnumerationType.PARTIAL_CHANGE);
        CarrierDetailsType carrierDetails = new CarrierDetailsType();
        ServiceDetailsType serviceDetails = new ServiceDetailsType();
        serviceDetails.setServiceLevelCode("GROUND");
        carrierDetails.setServiceDetails(List.of(serviceDetails));
        partyType.setCarrierDetails(carrierDetails);
        return partyType;
    }

    public static CarrierDetailsCharacteristics buildCarrierCharacteristics() {
        return PODAM_FACTORY.manufacturePojo(CarrierDetailsCharacteristics.class);
    }

    private static List<IngestionEntity> buildBuildCarrierServicesData() {
        List<IngestionEntity> persistentEntities = new ArrayList<>();
        persistentEntities.add(buildCarrierServicesData("carrierId", ServiceLevelCodeModel.GROUND, "LTL"));
        persistentEntities.add(buildCarrierServicesData("carrierId", ServiceLevelCodeModel.DELIVERY_CONFIRMATION, "Parcel"));
        return persistentEntities;
    }

    //    public static Map<DomainType, IngestionRequestPage> buildDomainResultSetMapForShipment() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.SHIPMENT);
    //        ingestionRequestPage.setHeaders(List.of("referenceNumberType", "referenceNumber", "trackingNumber", "billTo"));
    //        resultSetMap.put(DomainType.SHIPMENT, ingestionRequestPage);
    //        IngestionRequestPage ingestionRequestPage2 = new IngestionRequestPage();
    //        ingestionRequestPage2.setHeaders(List.of("referenceNumberType", "referenceNumber", "trackingNumber", "billTo"));
    //        ingestionRequestPage2.setDomainType(DomainType.SHIPMENT_LOGISTICS_UNIT);
    //        resultSetMap.put(DomainType.SHIPMENT_LOGISTICS_UNIT, ingestionRequestPage2);
    //        return resultSetMap;
    //    }

    public static ShipmentEntity buildShipmentDataRecord(String primaryId, int rowNumber) {
        ShipmentEntity shipment = PODAM_FACTORY.manufacturePojo(ShipmentEntity.class);
        shipment.setShipmentNumber(primaryId);
        shipment.getMetadata().setReferenceId(primaryId);
        shipment.setShipmentNumber("1");
        shipment.getMetadata().setRowNumber(rowNumber);
        return shipment;
    }

    //    protected static Map<DomainType, IngestionRequestPage> buildDomainResultSetMapForCommodity() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.COMMODITY, buildDomainResultSet(DomainType.COMMODITY, buildCommodityModel(), buildCommodityModel()));
    //        return resultSetMap;
    //    }

    private static CommodityEntity buildCommodityModel() {
        CommodityEntity commodity = new CommodityEntity();
        commodity.setCommodityId("commodity-001");
        commodity.getMetadata().setRowNumber(1);
        commodity.setFreightClassCode("FAK");
        return commodity;
    }

    public static DataIngestionDetails buildDataIngestionDetails() {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setStatus("PROCESSING");
        dataIngestionDetails.setId(UUID.randomUUID());
        return dataIngestionDetails;
    }

    protected static MockMultipartFile mockMultiPartReq() {
        return new MockMultipartFile("data", "filename.xlsx", "text/plain", "some kml".getBytes());
    }

    public static LocationType buildLocationType(String locationId) {
        LocationType locationType = PODAM_FACTORY.manufacturePojo(LocationType.class);
        locationType.setLocationId(locationId);
        locationType.getBasicLocation().getContact().get(0).setCommunicationChannel(buildCommunicationChannelData());
        return locationType;
    }

    private static List<CommunicationChannelType> buildCommunicationChannelData() {
        List<CommunicationChannelType> communicationChannelTypes = new ArrayList<>();
        List<CommunicationChannelCode> communicationChannelCodes = List.of(CommunicationChannelCode.EMAIL, CommunicationChannelCode.WEBSITE,
                CommunicationChannelCode.TELEPHONE, CommunicationChannelCode.TELEFAX);
        for (CommunicationChannelCode code : communicationChannelCodes) {
            CommunicationChannelType communicationChannelType = new CommunicationChannelType();
            communicationChannelType.setCommunicationChannelCode(code);
            communicationChannelType.setCommunicationValue("test1");
            communicationChannelTypes.add(communicationChannelType);
        }
        return communicationChannelTypes;
    }

    public static ShipmentEntity buildShipment(String serialNumber) {
        ShipmentEntity shipment = PODAM_FACTORY.manufacturePojo(ShipmentEntity.class);
        shipment.setOriginLocation("originLocation");
        shipment.setDestinationLocation("destinationLocation");
        shipment.setShipmentNumber(serialNumber);
        shipment.getMetadata().setErrorMessages(Collections.emptyList());
        return shipment;
    }

    public static ShipmentLogisticUnit buildLogisticUnit(String serialNumber) {
        ShipmentLogisticUnit logisticUnit = new ShipmentLogisticUnit();
        logisticUnit.setLogisticUnitName("logisticUnit");
        logisticUnit.setTotalGrossWeight(10.1);
        logisticUnit.setSerialNumber(serialNumber);
        logisticUnit.setDeclaredValue(1.0);
        logisticUnit.setCommodityId("AFN");
        return logisticUnit;
    }

    public static List<ErrorMessagesForRow> createErrorMessagesList(int rowNumber) {
        List<ErrorMessagesForRow> errorMessagesForRows = new ArrayList<>();
        ErrorMessagesForRow errorMessagesForRow = new ErrorMessagesForRow();
        errorMessagesForRow.setRowNumber(rowNumber);
        errorMessagesForRow.setErrors(List.of("test error1", "test error2"));
        errorMessagesForRows.add(errorMessagesForRow);
        return errorMessagesForRows;
    }

    //    public static Map<DomainType, IngestionRequestPage> buildDomainResultSetMapForLocation() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.LOCATION, buildDomainResultSet(DomainType.LOCATION, buildLocationModel()));
    //        return resultSetMap;
    //    }

    //    protected static Map<DomainType, IngestionRequestPage> buildDomainResultSetMapForCarrier() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.CARRIER, buildDomainResultSet(DomainType.CARRIER, buildCarrierModel()));
    //        resultSetMap.put(DomainType.CARRIER_SERVICES, buildDomainResultSet(DomainType.CARRIER_SERVICES, buildCarrierServicesData()));
    //        return resultSetMap;
    //    }

    //    private static IngestionRequestPage buildDomainResultSet(DomainType domainType, IngestionEntity... ingestionEntity) {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(domainType);
    //        ingestionRequestPage.setEntities(List.of(ingestionEntity));
    //        return ingestionRequestPage;
    //    }

    private static CustomerEntity buildCustomerModel() {
        CustomerEntity customerModel = new CustomerEntity();
        customerModel.setCustomerId("customer-id");
        customerModel.setCity("city");
        customerModel.setEmail("aaa@gma.com");
        return customerModel;
    }

    private static LocationEntity buildLocationModel() {
        LocationEntity locationModel = new LocationEntity();
        locationModel.setLocationId("location_id");
        return locationModel;
    }

    public static CarrierEntity buildCarrierModel() {
        CarrierEntity carrierModel = PODAM_FACTORY.manufacturePojo(CarrierEntity.class);
        carrierModel.setCarrierId("Carrier_id");
        carrierModel.getMetadata().setErrorMessages(Collections.emptyList());
        return carrierModel;
    }

    //    protected static Map<DomainType, IngestionRequestPage> buildDomainResultSetMapForCustomer() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.CUSTOMER, buildDomainResultSet(DomainType.CUSTOMER, buildCustomerModel()));
    //        return resultSetMap;
    //    }

    public static ZoneEntity buildZone(String zoneId) {
        ZoneEntity zone = PODAM_FACTORY.manufacturePojo(ZoneEntity.class);
        zone.setZoneIdentification(zoneId);
        zone.getGeographicAreas().get(0).setZoneIdentification(zoneId);
        zone.getMetadata().setErrorMessages(Collections.emptyList());
        return zone;
    }

    public static GeographicAreaEntity buildGeoGraphicArea() {
        GeographicAreaEntity zoneGeographicArea = PODAM_FACTORY.manufacturePojo(GeographicAreaEntity.class);
        zoneGeographicArea.getMetadata().setErrorMessages(Collections.emptyList());
        return zoneGeographicArea;
    }

    public static TransportEquipmentEntity buildTransportEquipment(String transportEquipmentId) {
        TransportEquipmentEntity transportEquipment = PODAM_FACTORY.manufacturePojo(TransportEquipmentEntity.class);
        transportEquipment.setTransportEquipmentId(transportEquipmentId);
        transportEquipment.setCommodityRestrictions(List.of(buildCommodityRestriction(transportEquipmentId)));
        transportEquipment.getMetadata().setErrorMessages(Collections.emptyList());
        transportEquipment.getMetadata().setRowNumber(1);
        return transportEquipment;
    }

    private static CommodityRestrictionEntity buildCommodityRestriction(String transportEquipmentId) {
        CommodityRestrictionEntity commodityRestrictionEntity = PODAM_FACTORY.manufacturePojo(CommodityRestrictionEntity.class);
        commodityRestrictionEntity.setTransportEquipmentId(transportEquipmentId);
        return commodityRestrictionEntity;
    }

    public static Map<String, String> getUnitOfMeasures() {
        Map<String, String> unitOfMeasures = new HashMap<>();
        unitOfMeasures.put("weight", MeasurementUnitCode.KGM.value());
        unitOfMeasures.put("length", MeasurementUnitCode.FOT.value());
        unitOfMeasures.put("currency", CurrencyCode.USD.value());
        return unitOfMeasures;
    }

    //    public static IngestionRequestPage buildZoneDomainResultSet() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.ZONE);
    //        ingestionRequestPage.setEntities(List.of(buildZone(), buildZone()));
    //        return ingestionRequestPage;
    //    }

    //    public static IngestionRequestPage buildGeoGraphicAreaDomainResultSet() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.GEOGRAPHIC_AREA);
    //        ingestionRequestPage.setEntities(List.of(buildGeoGraphicArea(), buildGeoGraphicArea()));
    //        return ingestionRequestPage;
    //    }

    //    public static IngestionRequestPage buildTransportEquipmentDomainSet() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.TRANSPORT_EQUIPMENT);
    //        ingestionRequestPage.setEntities(List.of(buildTransportEquipment("1"), buildTransportEquipment("2")));
    //        return ingestionRequestPage;
    //    }

    public static ZoneType buildZoneType() {
        return PODAM_FACTORY.manufacturePojo(ZoneType.class);
    }

    //    public static Map<DomainType, IngestionRequestPage> buildDomainResultSetForShipment(Boolean shouldAddLogisticUnit) {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.SHIPMENT, buildShipmentDomainResultSet());
    //        resultSetMap.put(DomainType.SHIPMENT_LOGISTICS_UNIT, buildLogisticUnitDomainResultSet());
    //        return resultSetMap;
    //    }

    //    private static IngestionRequestPage buildLogisticUnitDomainResultSet() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.SHIPMENT_LOGISTICS_UNIT);
    //        ingestionRequestPage.setHeaders(List.of("S. No.*", "LOGISTIC_UNIT_NAME", "COMMODITY_ID", "DECLARED_VALUE"));
    //        ingestionRequestPage.setEntities(List.of(buildLogisticUnit("1"), buildLogisticUnit("2"), buildLogisticUnit("3")));
    //        return ingestionRequestPage;
    //    }

    //    private static IngestionRequestPage buildShipmentDomainResultSet() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setHeaders(List.of(
    //                "S. No.*",
    //                "SHIPMENT_TYPE",
    //                "REFERENCE_NUMBER_TYPE",
    //                "REFERENCE_NUMBER",
    //                "CUSTOMER_ID"
    //        ));
    //        ingestionRequestPage.setDomainType(DomainType.SHIPMENT);
    //        ShipmentEntity shipmentWithOutLocation = buildShipment("1");
    //        shipmentWithOutLocation.setOriginLocation(null);
    //        shipmentWithOutLocation.setDestinationLocation(null);
    //
    //        ingestionRequestPage.setEntities(List.of(buildShipment("3"), buildShipment("2"), shipmentWithOutLocation));
    //        return ingestionRequestPage;
    //    }
}
