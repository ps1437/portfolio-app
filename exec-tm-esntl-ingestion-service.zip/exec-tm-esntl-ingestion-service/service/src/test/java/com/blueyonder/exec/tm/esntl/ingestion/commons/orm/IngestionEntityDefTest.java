/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters.NoOpConverter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class IngestionEntityDefTest {

    @Test
    void testValidEntityDef() {
        var object = new ValidEntity("test_name", true, "test_data");

        var entityDef = new IngestionEntityDef("test1", ValidEntity.class);

        assertSame(ValidEntity.class, entityDef.getType());
        assertTrue(entityDef.toString().startsWith("IngestionEntityDef"));

        var columnDefs = entityDef.getColumnDefs();
        assertNotNull(columnDefs);
        assertEquals(3, columnDefs.size());
        assertEquals(List.of("test1"), entityDef.getNameWithAlias());

        columnDefs.forEach((columnName, columnDef) -> {
            assertTrue(columnDef.getField().canAccess(object));
            assertNotNull(columnDef.getDataConverter());
        });

        IngestionEntityColumnDef typeColumnDef = entityDef.getColumnDef("Type");
        assertEquals("Type", typeColumnDef.getName());
        assertEquals("type", typeColumnDef.getFieldName());

        assertSame(typeColumnDef, entityDef.getColumnDef("OldType"));
        assertSame(typeColumnDef, entityDef.getAliasColumnDefs().get("OldType"));

        assertEquals("StringToBooleanConverter", typeColumnDef.getDataConverter().getClass().getSimpleName());
        assertInstanceOf(MyDataConverter.class, columnDefs.get("Data").getDataConverter());

        String s = typeColumnDef.toString();
        assertTrue(s.startsWith("Type"));
        assertFalse(s.contains(NoOpConverter.class.getSimpleName()));

        var anotherEntityDef = new IngestionEntityDef("test1", ValidEntity.class);
        assertTrue(Set.of(entityDef).contains(anotherEntityDef));
        assertTrue(Set.of(typeColumnDef).contains(anotherEntityDef.getColumnDef("Type")));
    }

    @Test
    void testEntityAnnotatedValidEntity() {
        var entityDef = new IngestionEntityDef(ValidEntity.class);
        var columnDefs = entityDef.getColumnDefs();
        assertNotNull(columnDefs);
        assertEquals(3, columnDefs.size());
        assertEquals(List.of("NAMED_ENTITY", "OLD_NAMED_ENTITY"), entityDef.getNameWithAlias());

        IngestionEntityColumnDef nameColumnDef = entityDef.getColumnDef("Name");

        ValidEntity obj = new ValidEntity("", true, "");
        nameColumnDef.setColumnValue(obj, "XYZ");
        assertEquals("XYZ", nameColumnDef.getColumnValue(obj));

        nameColumnDef.getField().setAccessible(false);
        assertThrows(Exception.class, () -> nameColumnDef.setColumnValue(obj, "ABCD"));
        assertThrows(Exception.class, () -> nameColumnDef.getColumnValue(obj));
    }

    @Test
    void testInvalidEntityDef() {
        IngestionEntityDef entityDef = new IngestionEntityDef("test2", InvalidEntity.class);
        assertNotNull(entityDef.getColumnDefs());
        assertEquals(0, entityDef.getColumnDefs().size());

        var anotherEntityDef = new IngestionEntityDef(InvalidEntity.class);
        assertNotEquals(entityDef, anotherEntityDef);
        assertEquals(InvalidEntity.class.getSimpleName(), anotherEntityDef.getName());
    }
}

@Entity
class InvalidEntity extends IngestionEntity {

    private final String name;

    private final Boolean type;

    InvalidEntity(String name, Boolean type) {
        this.name = name;
        this.type = type;
    }
}

@Entity(name = "NAMED_ENTITY", alias = "OLD_NAMED_ENTITY")
class ValidEntity extends IngestionEntity {

    @Column(name = "Name")
    private final String name;

    @Column(name = "Type", alias = "OldType")
    private final Boolean type;

    @Column(name = "Data", converter = MyDataConverter.class)
    private final String data;

    private final String computedData;

    ValidEntity(String name, Boolean type, String data) {
        this.name = name;
        this.type = type;
        this.data = data;
        this.computedData = "";
    }
}
