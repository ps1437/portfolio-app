/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadRequest;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.plat.lui.api.client.v1.FileStorageClient;
import com.blueyonder.plat.lui.api.model.v1.FileQueryResponseModel;
import com.blueyonder.plat.lui.api.model.v1.FileUploadRequestModel;
import com.blueyonder.plat.lui.api.model.v1.FileUploadResponseModel;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.XLSX_CONTENT_TYPE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FileStorageServiceTest {

    private static final String FILE_NAME = "test_file";

    private static final String FILE_CONTENT = "Test Content";

    private final FileStorageService fileStorageService;

    private final FileStorageClient fileStorageClient;

    @Captor
    private ArgumentCaptor<FileUploadRequestModel> fileUploadReqCaptor;

    FileStorageServiceTest() {
        this.fileStorageClient = mock(FileStorageClient.class);
        this.fileStorageService = new FileStorageService(fileStorageClient);
    }

    @Test
    void testUploadFile() {
        FileUploadResponseModel fileUploadResponse = buildFileUploadResponseModel();
        when(fileStorageClient.uploadFiles(any())).thenReturn(Flux.just(fileUploadResponse));
        FileUploadRequest request = new FileUploadRequest(FILE_NAME, FILE_CONTENT.getBytes(StandardCharsets.UTF_8), XLSX_CONTENT_TYPE);

        Flux<FileUploadResponse> publisher = fileStorageService.uploadFile(request);

        StepVerifier.create(publisher)
                .assertNext(uploadResponse -> {
                    assertNotNull(uploadResponse);
                    assertEquals(fileUploadResponse.getFileName(), uploadResponse.getFileName());
                    assertEquals(fileUploadResponse.getId(), uploadResponse.getFileId());
                }).verifyComplete();

        verify(fileStorageClient, times(1)).uploadFiles(fileUploadReqCaptor.capture());
        FileUploadRequestModel argCaptorValue = fileUploadReqCaptor.getValue();
        assertEquals(request.getFileExtension(), argCaptorValue.getExtFields());
        assertEquals(request.getFileName(), argCaptorValue.getReferenceName());
        assertNotNull(argCaptorValue.getReferenceId());
    }

    @Test
    void testUploadFileEmpty() {
        when(fileStorageClient.uploadFiles(any())).thenReturn(Flux.empty());
        FileUploadRequest request = new FileUploadRequest(FILE_NAME, FILE_CONTENT.getBytes(StandardCharsets.UTF_8), XLSX_CONTENT_TYPE);

        Flux<FileUploadResponse> publisher = fileStorageService.uploadFile(request);

        StepVerifier.create(publisher)
                .expectNextCount(0)
                .expectError(ResponseErrorMarkerException.class)
                .verify();
    }

    @Test
    void testUploadFileError() {
        when(fileStorageClient.uploadFiles(any())).thenReturn(Flux.error(new RuntimeException("File upload failed")));
        FileUploadRequest request = new FileUploadRequest(FILE_NAME, FILE_CONTENT.getBytes(StandardCharsets.UTF_8), XLSX_CONTENT_TYPE);

        Flux<FileUploadResponse> publisher = fileStorageService.uploadFile(request);

        StepVerifier.create(publisher)
                .expectNextCount(0)
                .expectError(ResponseErrorMarkerException.class)
                .verify();
    }

    @Test
    void testDownloadFile() throws IOException {
        when(fileStorageClient.downloadFileByIdAsStream(any())).thenReturn(mock(InputStream.class));

        var is = fileStorageService.downloadFile("fileId");

        verify(fileStorageClient, times(1)).downloadFileByIdAsStream(any());

        assertNotNull(is);
    }

    @Test
    void testGetFileDetails() {
        when(fileStorageClient.getFileDetailsById(any())).thenReturn(Mono.just(mock(FileQueryResponseModel.class)));

        var fileQueryResponse = fileStorageService.getFileDetails("fileId");

        verify(fileStorageClient, times(1)).getFileDetailsById(any());

        StepVerifier.create(fileQueryResponse)
                .expectNextCount(1)
                .expectComplete()
                .verify();
    }

    private FileUploadResponseModel buildFileUploadResponseModel() {
        FileUploadResponseModel fileUploadResponseModel = new FileUploadResponseModel();
        fileUploadResponseModel.setFileName("Location_ERROR_2021-12-16T16_17_17.051970900Z.xlsx");
        fileUploadResponseModel.setId("fileId");
        return fileUploadResponseModel;
    }
}
