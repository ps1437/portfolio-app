/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating.cssr;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.exec.tm.esntl.rating.api.v1.model.SelectionRulesModel;

import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildServiceSelectionRuleData;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CarrierSelectionRulesMapperTest {

    private final CarrierSelectionRulesMapper carrierSelectionRulesMapper = Mappers.getMapper(CarrierSelectionRulesMapper.class);

    @Test
    void testMapToServiceSelectionRule() {
        CarrierSelectionRulesEntity serviceSelectionRule = buildServiceSelectionRuleData();
        SelectionRulesModel selectionRulesModel = carrierSelectionRulesMapper.mapToSelectionRulesModel(serviceSelectionRule);
        assertEquals(serviceSelectionRule.getCarrierId(), selectionRulesModel.getCarrierId());
        assertEquals(serviceSelectionRule.getServiceLevelCode(), selectionRulesModel.getServiceLevelCode());
        assertEquals(serviceSelectionRule.getMaxHeight(), selectionRulesModel.getMaxHeight());
        assertEquals(serviceSelectionRule.getMinHeight(), selectionRulesModel.getMinHeight());
        assertEquals(serviceSelectionRule.getMaxWeight(), selectionRulesModel.getMaxWeight());
        assertEquals(serviceSelectionRule.getMinWeight(), selectionRulesModel.getMinWeight());
        assertEquals(serviceSelectionRule.getMinWidth(), selectionRulesModel.getMinWidth());
        assertEquals(serviceSelectionRule.getMaxWidth(), selectionRulesModel.getMaxWidth());
        assertEquals(serviceSelectionRule.getMaxLength(), selectionRulesModel.getMaxLength());
        assertEquals(serviceSelectionRule.getMinLength(), selectionRulesModel.getMinLength());
        assertEquals(serviceSelectionRule.getIncludeOriginZone(), selectionRulesModel.getIncludeOriginZone());
        assertEquals(serviceSelectionRule.getExcludeOriginZone(), selectionRulesModel.getExcludeOriginZone());
        assertEquals(serviceSelectionRule.getIncludeDestinationZone(), selectionRulesModel.getIncludeDestinationZone());
        assertEquals(serviceSelectionRule.getExcludeDestinationZone(), selectionRulesModel.getExcludeDestinationZone());
        assertEquals(serviceSelectionRule.getIncludeFreightTerms(), selectionRulesModel.getIncludeFreightTerms());
        assertEquals(serviceSelectionRule.getExcludeFreightTerms(), selectionRulesModel.getExcludeFreightTerms());
        assertEquals(stringToSet(serviceSelectionRule.getExcludeFreightClasses()), selectionRulesModel.getExcludeFreightClasses());
        assertEquals(stringToSet(serviceSelectionRule.getIncludeFreightClasses()), selectionRulesModel.getIncludeFreightClasses());
        assertEquals(stringToSet(serviceSelectionRule.getIncludeCommodityTypes()), selectionRulesModel.getIncludeCommodityTypes());
        assertEquals(stringToSet(serviceSelectionRule.getExcludeCommodityTypes()), selectionRulesModel.getExcludeCommodityTypes());
        assertEquals(stringToSet(serviceSelectionRule.getIncludeCustomers()), selectionRulesModel.getIncludeCustomers());
        assertEquals(stringToSet(serviceSelectionRule.getExcludeCustomers()), selectionRulesModel.getExcludeCustomers());
    }

    private Set<String> stringToSet(String val) {
        return Arrays.stream(val.split(",")).map(value -> value.trim()).collect(Collectors.toSet());
    }
}
