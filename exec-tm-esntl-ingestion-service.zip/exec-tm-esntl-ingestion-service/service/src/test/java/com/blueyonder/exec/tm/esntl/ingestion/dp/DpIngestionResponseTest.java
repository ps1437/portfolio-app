/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.blueyonder.exec.ecom.boot.commons.core.utils.BusinessIdUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.plat.dp.api.model.v1.ErrorMessageModel;
import com.blueyonder.plat.dp.api.model.v1.EventTypeModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;

import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpIngestionResponse.buildErrorResponse;
import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpIngestionResponse.extractPrimaryId;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DpIngestionResponseTest {

    @Test
    void testExtractPrimaryId() {
        String errorLog = String.format("%s , Validation failed for primaryId %s. Error : The value [DISTRIBUTION_CENTERs] is not a valid value for the enumeration type ", "test123", "test123");
        String primaryId = extractPrimaryId(errorLog);
        assertEquals("test123", primaryId);

        String s = UUID.randomUUID().toString();
        assertEquals(s, extractPrimaryId("my primaryId " + s + ". "));
        assertEquals(s, extractPrimaryId("my primaryId " + s + "."));
        assertEquals(s, extractPrimaryId("my primaryId " + s + ".data"));
        assertEquals(s, extractPrimaryId("my primary primaryId " + s + ". "));
        s = s.toUpperCase(Locale.getDefault());
        assertEquals(s, extractPrimaryId("my primary primaryId " + s + ". "));
        assertEquals("", extractPrimaryId("my primaryprimaryId " + s + ". data"));
        assertEquals(s, extractPrimaryId("my primaryId " + s + " "));
        s = BusinessIdUtils.generateBase32();
        assertEquals("", extractPrimaryId("my primaryId " + s));
        assertEquals(s, extractPrimaryId("my primaryId " + s + " "));
        assertEquals(s, extractPrimaryId("my primaryId " + s + "."));
        assertEquals("", extractPrimaryId("hell primaryId12345"));
    }

    @Test
    void testBuildErrorResponseEmpty() {
        IngestionQueryResponseModel o = new IngestionQueryResponseModel();
        o.setEvents(List.of());
        assertTrue(buildErrorResponse(o).isEmpty());
    }

    @Test
    void testBuildErrorResponse() {
        var emm1 = new ErrorMessageModel();
        emm1.setErrorMessage("Validation failed for primaryId external-id-1.");
        var emm2 = new ErrorMessageModel();
        emm2.setErrorMessage("Validation failed for primaryId external-id-2.");
        var etm = new EventTypeModel();
        etm.setService("validator");
        etm.setStatus("COMPLETED_WITH_ERROR");
        etm.setErrors(List.of(emm1, emm2));
        var o = new IngestionQueryResponseModel();
        o.setEvents(List.of(etm));

        var map = buildErrorResponse(o);
        assertEquals(1, map.get("external-id-1").size());
        assertEquals(1, map.get("external-id-2").size());
    }

    @Test
    void testDpIngestionResponse() {
        UUID requestId = UUID.randomUUID();
        IngestionRequest ingestionRequest = new IngestionRequest("",  List.of());
        ingestionRequest.setRequestId(requestId);
        IngestionQueryResponseModel ingestionResponseModel = new IngestionQueryResponseModel();
        ingestionResponseModel.setEvents(List.of());

        DpIngestionResponse response = new DpIngestionResponse(ingestionRequest, ingestionResponseModel);
        assertEquals(requestId, response.getIngestionRequest().getRequestId());
        assertSame(ingestionRequest, response.getIngestionRequest());
        assertSame(ingestionResponseModel, response.getIngestionResponseModel());
        assertTrue(response.getErrorResponse().isEmpty());
    }
}
