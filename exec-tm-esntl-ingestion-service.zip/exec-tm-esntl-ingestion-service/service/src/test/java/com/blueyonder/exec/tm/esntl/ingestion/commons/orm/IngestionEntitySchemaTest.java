/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.blueyonder.exec.tm.esntl.ingestion.commons.ChildEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.ParentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class IngestionEntitySchemaTest {

    @Test
    void testValidSchemaWithOneToMany() {
        IngestionEntitySchema schema = IngestionEntitySchema.of(ParentEntity.class);
        assertTrue(schema.toString().startsWith("IngestionEntitySchema"));
        assertEquals(1, schema.getRootEntityDefs().size());
        assertEquals(2, schema.getEntityDefs().size());
        assertEquals(Set.of("ParentEntity", "ChildEntity"), schema.getEntityDefs().keySet());

        assertNotNull(schema.getEntityDef("ParentEntity"));

        ParentEntity o = new ParentEntity();
        assertTrue(schema.getEntityDef("ChildEntity").getParentEntityOneToManyDef().parentEntityField().canAccess(o));
    }

    @Test
    void testInvalidSchema() {
        IngestionEntitySchema schema = IngestionEntitySchema.of(ParentEntity.class);
        IngestionEntityDef entityDef = schema.getEntityDef("ChildEntity");
        assertNotNull(entityDef);
        assertThrows(IllegalArgumentException.class, () -> IngestionEntitySchema.of(entityDef));
        assertThrows(IllegalArgumentException.class, () -> IngestionEntitySchema.of(List.of(
                new IngestionEntityDef(ParentEntity.class), new IngestionEntityDef(ChildEntity.class))));
    }

    @Test
    void testInvalidOneToMany() {
        assertThrows(IllegalArgumentException.class, () -> new IngestionEntityDef(ParentEntityNoId.class));
        assertThrows(IllegalArgumentException.class, () -> new IngestionEntityDef(ParentEntityBadJoinColumn.class));
        assertThrows(IllegalArgumentException.class, () -> new IngestionEntityDef(ParentEntityBadJoinFieldType.class));
        assertThrows(IllegalArgumentException.class, () -> new IngestionEntityDef(ParentEntitySelfJoin.class));
    }

    @Test
    void testOneToManyHandler() {
        IngestionEntityDef entityDef = new IngestionEntityDef(ParentEntity.class);
        var p1 = new ParentEntity("id1", "data-1");
        var p2 = new ParentEntity("id2", "data-2");
        Map<Object, ParentEntity> map = Map.of(p1.getId(), p1, p2.getId(), p2);

        var oneToManyHandler = new OneToManyHandler(entityDef.getChildEntityDefs().iterator()
                .next().getChildEntityDef(), map);

        // Good parent-child
        var c1 = new ChildEntity("id1", "extra-data-1");
        oneToManyHandler.accept(c1);
        assertEquals(p1.getId(), c1.getMetadata().getReferenceId());
        assertTrue(p1.getChildEntities().contains(c1));
        assertFalse(p1.getMetadata().hasError());

        // Child with error. Hence, parent should be also marked as error
        var c2 = new ChildEntity("id1", "extra-data-2");
        c2.getMetadata().addErrorMessage("error");
        assertTrue(c2.getMetadata().hasError());
        oneToManyHandler.accept(c2);
        assertEquals(p1.getId(), c2.getMetadata().getReferenceId());
        assertTrue(p1.getChildEntities().contains(c2));
        assertTrue(p1.getMetadata().hasError());

        // Earlier parent was marked as error. Hence, new valid child should be also marked as error
        var c3 = new ChildEntity("id1", "extra-data-2");
        assertFalse(c3.getMetadata().hasError());
        oneToManyHandler.accept(c3);
        assertEquals(p1.getId(), c3.getMetadata().getReferenceId());
        assertTrue(p1.getChildEntities().contains(c3));
        assertTrue(c3.getMetadata().hasError());

        // Invalid join id. Hence, child should be marked as error
        var c4 = new ChildEntity("x", "extra-data-3");
        assertFalse(c4.getMetadata().hasError());
        oneToManyHandler.accept(c4);
        assertEquals("x", c4.getMetadata().getReferenceId());
        assertFalse(p1.getChildEntities().contains(c4));
        assertTrue(c4.getMetadata().hasError());
    }

    @Test
    void testIngestionRequestEntityDef() {
        IngestionEntityDef entityDef = new IngestionEntityDef(ParentEntity.class);

        IngestionRequestEntityDef requestEntityDef = new IngestionRequestEntityDef(entityDef, true);
        assertEquals(entityDef.getColumnDefs().size(), requestEntityDef.getRequestColumnDefs().size());

        requestEntityDef = new IngestionRequestEntityDef(entityDef, false);
        assertTrue(requestEntityDef.getRequestColumnDefs().isEmpty());

        requestEntityDef = new IngestionRequestEntityDef(entityDef);
        assertTrue(requestEntityDef.getRequestColumnDefs().isEmpty());

        // Mandatory column
        requestEntityDef.addColumnDef("id*");
        assertSame(entityDef.getColumnDef("id"), requestEntityDef.getRequestColumnDefs().get("id*"));

        // Column with comments
        requestEntityDef.addColumnDef("name (xyz)");
        assertSame(entityDef.getColumnDef("name"), requestEntityDef.getRequestColumnDefs().get("name (xyz)"));

        // Duplicate column
        String generatedKey = "id*(INVALID_" + requestEntityDef.getRequestColumnDefs().size() + ")";
        requestEntityDef.addColumnDef("id*");
        assertTrue(requestEntityDef.getRequestColumnDefs().containsKey(generatedKey));
        assertNull(requestEntityDef.getRequestColumnDefs().get(generatedKey));

        // Unknown column
        generatedKey = "C1(INVALID_" + requestEntityDef.getRequestColumnDefs().size() + ")";
        requestEntityDef.addColumnDef("C1");
        assertTrue(requestEntityDef.getRequestColumnDefs().containsKey(generatedKey));
        assertNull(requestEntityDef.getRequestColumnDefs().get(generatedKey));

        // Standard test...
        requestEntityDef = new IngestionRequestEntityDef(entityDef);

        // * and comments
        requestEntityDef.addColumnDef("id* (xyz)   ");
        assertSame(entityDef.getColumnDef("id* (xyz)"), requestEntityDef.getRequestColumnDefs().get("name"));

        // Simple column
        requestEntityDef.addColumnDef("name");
        assertSame(entityDef.getColumnDef("name"), requestEntityDef.getRequestColumnDefs().get("name"));

        // Validity test...
        requestEntityDef = new IngestionRequestEntityDef(entityDef);
        assertFalse(requestEntityDef.isValid());

        requestEntityDef.addColumnDef("xyz");
        assertFalse(requestEntityDef.isValid());
    }

    @Test
    void testIngestionCreateEntity() {
        IngestionEntityDef entityDef = new IngestionEntityDef(ParentEntity.class);
        IngestionRequestEntityDef requestEntityDef = new IngestionRequestEntityDef(entityDef);

        assertTrue(requestEntityDef.toString().startsWith("IngestionRequestEntityDef"));
        assertEquals("ParentEntity", requestEntityDef.getName());

        // No request columns
        assertNull(requestEntityDef.createEntity(List.of("id-1", "name-1")));

        // Happy path
        requestEntityDef.addColumnDef("id");
        requestEntityDef.addColumnDef("name");
        ParentEntity entity = requestEntityDef.createEntity(List.of("id-1", "name-1"));
        assertEquals("id-1", entity.getId());

        // Blank string
        entity = requestEntityDef.createEntity(List.of("id-1", "   "));
        assertNull(entity.getName());

        // No data
        entity = requestEntityDef.createEntity(List.of());
        assertNull(entity);

        // Unknown column
        requestEntityDef.addColumnDef("C1");
        entity = requestEntityDef.createEntity(List.of("id-1", "name-1  "));
        assertEquals("name-1", entity.getName());

        // Exception...
        requestEntityDef.getRequestColumnDefs().get("id").getField().setAccessible(false);
        entity = requestEntityDef.createEntity(List.of("id-1", "name-1  "));
        assertNull(entity.getId());
        assertTrue(entity.getMetadata().getErrorMessages().stream()
                .anyMatch(s -> s.contains("not access method")));
    }
}

@Entity
class ParentEntityNoId extends IngestionEntity {

    @Column
    private String id;

    @Column
    private String name;

    @OneToMany(joinColumnName = "parentId")
    private List<ChildEntity> childEntities;
}

@Entity
class ParentEntityBadJoinColumn extends IngestionEntity {

    @Column
    private String id;

    @Column
    private String name;

    @OneToMany(joinColumnName = "randomId")
    private List<ChildEntity> childEntities;
}

@Entity
class ParentEntityBadJoinFieldType extends IngestionEntity {

    @Column
    private String id;

    @Column
    private String name;

    @OneToMany(joinColumnName = "parentId")
    private ChildEntity childEntity;
}

@Entity
class ParentEntitySelfJoin extends IngestionEntity {

    @Column
    private String id;

    @Column
    private String name;

    @OneToMany(joinColumnName = "id")
    private List<ParentEntitySelfJoin> childEntities;
}
