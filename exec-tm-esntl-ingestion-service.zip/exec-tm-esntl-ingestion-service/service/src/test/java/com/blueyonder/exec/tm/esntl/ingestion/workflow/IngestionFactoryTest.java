/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierIngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierMapper;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierServiceMapper;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class IngestionFactoryTest {

    private final IngestionFactory ingestionFactory;

    IngestionFactoryTest() {
        CarrierIngestionService carrierIngestionService = new CarrierIngestionService(
                mock(DpClient.class),
                mock(PartyDpClient.class),
                mock(DataStorageService.class),
                mock(PostIngestionService.class),
                mock(CarrierMapper.class),
                mock(CarrierServiceMapper.class),
                mock(IngestionConfigProperties.class));
        this.ingestionFactory = new IngestionFactory(List.of(carrierIngestionService));
    }

    @Test
    void testGetIngestionProvider() {
        IngestionService ingestionService = ingestionFactory.getIngestionService(IngestionType.CARRIER);
        assertEquals(IngestionType.CARRIER, ingestionService.getType());
    }

    @Test
    void testGetIngestionProviderException() {
        try {
            ingestionFactory.getIngestionService(IngestionType.COMMODITY);
        }
        catch (Exception exception) {
            assertTrue(exception instanceof IllegalArgumentException);
        }
    }
}
