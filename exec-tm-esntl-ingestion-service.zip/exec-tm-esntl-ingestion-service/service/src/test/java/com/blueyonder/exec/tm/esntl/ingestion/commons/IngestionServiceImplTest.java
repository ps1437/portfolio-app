/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

import static org.junit.jupiter.api.Assertions.assertThrows;

class IngestionServiceImplTest {

    private static final IngestionEntitySchema SCHEMA = IngestionEntitySchema.of(ParentEntity.class);

    private static final IngestionServiceImpl SERVICE = new IngestionServiceImpl() {

        @Override
        public IngestionType getType() {
            return null;
        }

        @Override
        public IngestionEntitySchema getEntitySchema() {
            return SCHEMA;
        }

        @Override
        protected DataIngestionDetails ingest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
            return null;
        }
    };

    @Test
    void testInvalidIngestionRequest() {
        var request1 = new IngestionRequest("", List.of());
        assertThrows(ResponseErrorMarkerException.class, () -> SERVICE.ingest(request1));

        var entityDef = new IngestionEntityDef(ParentEntity.class);
        var requestEntityDef = new IngestionRequestEntityDef(entityDef, true);
        var request2 = new IngestionRequest("",  List.of(requestEntityDef));
        assertThrows(ResponseErrorMarkerException.class, () -> SERVICE.ingest(request2));
    }
}
