/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file;

import java.io.IOException;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;

import com.blueyonder.exec.ecom.boot.commons.web.error.BadRequestAppException;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.dp.location.LocationIngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionFactory;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionSourceFactory;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.TemplateService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FileProcessServiceTest {

    private final FileProcessService fileProcessService;

    private HttpServletResponse httpServletResponse;

    private final LocationIngestionService locationIngestionService;

    @Captor
    private ArgumentCaptor<String> argumentCaptor;

    FileProcessServiceTest() {
        locationIngestionService = mock(LocationIngestionService.class);
        when(locationIngestionService.getType()).thenCallRealMethod();
        when(locationIngestionService.getEntitySchema()).thenCallRealMethod();
        fileProcessService = new FileProcessService(
                new TemplateService(new DefaultResourceLoader()),
                null,
                new IngestionFactory(List.of(locationIngestionService)),
                new IngestionSourceFactory());
    }

    @BeforeEach
    void setup() {
        httpServletResponse = mock(HttpServletResponse.class);
        ReflectionTestUtils.setField(fileProcessService, "response", httpServletResponse);
    }

    @Test
    void testGetTemplateByIdAll() throws IOException {
        when(httpServletResponse.getOutputStream()).thenReturn(mock(ServletOutputStream.class));
        fileProcessService.downloadEntityTemplates(Set.of(TemplateTypeModel.ALL));

        verify(httpServletResponse, times(1)).getOutputStream();
        verify(httpServletResponse, times(1)).setHeader(any(), argumentCaptor.capture());
        assertEquals("attachment;filename=templates.zip", argumentCaptor.getValue());
    }

    @Test
    void testGetTemplateByIdSingleFile() throws IOException {
        when(httpServletResponse.getOutputStream()).thenReturn(mock(ServletOutputStream.class));

        fileProcessService.downloadEntityTemplates(Set.of(TemplateTypeModel.CUSTOMER));

        verify(httpServletResponse, times(1)).getOutputStream();
        verify(httpServletResponse, times(1)).setHeader(any(), argumentCaptor.capture());
        verify(httpServletResponse, times(1)).flushBuffer();
        assertEquals("attachment;filename=Customer.xlsx", argumentCaptor.getValue());
    }

    @Test
    void testGetTemplateByIdForCarrierServices() throws IOException {
        when(httpServletResponse.getOutputStream()).thenReturn(mock(ServletOutputStream.class));

        fileProcessService.downloadEntityTemplates(Set.of(TemplateTypeModel.CARRIER_SERVICES_SELECTION_RULES));

        verify(httpServletResponse, times(1)).getOutputStream();
        verify(httpServletResponse, times(1)).setHeader(any(), argumentCaptor.capture());
        verify(httpServletResponse, times(1)).flushBuffer();
        assertEquals("attachment;filename=CarrierServicesSelectionRules.xlsx", argumentCaptor.getValue());
    }

    @Test
    void testGetTemplates() {
        Map<String, String> files = fileProcessService.getEntitiesList();

        assertEquals(TemplateTypeModel.values().length - 1, files.size());
        assertEquals("Carrier", files.get(TemplateTypeModel.CARRIER.getValue()));
    }

    @Test
    void testProcessStatusProcessing() throws IOException {
        MultipartFile multipartFile = buildMultiPartRequest("/Location.xlsx", "Location", "Location.xlsx");

        DataIngestionDetails dataIngestionDetails = buildDataUploadDetails();
        when(locationIngestionService.ingest(any(IngestionRequest.class))).thenReturn(dataIngestionDetails);

        DataIngestionDetailsModel dataIngestionDetailsModel = new DataIngestionDetailsModel();
        dataIngestionDetailsModel.setStatus(IngestionStatusModel.PROCESSING);

        var response = fileProcessService.process(multipartFile, IngestionType.LOCATION);

        assertNotNull(response);
        assertEquals(IngestionStatusModel.PROCESSING.toString(), response.getStatus());
        verify(locationIngestionService, times(1)).ingest(any(IngestionRequest.class));
    }

    @Test
    void testProcessResponseStatusException() throws IOException {
        MultipartFile multipartFile = buildMultiPartRequest("/Location.xlsx", "Location", "Location.xlsx");

        when(locationIngestionService.ingest(any(IngestionRequest.class))).thenThrow(BadRequestAppException.class);

        assertThrows(BadRequestAppException.class, () -> fileProcessService.process(multipartFile, IngestionType.LOCATION));
    }

    private MultipartFile buildMultiPartRequest(String filePath, String fileName, String originalFilename) throws IOException {
        InputStream inputStream = getClass().getResourceAsStream(filePath);
        return new MockMultipartFile(fileName,
                originalFilename, "application/vnd.ms-excel", IOUtils.toByteArray(inputStream));
    }

    private DataIngestionDetails buildDataUploadDetails() {
        DataIngestionDetails o = new DataIngestionDetails();
        o.setId(UUID.randomUUID());
        o.setEntityType(IngestionType.LOCATION.name());
        o.setFileName("Location.csv");
        o.setStartDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        o.setStatus(IngestionStatusModel.PROCESSING.toString());
        return o;
    }
}
