/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import java.time.OffsetDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.blueyonder.plat.dp.bydm.CountryCode;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ShipmentTest {

    @Test
    void testAfterPropertiesSetOriginDestinationEmpty() {
        ShipmentEntity shipment = new ShipmentEntity();

        shipment.postConstruct();

        List<String> errors = shipment.getMetadata().getErrorMessages();

        assertNotNull(errors);
        assertTrue(errors.size() > 0);
        assertTrue(errors.get(0).contains("Origin"));
        assertTrue(errors.get(1).contains("Destination"));
    }

    @Test
    void testAfterPropertiesSetOriginDestinationSame() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.setOriginLocation("TEST001");
        shipment.setDestinationLocation("TEST001");

        shipment.postConstruct();

        List<String> errors = shipment.getMetadata().getErrorMessages();

        assertNotNull(errors);
        assertTrue(errors.size() > 0);
        assertTrue(errors.get(0).contains("locationId"));
    }

    @Test
    void testAfterPropertiesSetDateTimeError() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.setOriginLocation("origin");
        shipment.setDestinationLocation("destination");
        shipment.setPlannedBeginDateTime(OffsetDateTime.now().plusDays(2));
        shipment.setDispatchBeginDateTime(OffsetDateTime.now());

        shipment.postConstruct();

        List<String> errors = shipment.getMetadata().getErrorMessages();

        assertNotNull(errors);
        assertTrue(errors.size() > 0);

        assertTrue(errors.get(0).contains("Pickup"));
    }

    @Test
    void testAfterPropertiesSetOriginDestinationError() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.setOriginCountryCode(CountryCode.DE);
        shipment.setDestinationCountryCode(CountryCode.DE);
        shipment.postConstruct();

        List<String> errors = shipment.getMetadata().getErrorMessages();

        assertNotNull(errors);
        assertTrue(errors.size() > 0);
        assertTrue(errors.get(0).contains("Origin"));
        assertTrue(errors.get(1).contains("Destination"));
    }

}
