package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageDataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageableModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryEntryModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryPaginationModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.SortModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.MetaDataDetailsService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileProcessService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith({ MockitoExtension.class })
class DataIngestionControllerTest {

    @InjectMocks
    private DataIngestionController dataIngestionController;

    @Mock
    private FileProcessService fileService;

    @Mock
    private MetaDataDetailsService metaDataDetailsService;

    private static MultipartFile buildMultiPartRequest(String fileName) throws IOException {
        try (InputStream in = new ClassPathResource(fileName).getInputStream()) {
            return new MockMultipartFile(fileName, fileName, "application/vnd.ms-excel", IOUtils.toByteArray(in));
        }
    }

    @Test
    void getEntitiesList() {
        Map<String, String> map = new HashMap<>();
        map.put("Location", "Location.csv");
        when(fileService.getEntitiesList()).thenReturn(map);

        ResponseEntity<Map<String, String>> templates = dataIngestionController.getEntitiesList();

        assertNotNull(templates.getBody());
        assertEquals(1, templates.getBody().size());
        assertEquals("Location.csv", templates.getBody().get("Location"));
    }

    @Test
    void testGetIngestionMetaData() {
        when(metaDataDetailsService.loadAllIngestionMetaData()).thenReturn(List.of(buildModelResponse()));

        ResponseEntity<List<DataIngestionDetailsModel>> response = dataIngestionController.getIngestionMetadata();

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertTrue(response.getStatusCode().is2xxSuccessful());
        DataIngestionDetailsModel result = response.getBody().get(0);
        assertEquals("test", result.getFileName());
    }

    @Test
    void testDownloadTemplateSingleFile() {
        dataIngestionController.downloadEntityTemplate(Set.of(TemplateTypeModel.ZONE));

        verify(fileService, times(1)).downloadEntityTemplates(any());
    }

    @Test
    void testDownloadTemplateWithEmptyName() {
        assertThrows(ResponseStatusException.class, () -> dataIngestionController.downloadEntityTemplate(Collections.emptySet()));
    }

    @Test
    void testUploadFile() throws IOException {
        when(fileService.process(any(), any())).thenReturn(buildResponse());

        MultipartFile multipartFile = buildMultiPartRequest("Commodity.xlsx");
        ResponseEntity<DataIngestionDetailsModel> response = dataIngestionController.upload(EntityTypeModel.COMMODITY, multipartFile);
        assertNotNull(response.getBody());
        assertEquals("test", response.getBody().getFileName());
    }

    @Test
    void testUploadFileWithEmptyFile() throws IOException {
        when(fileService.process(any(), any())).thenThrow(new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                "Uploaded file is empty."));

        MultipartFile multipartFile = buildMultiPartRequest("Commodity_Empty.xlsx");

        assertThrows(ResponseStatusException.class, () -> dataIngestionController.upload(EntityTypeModel.COMMODITY, multipartFile));
    }

    @Test
    void testSearch() {
        QueryPaginationModel pagination = new QueryPaginationModel();
        pagination.setLimit(3);
        pagination.setOffset(0);
        List<QueryEntryModel> filter = new ArrayList<>();
        QueryEntryModel queryEntry = new QueryEntryModel();
        queryEntry.setOperation("gte");
        queryEntry.setKey("startDateTime");
        queryEntry.setValue("2022-01-10");
        filter.add(queryEntry);
        QueryModel query = new QueryModel();
        query.setFilter(filter);
        query.setPagination(pagination);
        when(metaDataDetailsService.queryIngestionMetaData(any())).thenReturn(buildSearchResponse());

        ResponseEntity<PageDataIngestionDetailsModel> response = dataIngestionController.search(query);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertTrue(response.getStatusCode().is2xxSuccessful());
        PageDataIngestionDetailsModel result = response.getBody();
        assertEquals(1, result.getTotalPages());
        assertEquals(1, result.getSize());
    }

    private DataIngestionDetailsModel buildModelResponse() {
        DataIngestionDetailsModel dataIngestionDetails = new DataIngestionDetailsModel();
        dataIngestionDetails.setFileName("test");
        return dataIngestionDetails;
    }

    private DataIngestionDetails buildResponse() {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setFileName("test");
        dataIngestionDetails.setEntityType(EntityTypeModel.LOCATION.name());
        return dataIngestionDetails;
    }

    private PageDataIngestionDetailsModel buildSearchResponse() {
        PageDataIngestionDetailsModel pageDataIngestionDetailsModel = new PageDataIngestionDetailsModel();
        List<DataIngestionDetailsModel> dataIngestionDetailsModels = new ArrayList<>();
        DataIngestionDetailsModel dataIngestionDetailsModel = new DataIngestionDetailsModel();
        dataIngestionDetailsModel.setStatus(IngestionStatusModel.COMPLETED_WITH_ERRORS);
        dataIngestionDetailsModels.add(dataIngestionDetailsModel);
        pageDataIngestionDetailsModel.setContent(dataIngestionDetailsModels);
        pageDataIngestionDetailsModel.setTotalPages(1);
        pageDataIngestionDetailsModel.setSize(1);
        pageDataIngestionDetailsModel.setNumber(0);
        SortModel sortModel = new SortModel();
        sortModel.setSorted(false);
        sortModel.setUnsorted(true);
        sortModel.setEmpty(true);
        pageDataIngestionDetailsModel.setSort(sortModel);
        pageDataIngestionDetailsModel.setNumberOfElements(1);
        pageDataIngestionDetailsModel.setFirst(true);
        pageDataIngestionDetailsModel.setLast(true);
        PageableModel pageableModel = new PageableModel();
        pageableModel.setPaged(true);
        pageableModel.setOffset(0L);
        pageableModel.setPageNumber(1);
        pageableModel.paged(true);
        pageableModel.unpaged(false);
        pageableModel.setPageSize(1);
        pageDataIngestionDetailsModel.setPageable(pageableModel);
        return pageDataIngestionDetailsModel;
    }
}
