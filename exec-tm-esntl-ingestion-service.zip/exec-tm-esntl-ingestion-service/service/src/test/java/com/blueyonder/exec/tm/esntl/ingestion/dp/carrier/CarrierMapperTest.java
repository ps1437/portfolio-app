/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ServiceLevelCodeModel;
import com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationType;
import com.blueyonder.plat.dp.bydm.AdditionalPartyIdentificationTypeCode;
import com.blueyonder.plat.dp.bydm.CarrierDetailsCharacteristicsType;
import com.blueyonder.plat.dp.bydm.FinancialDetails;
import com.blueyonder.plat.dp.bydm.PartyContactType;
import com.blueyonder.plat.dp.bydm.PartyType;
import com.blueyonder.plat.dp.bydm.ServiceDetailsType;

import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildCarrierCharacteristics;
import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildCarrierModel;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class CarrierMapperTest {

    private final CarrierMapper carrierMapper = Mappers.getMapper(CarrierMapper.class);

    private static CarrierService buildCarrierData() {
        CarrierService carrierData = new CarrierService();
        carrierData.setCarrierId("Carrier_id");
        carrierData.setServiceDetails(Set.of(
                createServiceDetails(ServiceLevelCodeModel.NEXT_DAY_AIR, "parcel"),
                createServiceDetails(ServiceLevelCodeModel.SAME_DAY, "LTL"),
                createServiceDetails(ServiceLevelCodeModel.GROUND, "LTL"))
        );
        return carrierData;
    }

    private static ServiceDetail createServiceDetails(ServiceLevelCodeModel serviceLevelCodeModel, String carrierType) {
        ServiceDetail serviceDetail = new ServiceDetail();
        serviceDetail.setCarrierType(carrierType);
        serviceDetail.setServiceLevelCode(serviceLevelCodeModel);
        return serviceDetail;
    }

    @Test
    void testCarrierMapper() {
        CarrierEntity carrier = buildCarrierModel();
        PartyType partyType = carrierMapper.mapToPartyType(carrier);

        List<PartyContactType> contactTypes = partyType.getBasicParty().getPartyContact();
        assertNotNull(contactTypes);
        assertEquals(carrier.getEmail(), contactTypes.get(0).getCommunicationChannel().get(0).getCommunicationValue());
        assertEquals(carrier.getPersonName(), contactTypes.get(0).getPersonName());

        List<AdditionalPartyIdentificationType> additionalPartyIdentificationTypes = partyType.getBasicParty().getAdditionalPartyId();
        assertEquals(3, additionalPartyIdentificationTypes.size());
        assertEquals(AdditionalPartyIdentificationTypeCode.SCAC, additionalPartyIdentificationTypes.get(0).getTypeCode());
        assertEquals(carrier.getScac(), additionalPartyIdentificationTypes.get(0).getValue());
        assertEquals(AdditionalPartyIdentificationTypeCode.CARRIER_ASSIGNED_NUMBER, additionalPartyIdentificationTypes.get(1).getTypeCode());
        assertEquals(carrier.getCarrierAccountNumber(), additionalPartyIdentificationTypes.get(1).getValue());
        assertEquals(AdditionalPartyIdentificationTypeCode.BYN_IDENTIFIER, additionalPartyIdentificationTypes.get(2).getTypeCode());
        assertEquals(carrier.getExternalCarrierCode(), additionalPartyIdentificationTypes.get(2).getValue());

        FinancialDetails financialDetails = partyType.getBasicParty().getFinancialInformation();

        assertEquals(carrier.getArAccountNumber(), financialDetails.getAccountNumberReceivable());
        assertEquals(carrier.getApAccountNumber(), financialDetails.getAccountNumberPayable());
        assertEquals(carrier.getTenderResponseTimeHrs(), partyType.getCarrierDetails().getTenderResponseTime());
        assertEquals(carrier.getPickupLeadTimeHrs(), partyType.getCarrierDetails().getMinimumPickUpTime());
        assertEquals(carrier.getCurrencyCode(), partyType.getBasicParty().getPartyAddress().getCurrencyOfPartyCode());
    }

    @Test
    void testMapToFinancialDetailsIfAccNumInfoEmpty() {
        CarrierEntity carrierModel = buildCarrierModel();
        carrierModel.setApAccountNumber(null);
        carrierModel.setArAccountNumber(null);

        FinancialDetails financialDetails = carrierMapper.mapToFinancialInformation(carrierModel);

        assertNull(financialDetails);
    }

    @Test
    void testMapToCarrierCharacteristicsDetailsTypeInfoPresent() {
        CarrierDetailsCharacteristics carrierDetailsCharacteristics = buildCarrierCharacteristics();

        CarrierDetailsCharacteristicsType carrierDetailsCharacteristicsType = carrierMapper.mapToCarrierCharacteristics(carrierDetailsCharacteristics);

        assertEquals(carrierDetailsCharacteristics.getBookingCutoffTimeOfDay(), carrierDetailsCharacteristicsType.getBookingCutoffTimeOfDay());
        assertEquals(carrierDetailsCharacteristics.getPickupLeadTime(), carrierDetailsCharacteristicsType.getPickupLeadTime());
        assertEquals(carrierDetailsCharacteristics.getAppointmentsType(), carrierDetailsCharacteristicsType.getAppointmentsType());
        assertEquals(carrierDetailsCharacteristics.getAppointmentsType(), carrierDetailsCharacteristicsType.getAppointmentsType());
        assertEquals(carrierDetailsCharacteristics.getLabellingType(), carrierDetailsCharacteristicsType.getLabellingType());
        assertEquals(carrierDetailsCharacteristics.getBookingOrTenderingType(), carrierDetailsCharacteristicsType.getBookingOrTenderingType());
    }

    @Test
    void testMapToServiceDetails() {
        CarrierService carrierDataModel = buildCarrierData();
        ServiceDetail serviceDetail = carrierDataModel.getServiceDetails().iterator().next();
        CarrierEntity carrierModel = buildCarrierModel();
        carrierModel.setCarrierService(carrierDataModel);

        List<ServiceDetailsType> serviceDetailsTypes = carrierMapper.mapToServiceDetails(carrierModel);

        assertEquals(serviceDetail.getCarrierType(), serviceDetailsTypes.get(0).getCarrierType());
        assertEquals(serviceDetail.getServiceLevelCode().getValue(), serviceDetailsTypes.get(0).getServiceLevelCode());
        assertEquals(serviceDetail.getAvpList(), serviceDetailsTypes.get(0).getAvpList());
    }
}
