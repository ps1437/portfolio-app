package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageDataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.dp.PageDataIngestionDetailsModelMapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class PageDataIngestionDetailsModelMapperTest {

    @InjectMocks
    private PageDataIngestionDetailsModelMapper pageDataIngestionDetailsModelMapper;

    @Test
    void testMapToPageDataIngestionDetailsModel() {
        Pageable page = PageRequest.of(1, 1);
        DataIngestionDetails dataIngestionDetail = new DataIngestionDetails();
        dataIngestionDetail.setStatus("COMPLETED_WITH_ERROR");
        Page<DataIngestionDetails> pagedataIngestionDetails = new PageImpl<>(List.of(dataIngestionDetail), page, 1L);
        PageDataIngestionDetailsModel dataIngestionDetailsModels = PageDataIngestionDetailsModelMapper.mapToPageDataIngestionDetailsModel(page, pagedataIngestionDetails);
        assertNotNull(dataIngestionDetailsModels);
        assertEquals(pagedataIngestionDetails.getTotalElements(), dataIngestionDetailsModels.getTotalElements());
        assertEquals(pagedataIngestionDetails.getTotalPages(), dataIngestionDetailsModels.getTotalPages());
        assertEquals(pagedataIngestionDetails.getSize(), dataIngestionDetailsModels.getSize());
        assertEquals(pagedataIngestionDetails.getNumber(), dataIngestionDetailsModels.getNumber());
        assertEquals(pagedataIngestionDetails.getSort().isSorted(), dataIngestionDetailsModels.getSort().getSorted());
        assertEquals(pagedataIngestionDetails.getSort().isUnsorted(), dataIngestionDetailsModels.getSort().getUnsorted());
        assertEquals(pagedataIngestionDetails.getNumberOfElements(), dataIngestionDetailsModels.getNumberOfElements());
        assertEquals(pagedataIngestionDetails.getSort().isEmpty(), dataIngestionDetailsModels.getSort().getEmpty());
        assertEquals(pagedataIngestionDetails.isFirst(), dataIngestionDetailsModels.getFirst());
        assertEquals(pagedataIngestionDetails.isLast(), dataIngestionDetailsModels.getLast());
        assertEquals(pagedataIngestionDetails.getPageable().getPageSize(), dataIngestionDetailsModels.getPageable().getPageSize());
        assertNotNull(dataIngestionDetailsModels.getPageable().getPaged());
        assertEquals(pagedataIngestionDetails.getPageable().isPaged(), dataIngestionDetailsModels.getPageable().getPaged());
        assertEquals(pagedataIngestionDetails.getPageable().getOffset(), dataIngestionDetailsModels.getPageable().getOffset());
        assertEquals(pagedataIngestionDetails.getPageable().getPageNumber(), dataIngestionDetailsModels.getPageable().getPageNumber());
        assertEquals(page.isPaged(), dataIngestionDetailsModels.getPageable().getPaged());
    }
}
