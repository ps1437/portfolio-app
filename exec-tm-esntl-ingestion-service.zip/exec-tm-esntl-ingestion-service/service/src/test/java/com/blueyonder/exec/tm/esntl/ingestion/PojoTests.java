/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionEntityMetadata;
import com.blueyonder.exec.tm.esntl.ingestion.commons.validation.ValidationEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DataUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierDetailsCharacteristics;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierService;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierServiceEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.ServiceDetail;
import com.blueyonder.exec.tm.esntl.ingestion.dp.commodity.CommodityEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.customer.CustomerEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.location.EquipmentRestrictionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.location.LocationEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.shipment.ShipmentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.shipment.ShipmentLogisticUnit;
import com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment.CommodityRestrictionEntity;
import com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment.TransportEquipmentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.rating.cssr.CarrierSelectionRulesEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadRequest;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.openpojo.random.RandomFactory;
import com.openpojo.random.RandomGenerator;
import com.openpojo.random.generator.time.ZonedDateTimeRandomGenerator;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.EqualsAndHashCodeMatchRule;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.NoPublicFieldsExceptStaticFinalRule;
import com.openpojo.validation.rule.impl.NoStaticExceptFinalRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

import static com.openpojo.validation.affirm.Affirm.affirmTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class PojoTests {

    // Test specific pojo classes to avoid full classpath scan...
    private static final List<PojoClass> POJO_CLASSES = List.of(
            PojoClassFactory.getPojoClass(IngestionEntityMetadata.class),
            PojoClassFactory.getPojoClass(DataIngestionDetails.class),
            PojoClassFactory.getPojoClass(DataUploadResponse.class),
            PojoClassFactory.getPojoClass(FileUploadRequest.class),
            PojoClassFactory.getPojoClass(FileUploadResponse.class),
            PojoClassFactory.getPojoClass(CarrierServiceEntity.class),
            PojoClassFactory.getPojoClass(CarrierService.class),
            PojoClassFactory.getPojoClass(CarrierSelectionRulesEntity.class),
            PojoClassFactory.getPojoClass(ServiceDetail.class),
            PojoClassFactory.getPojoClass(ValidationEntity.class),
            PojoClassFactory.getPojoClass(CommodityEntity.class),
            PojoClassFactory.getPojoClass(ShipmentEntity.class),
            PojoClassFactory.getPojoClass(ShipmentLogisticUnit.class),
            PojoClassFactory.getPojoClass(CarrierEntity.class),
            PojoClassFactory.getPojoClass(CustomerEntity.class),
            PojoClassFactory.getPojoClass(LocationEntity.class),
            PojoClassFactory.getPojoClass(EquipmentRestrictionEntity.class),
            PojoClassFactory.getPojoClass(TransportEquipmentEntity.class),
            PojoClassFactory.getPojoClass(CommodityRestrictionEntity.class),
            PojoClassFactory.getPojoClass(CarrierDetailsCharacteristics.class)
    );

    @BeforeAll
    static void setup() {
        RandomFactory.addRandomGenerator(new DateTimeRandomGenerator());
    }

    private static String getClassFqsn(PojoClass pojoClass) {
        var name = pojoClass.getClazz().getSimpleName();
        if (pojoClass.isNestedClass()) {
            name = getClassFqsn(pojoClass.getEnclosingClass()) + '.' + name;
        }
        return name;
    }

    @Test
    void pojoClassesTest() {
        var validator = ValidatorBuilder.create()
                .with(new SetterMustExistRule(),
                        new GetterMustExistRule(),
                        new EqualsAndHashCodeMatchRule(),
                        new NoStaticExceptFinalRule(),
                        new NoPublicFieldsExceptStaticFinalRule())
                .with(new SetterTester(),
                        new GetterTester(),
                        // hashCode, equals & toString tester (PITest line coverage)
                        pojoClass -> {
                            Object o = RandomFactory.getRandomValue(pojoClass.getClazz());
                            affirmTrue("", o.hashCode() != 0 && !o.equals(""));
                            // Lombok toString value starts fully qualified simple name of the class, lets simply check for that...
                            var name = getClassFqsn(pojoClass);
                            affirmTrue("toString value doesn't start with class name ".concat(name), o.toString().startsWith(name));
                        })
                .build();
        assertNotNull(validator);

        validator.validate(POJO_CLASSES);
    }

    /**
     * Random generator for unavailable date-time classes in Openpojo library.
     *
     * @see ZonedDateTimeRandomGenerator
     */
    private static class DateTimeRandomGenerator implements RandomGenerator {

        public Collection<Class<?>> getTypes() {
            return List.of(OffsetDateTime.class, LocalDateTime.class, LocalTime.class);
        }

        public Object doGenerate(Class<?> type) {
            ZonedDateTime zdt = (ZonedDateTime) ZonedDateTimeRandomGenerator.getInstance().doGenerate(ZonedDateTime.class);
            if (OffsetDateTime.class == type) {
                return zdt.toOffsetDateTime();
            }
            else if (LocalDateTime.class == type) {
                return zdt.toLocalDateTime();
            }
            else if (LocalTime.class == type) {
                return zdt.toLocalTime();
            }
            return null;
        }
    }
}
