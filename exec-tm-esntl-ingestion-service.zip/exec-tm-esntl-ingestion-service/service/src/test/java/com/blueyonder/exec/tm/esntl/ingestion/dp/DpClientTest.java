/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.junit.jupiter.MockServerExtension;
import org.mockserver.model.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.ecom.boot.commons.web.error.ResponseErrorMarkerException;
import com.blueyonder.plat.dp.api.client.v1.CommonDpClient;
import com.blueyonder.plat.dp.api.client.v1.LocationDpClient;
import com.blueyonder.plat.dp.api.model.IngestionResponseModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;
import com.blueyonder.plat.dp.bydm.LocationType;
import com.fasterxml.jackson.databind.JsonNode;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@ExtendWith(MockServerExtension.class)
class DpClientTest {

    private final DpClient dpClient;

    private final CommonDpClient commonDpClient;

    private final ClientAndServer mockClientAndServer;

    private final LocationDpClient loactionDpClient;

    DpClientTest(ClientAndServer mockClientAndServer) {
        this.mockClientAndServer = mockClientAndServer;
        this.loactionDpClient = new LocationDpClient(WebClient.builder()
                .baseUrl("http://localhost:" + mockClientAndServer.getLocalPort())
                .build());
        this.commonDpClient = mock(CommonDpClient.class);
        this.dpClient = new DpClient(commonDpClient);
    }

    @Test
    void ingestToDpAsJsonNode200() {
        String entityId = UUID.randomUUID().toString();
        JsonNode locationNodes = getJsonNode(entityId);

        IngestionQueryResponseModel ingestionQueryResponseModel = mockPostDp200();

        assertDoesNotThrow(() -> StepVerifier.create(dpClient.ingest(loactionDpClient, locationNodes))
                .assertNext(e -> {
                    assertNotNull(e);
                    assertEquals(ingestionQueryResponseModel.getId(), e.getId());
                })
                .verifyComplete());
    }

    @Test
    void ingestToDpAsJsonNodeExceptionNoEvents() {
        String entityId = UUID.randomUUID().toString();
        JsonNode locationNodes = getJsonNode(entityId);

        mockDpPostNoEvents200();

        assertDoesNotThrow(() -> StepVerifier.create(dpClient.ingest(loactionDpClient, locationNodes))
                .expectError(ResponseErrorMarkerException.class)
                .verify());

    }

    @Test
    void ingestToDpAsNodeExceptionEventsNotCompleted() {
        String entityId = UUID.randomUUID().toString();
        JsonNode locationNodes = getJsonNode(entityId);

        mockPostDpNEventNotCompleted200();

        assertDoesNotThrow(() -> StepVerifier.create(dpClient.ingest(loactionDpClient, locationNodes))
                .expectError(ResponseErrorMarkerException.class)
                .verify());
    }

    @Test
    void ingestToDp200() {
        String entityId = UUID.randomUUID().toString();
        LocationType entity = buildLocationType(entityId);

        IngestionQueryResponseModel ingestionQueryResponseModel = mockPostDp200();

        assertDoesNotThrow(() -> StepVerifier.create(dpClient.ingest(loactionDpClient, List.of(entity)))
                .assertNext(e -> {
                    assertNotNull(e);
                    assertEquals(ingestionQueryResponseModel.getId(), e.getId());
                })
                .verifyComplete());

    }

    @Test
    void ingestToDpExceptionNoEvents() {
        String entityId = UUID.randomUUID().toString();
        LocationType entity = buildLocationType(entityId);

        mockDpPostNoEvents200();

        assertDoesNotThrow(() -> StepVerifier.create(dpClient.ingest(loactionDpClient, List.of(entity)))
                .expectError(ResponseErrorMarkerException.class)
                .verify());

    }

    @Test
    void ingestToDpExceptionEventsNotCompleted() {
        String entityId = UUID.randomUUID().toString();
        LocationType entity = buildLocationType(entityId);

        when(commonDpClient.getIngestionStatus(anyString())).thenReturn(Mono.just(buildIngestionQueryResponseModel()));

        IngestionResponseModel response = new IngestionResponseModel();
        response.setIngestionId("ingestion-0001");

        mockClientAndServer
                .when(request(loactionDpClient.getDpClient().getIngestionApiPath())
                        .withMethod("post"))
                .respond(response()
                        .withStatusCode(200)
                        .withBody(JsonUtils.toJson(response), MediaType.APPLICATION_JSON));

        assertDoesNotThrow(() -> StepVerifier.create(dpClient.ingest(loactionDpClient, List.of(entity)))
                .expectError(ResponseErrorMarkerException.class)
                .verify());

    }

    @AfterEach
    void reset() {
        mockClientAndServer.reset();
    }

    private void mockPostDpNEventNotCompleted200() {
        IngestionResponseModel response = new IngestionResponseModel();
        response.setIngestionId("ingestion-0001");
        when(commonDpClient.getIngestionStatus(anyString())).thenReturn(Mono.just(buildIngestionQueryResponseModel()));
        mockClientAndServer
                .when(request(loactionDpClient.getDpClient().getIngestionApiPath())
                        .withMethod("post"))
                .respond(response()
                        .withStatusCode(200)
                        .withBody(JsonUtils.toJson(response), MediaType.APPLICATION_JSON));
    }

    private LocationType buildLocationType(String entityId) {
        return new LocationType()
                .withSenderDocumentId("doc-" + entityId)
                .withLocationId("loc-" + entityId)
                .withCreationDateTime(OffsetDateTime.now());
    }

    private IngestionQueryResponseModel buildIngestionQueryResponseModel() {
        IngestionQueryResponseModel ingestionQueryResponseModel = new IngestionQueryResponseModel();
        ingestionQueryResponseModel.setId("testId");
        return ingestionQueryResponseModel;
    }

    private IngestionQueryResponseModel mockPostDp200() {
        IngestionQueryResponseModel ingestionQueryResponseModel = DpTestUtils.buildIngestionQueryResponseModel();
        when(commonDpClient.getIngestionStatus(anyString())).thenReturn(Mono.just(ingestionQueryResponseModel));

        IngestionResponseModel response = new IngestionResponseModel();
        response.setIngestionId("ingestion-0001");

        mockClientAndServer
                .when(request(loactionDpClient.getDpClient().getIngestionApiPath())
                        .withMethod("post"))
                .respond(response()
                        .withStatusCode(200)
                        .withBody(JsonUtils.toJson(response), MediaType.APPLICATION_JSON));
        return ingestionQueryResponseModel;
    }

    private JsonNode getJsonNode(String entityId) {
        LocationType entity = buildLocationType(entityId);
        return JsonUtils.objectMapper().convertValue(List.of(entity), JsonNode.class);
    }

    private void mockDpPostNoEvents200() {
        IngestionQueryResponseModel ingestionQueryResponseModel = buildIngestionQueryResponseModel();
        ingestionQueryResponseModel.setEvents(Collections.emptyList());
        when(commonDpClient.getIngestionStatus(anyString())).thenReturn(Mono.just(ingestionQueryResponseModel));
        IngestionResponseModel response = new IngestionResponseModel();
        response.setIngestionId("ingestion-0001");

        mockClientAndServer
                .when(request(loactionDpClient.getDpClient().getIngestionApiPath())
                        .withMethod("post"))
                .respond(response()
                        .withStatusCode(200)
                        .withBody(JsonUtils.toJson(response), MediaType.APPLICATION_JSON));
    }

}
