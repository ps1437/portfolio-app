package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.plat.dp.api.client.v1.LocationDpClient;
import com.blueyonder.plat.dp.api.model.query.Query;
import com.blueyonder.plat.dp.bydm.LocationType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ShipmentLocationDnfServiceTest {

    @InjectMocks
    private ShipmentLocationDnfService locationService;

    @Mock
    private LocationDpClient locationDpClient;

    @Test
    void queryShipmentLocationAsMap() {
        List<String> locationIds = List.of("loaction1", "location2");
        List<LocationType> locationTypes = List.of(DpTestUtils.buildLocationType("loaction1"), DpTestUtils.buildLocationType("location2"));
        when(locationDpClient.getByQuery(any(Query.class))).thenReturn(Mono.just(locationTypes));

        Map<String, LocationType> locationTypeMap = locationService.queryLocationAsMap(locationIds);

        assertNotNull(locationTypeMap);
        assertEquals(locationTypes.size(), locationTypeMap.size());
        assertEquals(locationTypes.get(0).getLocationId(), locationTypeMap.get("loaction1").getLocationId());
    }

    @Test
    void queryShipmentLocationAsMapEmpty() {
        when(locationDpClient.getByQuery(any(Query.class))).thenReturn(Mono.empty());

        Map<String, LocationType> locationTypeMap = locationService.queryLocationAsMap(List.of("loaction1", "location2"));

        assertNotNull(locationTypeMap);
        assertEquals(0, locationTypeMap.size());
    }

}
