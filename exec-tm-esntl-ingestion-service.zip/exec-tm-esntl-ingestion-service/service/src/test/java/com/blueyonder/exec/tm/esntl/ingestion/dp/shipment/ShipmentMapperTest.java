/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.plat.dp.bydm.CountMeasurementUnitCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class ShipmentMapperTest {

    private ShipmentMapper shipmentMapper;

    ShipmentMapperTest() {
        shipmentMapper = new ShipmentMapper(new ObjectMapper().registerModule(new JavaTimeModule()));
    }

    @Test
    void testShouldMapShipmentReqToShipment() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.setShipmentNumber("595954565");
        shipment.getMetadata().setReferenceId(shipment.getShipmentNumber());
        shipment.setReferenceNumber("1234");
        shipment.setReferenceNumberType("INTERNAL_ORDER");
        shipment.setShipmentType(ShipmentType.LOAD_BASED);

        List<ShipmentLogisticUnit> logisticUnits = new ArrayList<>();
        ShipmentLogisticUnit logisticUnit = new ShipmentLogisticUnit();
        logisticUnit.setLogisticUnitName("customer");
        logisticUnit.setHeight(1.00);
        logisticUnit.setCommodityId("commodityId");
        logisticUnit.setQuantity(2.0);
        logisticUnit.setQuantityUom(CountMeasurementUnitCode.BO);
        logisticUnit.setTotalGrossWeight(200.0);

        logisticUnits.add(logisticUnit);
        logisticUnits.add(logisticUnit);
        shipment.setLogisticUnits(logisticUnits);

        ObjectNode shipmentType = shipmentMapper.mapToShipmentForCreate(shipment);

        assertNotNull(shipmentType);
        assertEquals(13, shipmentType.get("shipmentId").textValue().length());
        assertEquals(2, shipmentType.get("plannedLogisticUnit").size());
        assertEquals(0, shipmentType.get("shipmentLine").size());
        assertEquals("customer", shipmentType.get("plannedLogisticUnit").get(0).get("logisticUnitName").textValue());
        assertEquals("commodityId", shipmentType.get("plannedLogisticUnit").get(0).get("commodityType").textValue());
        assertEquals(2.0, shipmentType.get("plannedLogisticUnit").get(0).get("quantity").asDouble());
        assertEquals(CountMeasurementUnitCode.BO.value(), shipmentType.get("plannedLogisticUnit").get(0).get("quantityUom").textValue());
        assertEquals(200.0, shipmentType.get("plannedLogisticUnit").get(0).get("totalGrossWeight").asDouble());
        assertNotNull(shipmentType.get("plannedLogisticUnit").get(0).get("logisticUnitId").textValue());
        assertEquals(400.0, shipmentType.get("freightTotal").get("totalGrossWeight").asDouble());
        assertEquals("MGM", shipmentType.get("freightTotal").get("weightUom").textValue());

        assertNotNull(shipmentType.get("shipmentId"));

        assertNotNull(shipmentType.get("stop"));
        assertEquals(2, shipmentType.get("stop").size());
        assertEquals("PICKUP", shipmentType.get("stop").get(0).get("stopOperationTypeCode").textValue());
        assertEquals("DROPOFF", shipmentType.get("stop").get(1).get("stopOperationTypeCode").textValue());

        assertNull(shipmentType.get("shipmentLeg"));

        int documentReferenceList = shipmentType.get("documentReference").size();
        assertEquals(1, documentReferenceList);
        assertEquals("1234", shipmentType.get("documentReference").get(0).get("referenceValue").textValue());
        assertEquals("INTERNAL_ORDER", shipmentType.get("documentReference").get(0).get("referenceName").textValue());
    }

    @Test
    void testShouldMapShipmentReqToShipmentIfDocumentReferenceNonNull() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.setShipmentNumber("595954565");
        shipment.setReferenceNumber("1234");
        shipment.setReferenceNumberType("INTERNAL_ORDER");
        shipment.setShipmentType(ShipmentType.DIRECT);
        List<ShipmentLogisticUnit> logisticUnits = new ArrayList<>();
        ShipmentLogisticUnit logisticUnit = new ShipmentLogisticUnit();
        logisticUnit.setLogisticUnitName("customer");
        logisticUnit.setHeight(1.00);
        logisticUnits.add(logisticUnit);
        logisticUnits.add(logisticUnit);
        shipment.setLogisticUnits(logisticUnits);

        ObjectNode shipmentType = shipmentMapper.mapToShipmentForCreate(shipment);

        assertEquals("1234", shipmentType.get("documentReference").get(0).get("referenceValue").textValue());
        assertEquals("INTERNAL_ORDER", shipmentType.get("documentReference").get(0).get("referenceName").textValue());
        assertNotNull(shipmentType.get("shipmentLeg"));
        assertEquals(1, shipmentType.get("shipmentLeg").size());

    }

    @Test
    void testMapShipmentReqToShipmentWithNullDocumentReference() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.setShipmentNumber("52388445");
        shipment.setReferenceNumber("123");
        shipment.setReferenceNumberType("data");
        List<ShipmentLogisticUnit> logisticUnits = new ArrayList<>();
        ShipmentLogisticUnit logisticUnit = new ShipmentLogisticUnit();
        logisticUnit.setLogisticUnitName("customer");
        logisticUnit.setHeight(1.00);
        logisticUnits.add(logisticUnit);
        shipment.setLogisticUnits(logisticUnits);

        ObjectNode shipmentType = shipmentMapper.mapToShipmentForCreate(shipment);

        assertNotNull(shipmentType);
        assertEquals(13, shipmentType.get("shipmentId").textValue().length());
    }

    @Test
    void testMapStop() {
        String shipment = """
                {"plannedLogisticUnit": [{"logisticUnitId": "logisticUnitId"}], "stop": [{"actionCode": "ADD"}, {"actionCode": "ADD"}]}
                """;
        ObjectNode jsonNodes = JsonUtils.fromJson(shipment, ObjectNode.class);
        String currentDateTime = OffsetDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        ObjectNode node = shipmentMapper.mapStop(jsonNodes, currentDateTime, "originLocationName", "destinationLocationName");
        assertNotNull(node);
        assertEquals(2, node.get("stop").size());
        assertEquals("logisticUnitId", node.get("stop").get(0).get("stopActivity").get(0).get("logisticUnitId").textValue());
    }
}
