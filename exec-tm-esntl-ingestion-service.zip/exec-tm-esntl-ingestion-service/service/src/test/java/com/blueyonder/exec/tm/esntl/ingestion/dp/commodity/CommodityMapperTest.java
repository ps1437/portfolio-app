/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.commodity;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;

import com.blueyonder.plat.dp.bydm.CommodityType;
import com.blueyonder.plat.dp.bydm.DescriptionType;
import com.blueyonder.plat.dp.bydm.LanguageCode;
import com.blueyonder.plat.dp.bydm.SegmentActionEnumerationType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class CommodityMapperTest {

    private static CommodityEntity commodity;

    private final CommodityMapper commodityMapper = Mappers.getMapper(CommodityMapper.class);

    @BeforeAll
    public static void buildCommodityEntity() {
        ((Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api")).setLevel(Level.OFF);
        PodamFactory factory = new PodamFactoryImpl();
        commodity = factory.manufacturePojo(CommodityEntity.class);
    }

    @Test
    void testMapToCommodityType() {
        CommodityType commodityType = commodityMapper.mapToCommodityType(commodity);
        assertNotNull(commodityType);
        assertEquals(commodity.getCommodityId(), commodityType.getCommodityId());
        assertEquals(1, commodityType.getDescription().size());
    }

    @Test
    void testMapToDescription() {
        List<DescriptionType> descriptionTypes = commodityMapper.mapToDescription(commodity);
        assertTrue(descriptionTypes.size() > 0);
        assertEquals(SegmentActionEnumerationType.ADD, descriptionTypes.get(0).getActionCode());
        assertEquals(LanguageCode.EN, descriptionTypes.get(0).getLanguageCode());
    }
}
