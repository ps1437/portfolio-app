/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

class LocationEntityMapperTests {

    //    @Test
    //    void testMapEntityForLocationWithCorrectFields() throws IOException {
    //        InputStream fileStream = new ClassPathResource("Location.xlsx").getInputStream();
    //
    //        Workbook workbook = WorkbookFactory.create(fileStream);
    //
    //        Sheet locationSheet = workbook.getSheet(DomainType.LOCATION.getName());
    //        DomainSchemaInfo domainSchemaInfo = ExcelDataReader.validateSchema(
    //                DomainType.LOCATION,
    //                locationSheet.getRow(0)
    //        );
    //        IngestionEntityColumnDef[] locationSheetEntityPropertiesInfoOrder = domainSchemaInfo.getIngestionEntityProperties();
    //
    //        LocationEntity locationEntity = IngestionEntityBuilder.buildEntity(locationSheet.getRow(1), locationSheetEntityPropertiesInfoOrder, LocationEntity.class, "LocationModel");
    //
    //        assertNotNull(locationEntity);
    //
    //        assertEquals(locationEntity.getLocationId(), locationSheet.getRow(1).getCell(0).getStringCellValue());
    //        assertEquals(DomainType.LOCATION, domainSchemaInfo.getDomainType());
    //        assertFalse(domainSchemaInfo.isSchemaError());
    //    }

    //    @Test
    //    void testMapEntityForCarrierServicesWithEmptyFields() throws IOException {
    //        InputStream fileStream = new ClassPathResource("Location_Empty.xlsx").getInputStream();
    //        Workbook workbook = WorkbookFactory.create(fileStream);
    //        Sheet locationSheet = workbook.getSheet(DomainType.LOCATION.getName());
    //        DomainSchemaInfo domainSchemaInfo = ExcelDataReader.validateSchema(
    //                DomainType.LOCATION,
    //                locationSheet.getRow(0)
    //        );
    //        IngestionEntityColumnDef[] locationEntityPropertiesInfoOrder = domainSchemaInfo.getIngestionEntityProperties();
    //
    //        LocationEntity locationModel =
    //                IngestionEntityBuilder.buildEntity(locationSheet.getRow(1), locationEntityPropertiesInfoOrder, LocationEntity.class, "LocationModel");
    //
    //        assertNull(locationModel);
    //    }

    //    @Test
    //    void testMapAndValidateEntityNullRow() {
    //
    //        assertNull(IngestionEntityBuilder.buildEntity(null, null, LocationEntity.class, "LocationModel"));
    //    }
}
