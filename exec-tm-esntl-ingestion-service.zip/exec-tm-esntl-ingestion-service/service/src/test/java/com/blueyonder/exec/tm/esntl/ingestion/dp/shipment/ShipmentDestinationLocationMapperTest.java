package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.LocationAddressType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.LocationType;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ShipmentDestinationLocationMapperTest {

    private final ShipmentDestinationLocationMapper shipmentDestinationLocationMapper = Mappers.getMapper(ShipmentDestinationLocationMapper.class);

    @Test
    void mapToDestinationLocation() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.getMetadata().setRowNumber(1);
        shipment.setShipmentNumber("1");
        LocationType locationType = DpTestUtils.buildLocationType("location1");

        shipmentDestinationLocationMapper.mapToDestinationLocation(locationType, shipment);

        assertEquals(1, shipment.getMetadata().getRowNumber());
        assertEquals(locationType.getBasicLocation().getLocationName(), shipment.getDestinationLocationName());
        LocationAddressType addressType = locationType.getBasicLocation().getAddress();
        assertEquals(addressType.getState(), shipment.getDestinationState());
        assertEquals(addressType.getCity(), shipment.getDestinationCity());
        assertEquals(addressType.getCountryCode(), shipment.getDestinationCountryCode());
        assertEquals(addressType.getPostalCode(), shipment.getDestinationPostalCode());
        assertEquals(addressType.getStreetAddressOne(), shipment.getDestinationStreetAddressOne());
        assertEquals(addressType.getStreetAddressTwo(), shipment.getDestinationStreetAddressTwo());
        assertEquals(addressType.getStreetAddressThree(), shipment.getDestinationStreetAddressThree());
        assertEquals(addressType.getGeographicalCoordinates().getLatitude(), shipment.getDestinationLatitude());
        assertEquals(addressType.getGeographicalCoordinates().getLongitude(), shipment.getDestinationLongitude());
        LocationContactType contactType = locationType.getBasicLocation().getContact().get(0);
        assertEquals(contactType.getCompanyName(), shipment.getDestinationCompanyName());
        assertEquals(contactType.getPersonName(), shipment.getDestinationContactName());
        List<CommunicationChannelType> communicationChannels = contactType.getCommunicationChannel();
        for (CommunicationChannelType channelType : communicationChannels) {
            if (channelType.getCommunicationChannelCode().value().equals("EMAIL")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getDestinationEmail());
            }
            else if (channelType.getCommunicationChannelCode().value().equals("TELEPHONE")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getDestinationTelephone());
            }
            else if (channelType.getCommunicationChannelCode().value().equals("TELEFAX")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getDestinationTelefax());
            }
            else if (channelType.getCommunicationChannelCode().value().equals("WEBSITE")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getDestinationWebsite());
            }
        }
    }
}
