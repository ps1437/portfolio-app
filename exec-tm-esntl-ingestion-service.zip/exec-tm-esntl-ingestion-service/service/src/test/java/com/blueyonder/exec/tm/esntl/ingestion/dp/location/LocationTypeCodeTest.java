/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class LocationTypeCodeTest {

    @Test
    void checkAllValues() {
        assertEquals("CROSS_DOCK", LocationTypeCode.CROSS_DOCK.value());
        assertEquals("DISTRIBUTION_CENTER", LocationTypeCode.DISTRIBUTION_CENTER.value());
        assertEquals("CONSIGNEE", LocationTypeCode.CONSIGNEE.value());
        assertEquals("SHIP_FROM", LocationTypeCode.SHIP_FROM.value());
    }

    @Test
    void testFromValue() {
        assertEquals("DISTRIBUTION_CENTER", LocationTypeCode.fromValue("DISTRIBUTION_CENTER").name());
    }

    @Test
    void testFromValueException() {
        assertThrows(IllegalArgumentException.class, () -> LocationTypeCode.fromValue("test"));
    }
}
