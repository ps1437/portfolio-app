/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequestPage;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DpIngestionServiceImplTest {

    private DpClient dpClient = mock(DpClient.class);

    private PartyDpClient partyDpClient = mock(PartyDpClient.class);

    private DataStorageService dataStorageService = mock(DataStorageService.class);

    private PostIngestionService postIngestionService = mock(PostIngestionService.class);

    private IngestionConfigProperties ingestionConfigProperties = mock(IngestionConfigProperties.class);

    private DpIngestionServiceImpl dpIngestionService = new DpIngestionServiceImpl(
            dpClient,
            partyDpClient,
            dataStorageService,
            postIngestionService,
            ingestionConfigProperties
    ) {

        @Override
        public IngestionType getType() {
            return IngestionType.CARRIER;
        }

        @Override
        public IngestionEntitySchema getEntitySchema() {
            return null;
        }

        @Override
        protected List<?> prepareEntitiesToIngest(IngestionRequest ingestionRequest, IngestionRequestPage rootEntityPage) {
            return Collections.emptyList();
        }
    };

    @Test
    void testEmptyEntitiesList() {
        var ingestionRequest = mock(IngestionRequest.class);
        var ingestionRequestPage = mock(IngestionRequestPage.class);
        var ingestionRequestEntityDef = mock(IngestionRequestEntityDef.class);
        var ingestionEntityDef = mock(IngestionEntityDef.class);

        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();

        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
        when(ingestionRequestPage.getRequestEntityDef()).thenReturn(ingestionRequestEntityDef);
        when(ingestionRequestEntityDef.getEntityDef()).thenReturn(ingestionEntityDef);

        dpIngestionService.ingest(ingestionRequest, ingestionRequestPage);

        verify(postIngestionService, times(1)).processIngestion(any());
    }

}
