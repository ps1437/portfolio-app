/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion;

import reactor.core.publisher.Mono;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.WebMvcConfigurerImpl;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.LuiConfig;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpConfig;
import com.blueyonder.exec.tm.esntl.ingestion.rating.RatingClient;
import com.blueyonder.exec.tm.esntl.ingestion.rating.RatingConfig;
import com.blueyonder.plat.dp.api.client.v1.CommodityDpClient;
import com.blueyonder.plat.dp.api.client.v1.CommonDpClient;
import com.blueyonder.plat.dp.api.client.v1.LocationDpClient;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;
import com.blueyonder.plat.dp.api.client.v1.ShipmentDpClient;
import com.blueyonder.plat.dp.api.client.v1.TransportEquipmentDpClient;
import com.blueyonder.plat.dp.api.client.v1.ZoneDpClient;
import com.blueyonder.plat.lui.api.client.v1.FileStorageClient;
import com.blueyonder.plat.lui.api.client.v1.UIConfigurationClient;
import com.jda.security.tenancy.TenancyContext;
import com.jda.security.tenancy.TenancyContextHolder;
import com.jda.security.tenancy.Tenant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ConfigTest {

    @Test
    void configTest() {
        TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("test", null, true)));
        ApplicationContextRunner contextRunner = new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(
                        DpConfig.class,
                        LuiConfig.class,
                        RatingConfig.class,
                        WebMvcConfigurerImpl.class));
        assertDoesNotThrow(() -> {
            contextRunner.withUserConfiguration(WebClientConfig.class).run((context) -> {
                assertThat(context).hasSingleBean(LocationDpClient.class);
                assertThat(context).hasSingleBean(CommonDpClient.class);
                assertNotNull(context.getBean(CommonDpClient.class).getIngestionStatus("test"));
                assertNotNull(context.getBean(LocationDpClient.class).getDpClient());
                assertThat(context).hasSingleBean(PartyDpClient.class);
                assertNotNull(context.getBean(PartyDpClient.class).getDpClient());
                assertThat(context).hasSingleBean(ShipmentDpClient.class);
                assertNotNull(context.getBean(ShipmentDpClient.class).getDpClient());
                assertThat(context).hasSingleBean(CommodityDpClient.class);
                assertNotNull(context.getBean(CommodityDpClient.class).getDpClient());
                assertThat(context).hasSingleBean(TransportEquipmentDpClient.class);
                assertNotNull(context.getBean(TransportEquipmentDpClient.class).getDpClient());
                assertThat(context).hasSingleBean(ZoneDpClient.class);
                assertNotNull(context.getBean(ZoneDpClient.class).getDpClient());

                assertThat(context).hasSingleBean(FileStorageClient.class);
                assertNotNull(context.getBean(FileStorageClient.class).getConfigurations("source", List.of("k1")));
                assertThat(context).hasSingleBean(UIConfigurationClient.class);
                assertNotNull(context.getBean(UIConfigurationClient.class).getTenantPreferences());

                assertThat(context).hasSingleBean(RatingClient.class);
                assertNotNull(context.getBean(RatingClient.class).createCarrierServicesSelectionRules(Mono.empty()));

                assertThat(context).hasSingleBean(WebMvcConfigurerImpl.class);
            });
        });
    }

    @Configuration
    static class WebClientConfig {

        @Bean
        WebClient.Builder webClientBuilder() {
            return WebClient.builder();
        }
    }
}
