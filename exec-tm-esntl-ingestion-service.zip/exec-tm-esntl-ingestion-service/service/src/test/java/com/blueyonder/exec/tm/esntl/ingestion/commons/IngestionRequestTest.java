/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

class IngestionRequestTest {

    private static final IngestionEntityDef DEFAULT_ENTITY_DEF = new IngestionEntityDef(ParentEntity.class);

    @Test
    void testSimpleIngestionRequest() {
        var request = new IngestionRequest("src", List.of());
        assertEquals("src", request.getSourceName());
        assertEquals(0, request.getRequestPages().size());
        assertTrue(request.isEmpty());
    }

    private IngestionRequest buildIngestionRequest() {
        Iterator<IngestionEntityDef> itr = IngestionEntitySchema.of(DEFAULT_ENTITY_DEF).getEntityDefs().values().iterator();
        IngestionEntityDef entityDef1 = itr.next();
        IngestionEntityDef entityDef2 = itr.next();
        var requestEntityDef1 = new IngestionRequestEntityDef(entityDef1, true);
        var requestEntityDef2 = new IngestionRequestEntityDef(entityDef2, true);
        return new IngestionRequest("src", List.of(requestEntityDef1, requestEntityDef2));
    }

    @Test
    void testIngestionRequestInit() {
        var request = buildIngestionRequest();
        assertEquals(2, request.getRequestSchema().size());
        assertEquals(2, request.getRequestPages().size());
        assertTrue(request.toString().startsWith("IngestionRequest"));

        IngestionRequestPage requestPage = request.getFirstRequestPage();
        assertSame(requestPage, request.getRequestPages().get(DEFAULT_ENTITY_DEF.getName()));
        assertTrue(request.isEmpty());

        assertTrue(request.getEntities(DEFAULT_ENTITY_DEF.getName()).isEmpty());
        assertTrue(request.getValidEntities(DEFAULT_ENTITY_DEF.getName()).isEmpty());
        assertTrue(request.getInvalidEntities(DEFAULT_ENTITY_DEF.getName()).isEmpty());

        requestPage.addEntity(1, List.of("id-1", "entity"));

        ParentEntity entity = new ParentEntity("id-2", "entity-with-error");
        entity.getMetadata().addErrorMessage("some error");
        requestPage.addEntity(entity);

        assertFalse(request.isEmpty());

        List<ParentEntity> list = request.getEntities(DEFAULT_ENTITY_DEF.getName());
        assertEquals("entity", list.get(0).getName());

        list = request.getValidEntities(DEFAULT_ENTITY_DEF.getName());
        assertEquals("entity", list.get(0).getName());

        list = request.getInvalidEntities(DEFAULT_ENTITY_DEF.getName());
        assertEquals("entity-with-error", list.get(0).getName());
    }

    @Test
    void testIngestionRequestPage() {
        IngestionRequest request = buildIngestionRequest();

        IngestionRequestPage parentEntityPage = request.getFirstRequestPage();
        assertEquals(DEFAULT_ENTITY_DEF.getName(), parentEntityPage.getName());
        assertEquals(DEFAULT_ENTITY_DEF.getColumnDefs().size(), parentEntityPage.getColumnNames().size());
        assertTrue(parentEntityPage.toString().startsWith("IngestionRequestPage"));
        testParentEntityPage(parentEntityPage);

        IngestionRequestPage childEntityPage = request.getRequestPages().get(ChildEntity.class.getSimpleName());
        testChildEntityPage(childEntityPage, parentEntityPage);

        parentEntityPage.postConstruct();
        ParentEntity parentEntity = (ParentEntity) parentEntityPage.getIndexedEntities().get("id-1");
        assertNotNull(parentEntity.getPostGraphConstructResult());
    }

    private void testParentEntityPage(IngestionRequestPage requestPage) {
        // Add entity and metadata update test
        requestPage.addEntity(1, List.of("id-1", "entity"));
        ParentEntity first = (ParentEntity) requestPage.getEntities().get(0);
        assertEquals("id-1", first.getMetadata().getReferenceId());
        assertEquals(1, first.getMetadata().getRowNumber());
        assertEquals(List.of("id-1", "entity"), first.getMetadata().getRow());
        assertNotNull(first.getPostConstructResult());

        // Index and error entity
        ParentEntity entity = new ParentEntity("id-2", "entity-with-error");
        entity.getMetadata().addErrorMessage("some error");
        requestPage.addEntity(entity);
        assertSame(entity, requestPage.getIndexedEntities().get("id-2"));

        // Index and Invalid ID
        entity = new ParentEntity(null, "entity");
        entity.getMetadata().addErrorMessage("Id is mandatory field.");
        requestPage.addEntity(entity);
        assertTrue(entity.getMetadata().hasError());

        // Index and duplicate ID
        entity = new ParentEntity("id-1", "entity");
        requestPage.addEntity(entity);
        assertTrue(entity.getMetadata().hasError());
        assertSame(first, requestPage.getIndexedEntities().get("id-1"));
    }

    private void testChildEntityPage(IngestionRequestPage childEntityRequestPage, IngestionRequestPage parentEntityPage) {
        // Add entity and metadata update test
        childEntityRequestPage.addEntity(1, List.of("id-1", "entity"));
        ChildEntity first = (ChildEntity) childEntityRequestPage.getValidEntities().get(0);
        assertEquals("id-1", first.getMetadata().getReferenceId());

        // Check the object graph...
        ParentEntity parentEntity = (ParentEntity) parentEntityPage.getIndexedEntities().get("id-1");
        assertTrue(parentEntity.getChildEntities().contains(first));
    }
}
