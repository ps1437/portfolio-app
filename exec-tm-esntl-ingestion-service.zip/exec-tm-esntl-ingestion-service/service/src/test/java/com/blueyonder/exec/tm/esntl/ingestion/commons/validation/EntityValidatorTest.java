package com.blueyonder.exec.tm.esntl.ingestion.commons.validation;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class EntityValidatorTest {

    @Test
    void testValidate() {
        List<String> errors = EntityValidator.validate("Shipment", "shipmentSeqNbr", "");
        assertEquals(1, errors.size());
        assertTrue(errors.get(0).contains("shipmentSeqNbr"));

        errors = EntityValidator.validate("Shipment Logistic Units", "length", "abcd");
        assertEquals(1, errors.size());
        assertTrue(errors.get(0).contains("length"));
    }

    @ParameterizedTest
    @ValueSource(strings = { "[A-Z]+", "" })
    void validateRegex(String value) {
        boolean validRegex = ReflectionTestUtils.invokeMethod(EntityValidator.class, "validateRegex", value, "REFERENCE");
        assertTrue(validRegex);
    }

    @Test
    void validateInvalidRegex() {
        boolean validRegex3 = ReflectionTestUtils.invokeMethod(EntityValidator.class, "validateRegex", "[A-Z]", "REFERENCE");
        assertFalse(validRegex3);
    }
}
