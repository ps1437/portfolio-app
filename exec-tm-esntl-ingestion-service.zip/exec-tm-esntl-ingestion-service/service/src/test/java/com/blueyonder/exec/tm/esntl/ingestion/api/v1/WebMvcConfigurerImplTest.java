package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.format.FormatterRegistry;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith({ MockitoExtension.class })
class WebMvcConfigurerImplTest {

    @InjectMocks
    private WebMvcConfigurerImpl webMvcConfigurer;

    @Test
    void testAddFormatters() {
        FormatterRegistry formatterRegistry = Mockito.mock(FormatterRegistry.class);
        webMvcConfigurer.addFormatters(formatterRegistry);
        verify(formatterRegistry, times(1)).addConverter(any(WebMvcConfigurerImpl.StringToEntityTypeModelConverter.class));
    }

    @Test
    void testIngestionEntityTypeModelConverter() {
        var converter = new WebMvcConfigurerImpl.StringToEntityTypeModelConverter();
        assertEquals(EntityTypeModel.CARRIER, converter.convert("Carrier"));
    }

    @Test
    void testStringToTemplateTypeModelConverter() {
        var converter = new WebMvcConfigurerImpl.StringToTemplateTypeModelConverter();
        assertEquals(TemplateTypeModel.CARRIER, converter.convert("Carrier"));
    }
}
