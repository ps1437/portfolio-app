package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.slf4j.LoggerFactory;

import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.LocationAddressType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.LocationType;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ShipmentOriginLocationMapperTest {

    private final ShipmentOriginLocationMapper shipmentOriginLocationMapper = Mappers.getMapper(ShipmentOriginLocationMapper.class);

    @BeforeAll
    static void setup() {
        Logger root = (Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api");
        root.setLevel(Level.OFF);
    }

    @Test
    void mapToOriginLocation() {
        ShipmentEntity shipment = new ShipmentEntity();
        shipment.getMetadata().setRowNumber(1);
        shipment.setShipmentNumber("1");
        LocationType locationType = DpTestUtils.buildLocationType("location1");

        shipmentOriginLocationMapper.mapToOriginLocation(locationType, shipment);

        assertEquals(1, shipment.getMetadata().getRowNumber());
        assertEquals(locationType.getBasicLocation().getLocationName(), shipment.getOriginLocationName());
        LocationAddressType addressType = locationType.getBasicLocation().getAddress();
        assertEquals(addressType.getState(), shipment.getOriginState());
        assertEquals(addressType.getCity(), shipment.getOriginCity());
        assertEquals(addressType.getCountryCode(), shipment.getOriginCountryCode());
        assertEquals(addressType.getPostalCode(), shipment.getOriginPostalCode());
        assertEquals(addressType.getStreetAddressOne(), shipment.getOriginStreetAddressOne());
        assertEquals(addressType.getStreetAddressTwo(), shipment.getOriginStreetAddressTwo());
        assertEquals(addressType.getStreetAddressThree(), shipment.getOriginStreetAddressThree());
        assertEquals(addressType.getGeographicalCoordinates().getLatitude(), shipment.getOriginLatitude());
        assertEquals(addressType.getGeographicalCoordinates().getLongitude(), shipment.getOriginLongitude());
        LocationContactType contactType = locationType.getBasicLocation().getContact().get(0);
        assertEquals(contactType.getCompanyName(), shipment.getOriginCompanyName());
        assertEquals(contactType.getPersonName(), shipment.getOriginContactName());
        List<CommunicationChannelType> communicationChannels = contactType.getCommunicationChannel();
        for (CommunicationChannelType channelType : communicationChannels) {
            if (channelType.getCommunicationChannelCode().value().equals("EMAIL")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getOriginEmail());
            }
            else if (channelType.getCommunicationChannelCode().value().equals("TELEPHONE")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getOriginTelephone());
            }
            else if (channelType.getCommunicationChannelCode().value().equals("TELEFAX")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getOriginTelefax());
            }
            else if (channelType.getCommunicationChannelCode().value().equals("WEBSITE")) {
                assertEquals(channelType.getCommunicationValue(), shipment.getOriginWebsite());
            }
        }
    }
}
