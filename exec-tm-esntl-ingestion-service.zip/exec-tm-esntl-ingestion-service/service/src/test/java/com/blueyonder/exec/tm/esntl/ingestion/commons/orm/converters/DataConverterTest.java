/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons.orm.converters;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.ReflectionUtils;

import com.blueyonder.plat.dp.bydm.CountryCode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DataConverterTest {

    @Test
    void testConverterByType() throws Exception {
        Map<?, ?> converters = (Map<?, ?>) ReflectionUtils.tryToReadFieldValue(DataConverterUtils.class, "CONVERTERS_CACHE", null).get();
        converters.clear();

        assertNull(DataConverterUtils.getDataConverter(Map.class, null));
        assertInstanceOf(NoOpConverter.class, DataConverterUtils.getDataConverter(Map.class));

        assertNull(converters.get(String.class));
        assertInstanceOf(NoOpConverter.class, DataConverterUtils.getDataConverter(String.class));
        assertNotNull(converters.get(String.class));

        assertNull(converters.get(Integer.class));
        assertInstanceOf(StringToNumberConverter.class, DataConverterUtils.getDataConverter(Integer.class));
        assertNotNull(converters.get(Integer.class));

        assertNull(converters.get(Boolean.class));
        assertInstanceOf(StringToBooleanConverter.class, DataConverterUtils.getDataConverter(Boolean.class));
        assertNotNull(converters.get(Boolean.class));

        assertNull(converters.get(OffsetDateTime.class));
        assertInstanceOf(StringToOffsetDateTimeConverter.class, DataConverterUtils.getDataConverter(OffsetDateTime.class));
        assertNotNull(converters.get(OffsetDateTime.class));

        assertNull(converters.get(TimeUnit.class));
        assertInstanceOf(StringToEnumConverter.class, DataConverterUtils.getDataConverter(TimeUnit.class));
        assertNotNull(converters.get(TimeUnit.class));

        assertNull(converters.get(CountryCode.class));
        assertInstanceOf(StringToEnumFromValueConverter.class, DataConverterUtils.getDataConverter(CountryCode.class));
        assertNotNull(converters.get(CountryCode.class));
    }

    @Test
    void testNoOpConverter() {
        var converter = DataConverterUtils.getDataConverter(String.class);
        assertNull(converter.convert(null));
        assertEquals("", converter.convert(""));
        assertEquals(" ", converter.convert(" "));
        assertEquals("abcd", converter.convert("abcd"));
    }

    @Test
    void testStringToEnumFromValueConverter() {
        var converter = DataConverterUtils.getDataConverter(CountryCode.class);
        assertThrows(Exception.class, () -> converter.convert(null));
        assertThrows(Exception.class, () -> converter.convert(""));
        assertEquals(CountryCode.IN, converter.convert("IN"));
        assertEquals(CountryCode.IN, converter.convert("in"));
        assertThrows(Exception.class, () -> converter.convert("IN-X"));
        assertThrows(Exception.class, () -> converter.convert("in-x"));
        assertSame(converter, DataConverterUtils.getDataConverter(CountryCode.class));
    }

    @Test
    void testStringToEnum() {
        var converter = DataConverterUtils.getDataConverter(TimeUnit.class);
        assertThrows(Exception.class, () -> converter.convert(null));
        assertThrows(Exception.class, () -> converter.convert(""));
        assertEquals(TimeUnit.SECONDS, converter.convert("SECONDS"));
        assertEquals(TimeUnit.SECONDS, converter.convert("seconds"));
        assertThrows(Exception.class, () -> converter.convert("SECONDS-X"));
        assertThrows(Exception.class, () -> converter.convert("seconds-x"));
        assertSame(converter, DataConverterUtils.getDataConverter(TimeUnit.class));
    }

    @Test
    void testStringToInteger() {
        var converter = DataConverterUtils.getDataConverter(Integer.class);
        assertThrows(Exception.class, () -> converter.convert(null));
        assertThrows(Exception.class, () -> converter.convert(""));
        assertEquals(99, converter.convert("99"));
        assertThrows(Exception.class, () -> converter.convert("99x"));
        assertSame(converter, DataConverterUtils.getDataConverter(Integer.class));
    }

    @Test
    void testStringToDouble() {
        var converter = DataConverterUtils.getDataConverter(Double.class);
        assertThrows(Exception.class, () -> converter.convert(null));
        assertThrows(Exception.class, () -> converter.convert(""));
        assertEquals(99.99, converter.convert("99.99"));
        assertThrows(Exception.class, () -> converter.convert("99x"));
        assertSame(converter, DataConverterUtils.getDataConverter(Double.class));
    }

    @Test
    void testStringToBoolean() {
        var converter = DataConverterUtils.getDataConverter(Boolean.class);
        assertNull(converter.convert(null));
        assertNull(converter.convert(""));
        assertNull(converter.convert("xyz"));
        assertEquals(true, converter.convert("true"));
        assertSame(converter, DataConverterUtils.getDataConverter(Boolean.class));
    }

    @Test
    void testStringToOffsetDateTime() {
        var converter = DataConverterUtils.getDataConverter(OffsetDateTime.class);
        assertThrows(Exception.class, () -> converter.convert(null));
        assertThrows(Exception.class, () -> converter.convert(""));
        String s = "2022-03-14T19:48:43";
        assertEquals(s.concat("Z"), converter.convert(s).toString());
        s = "2022-03-14T19:48:43Z";
        assertEquals(s, converter.convert(s).toString());
        s = "2022-03-14T19:48:43+05:30";
        assertEquals(s, converter.convert(s).toString());
        assertSame(converter, DataConverterUtils.getDataConverter(OffsetDateTime.class));
    }
}
