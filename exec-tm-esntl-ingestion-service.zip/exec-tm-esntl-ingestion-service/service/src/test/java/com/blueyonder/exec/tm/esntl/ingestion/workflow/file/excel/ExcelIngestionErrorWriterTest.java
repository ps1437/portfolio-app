/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.ParentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ExcelIngestionErrorWriterTest {

    private static final IngestionEntityDef DEFAULT_ENTITY_DEF = new IngestionEntityDef(ParentEntity.class);

    private static IngestionRequest buildIngestionRequest() {
        Iterator<IngestionEntityDef> itr = IngestionEntitySchema.of(DEFAULT_ENTITY_DEF).getEntityDefs().values().iterator();
        IngestionEntityDef entityDef1 = itr.next();
        IngestionEntityDef entityDef2 = itr.next();
        var requestEntityDef1 = new IngestionRequestEntityDef(entityDef1, true);
        var requestEntityDef2 = new IngestionRequestEntityDef(entityDef2, true);
        return new IngestionRequest("test_source.xlsx", List.of(requestEntityDef1, requestEntityDef2));
    }

    private static IngestionRequest buildSampleIngestionRequest() {
        var request = buildIngestionRequest();
        var page = request.getFirstRequestPage();
        int errorCounter = 1;
        for (int i = 1; i < 20; ++i) {
            var entity = page.addEntity(i, List.of("id-" + i, "name-" + i));
            if (0 == i % 3) {
                // With each 3rd entity increase error count...
                for (int j = 0; j < errorCounter; ++j) {
                    entity.getMetadata().addErrorMessage("Random error " + i + " " + j);
                }
                ++errorCounter;
            }
        }
        return request;
    }

    @Test
    void testBuildErrorWorkbookEmpty() {
        byte[] bytes = new ExcelIngestionErrorWriter(buildIngestionRequest()).writeBytes();
        assertNotNull(bytes);
        assertTrue(bytes.length > 2000);
    }

    @Test
    void testBuildErrorWorkbookWithSampleData() throws IOException {
        var request = buildSampleIngestionRequest();
        var workbook = WorkbookFactory.create(new ExcelIngestionErrorWriter(request).writeInputStream());

        assertEquals(2, workbook.getNumberOfSheets());
        var sheet = workbook.getSheet(DEFAULT_ENTITY_DEF.getName());
        assertNotNull(sheet);

        var row0 = sheet.getRow(0);
        assertEquals(3, row0.getPhysicalNumberOfCells());
        assertEquals("id", row0.getCell(0).toString());
        assertEquals("name", row0.getCell(1).toString());
        assertEquals("ERROR_MESSAGE", row0.getCell(2).toString());

        // 2nd error record with 2 error messages...
        var row1 = sheet.getRow(2);
        assertEquals(4, row1.getPhysicalNumberOfCells());
        assertEquals("id-6", row1.getCell(0).toString());
        assertEquals("name-6", row1.getCell(1).toString());
        assertTrue(row1.getCell(2).toString().contains("error 6"));
        assertTrue(row1.getCell(3).toString().contains("error 6"));
    }
}
