/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import java.io.IOException;
import java.util.UUID;

import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel.ExcelIngestionRequestReader;

public class TestUtils {

    public static final PodamFactory PODAM_FACTORY = new PodamFactoryImpl();

    static {
        ((Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api")).setLevel(Level.OFF);
    }

    public static DataIngestionDetails buildDataIngestionDetails() {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setStatus("PROCESSING");
        dataIngestionDetails.setId(UUID.randomUUID());
        return dataIngestionDetails;
    }

    public static IngestionRequest buildIngestionRequest(IngestionService ingestionService, String filename) {
        try {
            return new ExcelIngestionRequestReader(filename, ingestionService.getEntitySchema())
                    .read(new ClassPathResource(filename).getInputStream());
        }
        catch (IOException e) {
            throw new IllegalArgumentException(e);
        }
    }
}
