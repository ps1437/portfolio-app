/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionRequestModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionEntityManager;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionRequestService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestStatusEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DisplayName("Ingestion Request Controller Tests")
@ExtendWith(MockitoExtension.class)
class IngestionRequestControllerTest {

    @Mock
    private IngestionRequestService ingestionRequestService;

    @Mock
    private IngestionEntityManager ingestionEntityManager;

    @Mock
    private IngestionRequestMapper ingestionRequestMapper;

    @Mock
    private IngestionRequestStatusMapper ingestionRequestStatusMapper;

    @InjectMocks
    private IngestionRequestController ingestionRequestController;

    private static final String CARRIER_FILE_ID = "63cec1337b2d4bdd168c408c";

    private static final String CARRIER_FILE_NAME = "Carrier.xlsx";

    @DisplayName("create ingestion request")
    @Test
    void testCreateIngestionRequest() {
        IngestionRequestDetailsModel ingestionRequestDetailsModel = new IngestionRequestDetailsModel();
        ingestionRequestDetailsModel.setEntityType(EntityTypeModel.CARRIER);
        ingestionRequestDetailsModel.setFileId(CARRIER_FILE_ID);

        IngestionRequestModel ingestionModel = new IngestionRequestModel();
        ingestionModel.setEntityType(EntityTypeModel.CARRIER);
        ingestionModel.setFileId(CARRIER_FILE_ID);
        ingestionModel.setFileName(CARRIER_FILE_NAME);

        when(ingestionRequestService.createIngestion(any(), any())).thenReturn(mock(IngestionRequestEntity.class));
        when(ingestionRequestMapper.toIngestionRequestModel(any())).thenReturn(ingestionModel);

        var responseEntity = ingestionRequestController.createIngestionRequest(ingestionRequestDetailsModel);
        var actualIngestionModel = responseEntity.getBody();

        assertEquals(ingestionModel.getFileId(), actualIngestionModel.getFileId());
        assertEquals(ingestionModel.getFileName(), actualIngestionModel.getFileName());
    }

    @DisplayName("get ingestion request page")
    @Test
    @SuppressWarnings("unchecked")
    void testGetIngestionRequestPage() {
        when(ingestionEntityManager.getIngestionRequests(any())).thenReturn(mock(Page.class));

        var pageResponseEntity = ingestionRequestController.getIngestionRequestPage(0, 0, "asc", Pageable.ofSize(1));

        verify(ingestionEntityManager, times(1)).getIngestionRequests(any());

        assertNotNull(pageResponseEntity);
    }

    @DisplayName("get ingestion request status")
    @Test
    void testGetIngestionRequestStatus() {
        when(ingestionEntityManager.getIngestionRequestStatusById(any())).thenReturn(mock(IngestionRequestStatusEntity.class));

        var responseEntity = ingestionRequestController.getIngestionRequestStatus(UUID.randomUUID());

        verify(ingestionRequestStatusMapper, times(1)).toIngestionRequestStatusModel(any());

        assertNotNull(responseEntity);
    }

    @DisplayName("get ingestion request statuses page")
    @Test
    @SuppressWarnings("unchecked")
    void testGetIngestionRequestStatusPage() {
        when(ingestionEntityManager.getIngestionRequestStatuses(any())).thenReturn(mock(Page.class));

        var pageResponseEntity = ingestionRequestController.getIngestionRequestStatusPage(0, 0, "asc", Pageable.ofSize(1));

        verify(ingestionEntityManager, times(1)).getIngestionRequestStatuses(any());

        assertNotNull(pageResponseEntity);
    }

}
