/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryEntryModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

import static com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.DataIngestSpecification.YYYY_MM_DD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class DataIngestSpecificationTest {

    @InjectMocks
    private DataIngestSpecification specifications;

    @SuppressWarnings("unchecked")
    @Test
    void testToPredicate() {
        Root<DataIngestionDetails> root = (Root<DataIngestionDetails>) mock(Root.class);
        CriteriaQuery<?> cq = mock(CriteriaQuery.class);
        CriteriaBuilder cb = mock(CriteriaBuilder.class);
        QueryEntryModel startDateQuery = new QueryEntryModel();
        startDateQuery.setOperation("gte");
        startDateQuery.setKey("startDateTime");
        startDateQuery.setValue("2022-01-10");
        QueryEntryModel endDateQuery = new QueryEntryModel();
        endDateQuery.setOperation("lte");
        endDateQuery.setKey("endDateTime");
        endDateQuery.setValue("2022-03-10");
        QueryEntryModel query = new QueryEntryModel();
        query.setOperation("eq");
        query.setKey("status");
        query.setValue("COMPLETED_WITH_ERROR");
        specifications.add(startDateQuery);
        specifications.add(endDateQuery);
        specifications.add(query);

        assertNull(specifications.toPredicate(root, cq, cb));

        verify(cb, times(1)).greaterThanOrEqualTo(null, formatToOffsetTime(startDateQuery.getValue()));
        verify(cb, times(1)).lessThanOrEqualTo(null, formatToOffsetTime(endDateQuery.getValue()));
        verify(cb, times(1)).equal(null, query.getValue());
    }

    @SuppressWarnings("unchecked")
    private void assertPredicates(String gtew, String startDateTime) {
        Root<DataIngestionDetails> root = (Root<DataIngestionDetails>) mock(Root.class);
        CriteriaQuery<?> cq = mock(CriteriaQuery.class);
        CriteriaBuilder cb = mock(CriteriaBuilder.class);
        QueryEntryModel startDateQuery = new QueryEntryModel();
        startDateQuery.setOperation(gtew);
        startDateQuery.setKey(startDateTime);
        startDateQuery.setValue("2022-01-10");

        specifications.add(startDateQuery);
        assertNull(specifications.toPredicate(root, cq, cb));
    }

    @Test
    void testToPredicateWithGTEAndWrongKey() {
        assertPredicates("gte", "test");
    }

    @Test
    void testToPredicateWithLTEAndWrongKey() {
        assertPredicates("lte", "test");
    }

    @Test
    void testFormatDataTime() {
        OffsetDateTime dateTime = ReflectionTestUtils.invokeMethod(specifications, "formatToOffsetTime", "2022-03-07");
        assertEquals(OffsetDateTime.of(LocalDate.parse("2022-03-07", DateTimeFormatter.ofPattern(YYYY_MM_DD)), LocalTime.NOON, ZoneOffset.UTC), dateTime);
    }

    private OffsetDateTime formatToOffsetTime(String value) {
        LocalDate date = LocalDate.parse(value, DateTimeFormatter.ofPattern(YYYY_MM_DD));
        return OffsetDateTime.of(date, LocalTime.NOON, ZoneOffset.UTC);
    }
}
