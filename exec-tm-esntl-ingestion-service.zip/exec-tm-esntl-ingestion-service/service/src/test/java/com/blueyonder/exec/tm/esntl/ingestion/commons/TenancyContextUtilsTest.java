/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import org.junit.jupiter.api.Test;

import com.blueyonder.service.common.liam.identity.IdentityScope;
import com.jda.security.tenancy.TenancyContext;
import com.jda.security.tenancy.TenancyContextHolder;
import com.jda.security.tenancy.Tenant;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class TenancyContextUtilsTest {

    @Test
    void runWithContext() {
        TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("id", "alias", true)));

        assertDoesNotThrow(() -> {
                    StepVerifier.create(TenancyContextUtils.runWithContext(Mono.just("test-data")))
                            .assertNext(response -> {
                                assertNotNull(TenancyContextHolder.getContext());
                                assertEquals("alias", TenancyContextHolder.getContext().getTenant().getAlias());
                                assertEquals("id", TenancyContextHolder.getContext().getTenant().getId());
                                assertEquals("test-data", response);
                            });
                }
        );
    }

    @Test
    void testRunWithContext() {
        TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("test", "test", true)));
        TenancyContextUtils.runWithContext(Mono.just("test-data"), s -> {
        });

        assertNotNull(TenancyContextHolder.getContext().getTenant());
        assertEquals("test", TenancyContextHolder.getContext().getTenant().getAlias());
    }

    @Test
    void testSetContext() {
        assertNotNull(TenancyContextHolder.getContext());
        assertNotNull(IdentityScope.getCurrentIdentity());
    }
}
