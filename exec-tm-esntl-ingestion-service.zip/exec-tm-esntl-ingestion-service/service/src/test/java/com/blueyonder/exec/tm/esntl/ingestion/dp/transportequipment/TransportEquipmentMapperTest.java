/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.plat.dp.bydm.LanguageCode;
import com.blueyonder.plat.dp.bydm.MeasurementTypeCode;
import com.blueyonder.plat.dp.bydm.TransportEquipmentTransportEquipmentType;

import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.LENGTH;
import static com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionServiceConstants.WEIGHT;
import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildTransportEquipment;
import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.getUnitOfMeasures;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TransportEquipmentMapperTest {

    private final TransportEquipmentMapper transportEquipmentMapper = Mappers.getMapper(TransportEquipmentMapper.class);

    @Test
    void testTransportEquipmentMapper() {
        TransportEquipmentEntity transportEquipment = buildTransportEquipment("trans_equip_1");
        Map<String, String> unitOfMeasures = getUnitOfMeasures();

        TransportEquipmentTransportEquipmentType transportEquipmentType = transportEquipmentMapper.mapToTransportEquipmentType(transportEquipment, unitOfMeasures);

        assertEquals(transportEquipment.getTransportEquipmentId(), transportEquipmentType.getTransportEquipmentId());

        assertEquals(unitOfMeasures.get(LENGTH), transportEquipmentType.getLength().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getLength(), transportEquipmentType.getLength().getValue());

        assertEquals(unitOfMeasures.get(LENGTH), transportEquipmentType.getWidth().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getWidth(), transportEquipmentType.getWidth().getValue());

        assertEquals(unitOfMeasures.get(LENGTH), transportEquipmentType.getHeight().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getHeight(), transportEquipmentType.getHeight().getValue());

        assertEquals(unitOfMeasures.get(WEIGHT), transportEquipmentType.getTareWeight().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getTareWeight(), transportEquipmentType.getTareWeight().getValue());

        assertEquals(unitOfMeasures.get(LENGTH), transportEquipmentType.getMaximumLoadingHeight().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getMaximumLoadingHeight(), transportEquipmentType.getMaximumLoadingHeight().getValue());

        assertEquals(unitOfMeasures.get(LENGTH), transportEquipmentType.getMaximumLoadingLength().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getMaximumLoadingLength(), transportEquipmentType.getMaximumLoadingLength().getValue());

        assertEquals(unitOfMeasures.get(LENGTH), transportEquipmentType.getMaximumLoadingWidth().getMeasurementUnitCode().value());
        assertEquals(transportEquipment.getMaximumLoadingWidth(), transportEquipmentType.getMaximumLoadingWidth().getValue());

        assertEquals(LanguageCode.EN, transportEquipmentType.getDescription().getLanguageCode());
        assertEquals(transportEquipment.getDescription(), transportEquipmentType.getDescription().getValue());

        assertEquals(transportEquipment.getMaximumLoadingWeight(), transportEquipmentType.getUsageThresholdValues().get(0).getMaximumAllowableValue());
        assertEquals(MeasurementTypeCode.WEIGHT, transportEquipmentType.getUsageThresholdValues().get(0).getMeasurementType());
        assertEquals(unitOfMeasures.get(WEIGHT), transportEquipmentType.getUsageThresholdValues().get(0).getMeasurementUnitCode().value());
        checkTheCommodityDataForEquipment(transportEquipment, transportEquipmentType);
    }

    private void checkTheCommodityDataForEquipment(TransportEquipmentEntity transportEquipment, TransportEquipmentTransportEquipmentType transportEquipmentType) {
        assertEquals(transportEquipment.getLoadingDurationInHours(), transportEquipmentType.getLoadingDurationInHours());
        assertEquals(transportEquipment.getUnloadingDurationInHours(), transportEquipmentType.getUnloadingDurationInHours());
        assertEquals(transportEquipment.getCommodityRestrictions().get(0).getCommodityRestrictionCode().toString(), transportEquipmentType.getCommodityRestrictions().get(0).getRestrictionCode().value());
        assertEquals(transportEquipment.getCommodityRestrictions().get(0).getCommodityType(), transportEquipmentType.getCommodityRestrictions().get(0).getCommodityCode());
    }

    @Test
    void checkTheCommodityDataForEquipWithOnlyMandatoryValues() {
        TransportEquipmentEntity transportEquipment = buildTransportEquipment("trans_equip_1");
        Map<String, String> unitOfMeasures = getUnitOfMeasures();
        transportEquipment.setLoadingDurationInHours(null);
        transportEquipment.setUnloadingDurationInHours(null);

        TransportEquipmentTransportEquipmentType transportEquipmentType = transportEquipmentMapper.mapToTransportEquipmentType(transportEquipment, unitOfMeasures);

        assertNull(transportEquipment.getLoadingDurationInHours());
        assertNull(transportEquipment.getUnloadingDurationInHours());
        assertEquals(transportEquipment.getCommodityRestrictions().get(0).getCommodityRestrictionCode().toString(), transportEquipmentType.getCommodityRestrictions().get(0).getRestrictionCode().value());
        assertEquals(transportEquipment.getCommodityRestrictions().get(0).getCommodityType(), transportEquipmentType.getCommodityRestrictions().get(0).getCommodityCode());
    }
}
