/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class IngestionRequestMapperTest {

    private IngestionRequestMapper ingestionRequestMapper = Mappers.getMapper(IngestionRequestMapper.class);

    @Test
    void testToModel() {
        IngestionRequestEntity ingestionRequestEntity = new IngestionRequestEntity();
        ingestionRequestEntity.setRequestId(UUID.randomUUID());
        ingestionRequestEntity.setEntityType(IngestionType.CARRIER);
        ingestionRequestEntity.setFileName("Carrier.xlsx");
        ingestionRequestEntity.setFileId("carrierFileId");
        var ingestionRequestModel = ingestionRequestMapper.toIngestionRequestModel(ingestionRequestEntity);

        assertEquals(ingestionRequestEntity.getRequestId(), ingestionRequestModel.getRequestId());
        assertEquals(ingestionRequestEntity.getEntityType().name(), ingestionRequestModel.getEntityType().name());
        assertEquals(ingestionRequestEntity.getFileName(), ingestionRequestModel.getFileName());
        assertEquals(ingestionRequestEntity.getFileId(), ingestionRequestModel.getFileId());

        var instant = Instant.now();
        var expectedOffsetDateTime = OffsetDateTime.parse(instant.toString());
        var actualOffsetDateTime = ingestionRequestMapper.toOffsetDateTime(instant);

        assertEquals(expectedOffsetDateTime, actualOffsetDateTime);
    }

}
