/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.PageDataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryEntryModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.QueryPaginationModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.DataIngestSpecification;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionMetadataRepository;

import static com.blueyonder.exec.tm.esntl.ingestion.workflow.MetaDataDetailsService.DEFAULT_LIMIT;
import static com.blueyonder.exec.tm.esntl.ingestion.workflow.MetaDataDetailsService.DEFAULT_PAGE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MetadataDetailsServiceTest {

    @InjectMocks
    private MetaDataDetailsService metaDataDetailsService;

    @Mock
    private IngestionMetadataRepository ingestionMetadataRepository;

    @Test
    void testGetRecords() {
        when(ingestionMetadataRepository.findAll(any(Sort.class))).thenReturn(List.of(buildDataIngestionDetails()));

        List<DataIngestionDetailsModel> dataIngestionDetailsModels = metaDataDetailsService.loadAllIngestionMetaData();

        assertNotNull(dataIngestionDetailsModels);
        assertEquals(1, dataIngestionDetailsModels.size());
    }

    @Test
    void testDataUploadSearch() {
        QueryModel query = buildQueryModel();
        Page<DataIngestionDetails> dataIngestionDetails = new PageImpl<>(List.of(buildDataIngestionDetails()), PageRequest.of(0, 3), 10L);
        when(ingestionMetadataRepository.findAll(any(DataIngestSpecification.class), any(Pageable.class))).thenReturn(dataIngestionDetails);

        PageDataIngestionDetailsModel dataIngestionDetailsModels = metaDataDetailsService.queryIngestionMetaData(query);

        assertNotNull(dataIngestionDetailsModels);
        assertNotNull(dataIngestionDetailsModels.getContent());
        assertEquals(1, dataIngestionDetailsModels.getContent().size());
        assertEquals(dataIngestionDetails.getTotalElements(), dataIngestionDetailsModels.getTotalElements());
        assertEquals(dataIngestionDetails.getTotalPages(), dataIngestionDetailsModels.getTotalPages());
        assertEquals(dataIngestionDetails.getSize(), dataIngestionDetailsModels.getSize());
        assertEquals(dataIngestionDetails.getNumber(), dataIngestionDetailsModels.getNumber());
        assertEquals(dataIngestionDetails.getSort().isSorted(), dataIngestionDetailsModels.getSort().getSorted());
        assertEquals(dataIngestionDetails.getSort().isUnsorted(), dataIngestionDetailsModels.getSort().getUnsorted());
        assertEquals(dataIngestionDetails.getNumberOfElements(), dataIngestionDetailsModels.getNumberOfElements());
        assertEquals(dataIngestionDetails.getSort().isEmpty(), dataIngestionDetailsModels.getSort().getEmpty());
        assertEquals(dataIngestionDetails.isFirst(), dataIngestionDetailsModels.getFirst());
        assertEquals(dataIngestionDetails.isLast(), dataIngestionDetailsModels.getLast());
        assertEquals(dataIngestionDetails.getPageable().getPageSize(), dataIngestionDetailsModels.getPageable().getPageSize());
        assertEquals(dataIngestionDetails.getPageable().isPaged(), dataIngestionDetailsModels.getPageable().getPaged());
        assertEquals(dataIngestionDetails.getPageable().getOffset(), dataIngestionDetailsModels.getPageable().getOffset());
        assertEquals(dataIngestionDetails.getPageable().getPageNumber(), dataIngestionDetailsModels.getPageable().getPageNumber());
    }

    @Test
    void testDataUploadSearchWithDefaultPageable() {
        QueryModel query = buildQueryModel();
        query.setPagination(null);
        Page<DataIngestionDetails> dataIngestionDetails = new PageImpl<>(List.of(buildDataIngestionDetails()), PageRequest.of(0, 3), 10L);
        when(ingestionMetadataRepository.findAll(any(DataIngestSpecification.class), any(Pageable.class))).thenReturn(dataIngestionDetails);

        PageDataIngestionDetailsModel dataIngestionDetailsModels = metaDataDetailsService.queryIngestionMetaData(query);

        assertNotNull(dataIngestionDetailsModels);
        assertNotNull(dataIngestionDetails.getPageable());
        assertEquals(DEFAULT_LIMIT, dataIngestionDetailsModels.getPageable().getPageSize());
        assertEquals(dataIngestionDetails.getPageable().isPaged(), dataIngestionDetailsModels.getPageable().getPaged());
        assertEquals(dataIngestionDetails.getPageable().getOffset(), dataIngestionDetailsModels.getPageable().getOffset());
        assertEquals(DEFAULT_PAGE, dataIngestionDetailsModels.getPageable().getPageNumber());
    }

    private List<QueryEntryModel> buildQueryEntryModel() {
        List<QueryEntryModel> filter = new ArrayList<>();
        QueryEntryModel queryEntry = new QueryEntryModel();
        queryEntry.setOperation("gte");
        queryEntry.setKey("startDateTime");
        queryEntry.setValue("2022-01-10");
        filter.add(queryEntry);
        return filter;
    }

    private QueryModel buildQueryModel() {
        QueryPaginationModel pagination = new QueryPaginationModel();
        pagination.setLimit(3);
        pagination.setOffset(0);
        QueryModel query = new QueryModel();
        query.setFilter(buildQueryEntryModel());
        query.setPagination(pagination);
        return query;
    }

    private DataIngestionDetails buildDataIngestionDetails() {
        DataIngestionDetails dataIngestionDetail = new DataIngestionDetails();
        dataIngestionDetail.setStatus("COMPLETED_WITH_ERROR");
        dataIngestionDetail.setEntityType("TRANSPORT_EQUIPMENT");
        return dataIngestionDetail;
    }

}
