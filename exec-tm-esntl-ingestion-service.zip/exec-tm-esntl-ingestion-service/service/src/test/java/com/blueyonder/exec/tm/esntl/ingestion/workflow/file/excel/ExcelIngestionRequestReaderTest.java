/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.file.excel;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionSourceType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.dp.carrier.CarrierEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class ExcelIngestionRequestReaderTest {

    @Test
    void testProcessFile() throws IOException {
        IngestionRequest ingestionRequest = new ExcelIngestionRequestReader("Carrier.xlsx",
                IngestionEntitySchema.of(CarrierEntity.class))
                .read(new ClassPathResource("Carrier.xlsx").getInputStream());

        assertEquals(2, ingestionRequest.getRequestPages().size());
        assertEquals(1, ingestionRequest.getRequestPages().get("Carrier").getEntities().size());
        assertEquals(1, ingestionRequest.getRequestPages().get("Carrier Services").getEntities().size());

        assertFalse(ingestionRequest.getFirstRequestPage().hasError());
        assertFalse(ingestionRequest.getRequestPages().get("Carrier Services").hasError());

        assertEquals(IngestionSourceType.EXCEL, ingestionRequest.getSourceType());
        assertEquals("Carrier.xlsx", ingestionRequest.getSourceName());
    }
}
