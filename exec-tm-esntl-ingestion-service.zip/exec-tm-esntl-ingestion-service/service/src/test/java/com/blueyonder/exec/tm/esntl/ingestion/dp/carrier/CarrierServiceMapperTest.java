/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ServiceLevelCodeModel;

import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildCarrierServicesData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class CarrierServiceMapperTest {

    private final CarrierServiceMapper carrierServiceMapper = Mappers.getMapper(CarrierServiceMapper.class);

    @Test
    void testMapCarrierServicesToCarrierData() {
        CarrierServiceEntity services = buildCarrierServicesData("carrierId", ServiceLevelCodeModel.GROUND, "serviceType1");

        CarrierService carrierData = carrierServiceMapper.mapToCarrierService(services, new CarrierService());

        assertEquals(services.getCarrierId(), carrierData.getCarrierId());
        assertNull(carrierData.getServiceDetails());
    }
}
