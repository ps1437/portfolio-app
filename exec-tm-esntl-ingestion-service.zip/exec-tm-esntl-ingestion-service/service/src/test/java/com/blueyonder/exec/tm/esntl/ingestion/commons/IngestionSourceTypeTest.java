package com.blueyonder.exec.tm.esntl.ingestion.commons;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class IngestionSourceTypeTest {

    @Test
    void testSupportedTypes() {
        assertEquals(IngestionSourceType.EXCEL, IngestionSourceType.fromValue("xls"));
        assertEquals(IngestionSourceType.EXCEL, IngestionSourceType.fromValue("xls", IngestionType.SHIPMENT));

        assertTrue(IngestionSourceType.EXCEL.getSourceTypes().contains("xlsx"));
        assertTrue(IngestionSourceType.EXCEL.getSupportedIngestionTypes().contains(IngestionType.SHIPMENT));
    }

    @Test
    void testUnsupportedTypes() {
        assertThrows(IllegalArgumentException.class, () -> IngestionSourceType.fromValue("any"));
        assertThrows(IllegalArgumentException.class, () -> IngestionSourceType.fromValue("csv",
                IngestionType.SHIPMENT));
    }
}
