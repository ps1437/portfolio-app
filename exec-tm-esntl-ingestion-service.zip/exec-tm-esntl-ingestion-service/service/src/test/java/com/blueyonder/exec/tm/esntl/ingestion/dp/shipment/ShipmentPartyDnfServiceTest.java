/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;
import com.blueyonder.plat.dp.api.model.query.Query;
import com.blueyonder.plat.dp.bydm.PartyType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ShipmentPartyDnfServiceTest {

    @InjectMocks
    private ShipmentPartyDnfService partyService;

    @Mock
    private PartyDpClient partyDpClient;

    @Test
    void testPopulatePartyBillToId() {
        List<String> buyerIds = List.of("partyId1", "partyId2", "partyId3");
        List<PartyType> partyTypes = List.of(DpTestUtils.buildPartyTypeData("partyId1"), DpTestUtils.buildPartyTypeData("partyId2"));
        when(partyDpClient.getByQuery(any(Query.class))).thenReturn(Mono.just(partyTypes));

        Map<String, String> partyTypesMap = partyService.populatePartyBillToId(buyerIds);

        String expectedBillToId = partyTypes.get(0).getBasicParty().getFinancialInformation().getBillTo().getPrimaryId();
        String expectedBillToId2 = partyTypes.get(1).getBasicParty().getFinancialInformation().getBillTo().getPrimaryId();

        assertEquals(partyTypes.size(), partyTypesMap.size());
        assertEquals(expectedBillToId, partyTypesMap.get(partyTypes.get(0).getPartyId()));
        assertEquals(expectedBillToId2, partyTypesMap.get(partyTypes.get(1).getPartyId()));
    }

    @Test
    void testPopulatePartyBillToIdEmpty() {
        when(partyDpClient.getByQuery(any(Query.class))).thenReturn(Mono.just(Collections.emptyList()));

        Map<String, String> partyTypesMap = partyService.populatePartyBillToId(List.of("partyId1", "partyId2"));

        assertEquals(0, partyTypesMap.size());
    }
}
