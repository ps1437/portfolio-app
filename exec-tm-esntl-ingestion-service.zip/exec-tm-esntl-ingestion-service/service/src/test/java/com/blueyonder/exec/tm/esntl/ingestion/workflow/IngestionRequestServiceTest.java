/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import reactor.core.publisher.Mono;

import org.hibernate.exception.JDBCConnectionException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.blueyonder.exec.ecom.boot.commons.web.error.InternalServerAppException;
import com.blueyonder.exec.ecom.boot.commons.web.error.NotFoundAppException;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.messaging.IngestionEventPublisher;
import com.blueyonder.plat.lui.api.model.v1.FileQueryResponseModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@DisplayName("Ingestion Request Service Tests")
@ExtendWith(MockitoExtension.class)
public class IngestionRequestServiceTest {

    private static final String CARRIER_FILE_ID = "63cec1337b2d4bdd168c408c";

    private static final String CARRIER_FILE_NAME = "Carrier.xlsx";

    @Mock
    private FileStorageService fileStorageService;

    @Mock
    private IngestionEntityManager ingestionEntityManager;

    @Mock
    private IngestionEventPublisher ingestionEventPublisher;

    @InjectMocks
    private IngestionRequestService ingestionRequestService;

    @DisplayName("create ingestion request")
    @Test
    void testCreateIngestion() {
        FileQueryResponseModel fileQueryResponseModel = new FileQueryResponseModel();
        fileQueryResponseModel.setFileName(CARRIER_FILE_NAME);

        IngestionRequestEntity expectedIngestionRequestEntity = new IngestionRequestEntity();
        expectedIngestionRequestEntity.setFileId(CARRIER_FILE_ID);
        expectedIngestionRequestEntity.setFileName(CARRIER_FILE_NAME);

        when(fileStorageService.getFileDetails(any())).thenReturn(Mono.just(fileQueryResponseModel));
        when(ingestionEntityManager.createIngestionRequest(any(), any(), any())).thenReturn(expectedIngestionRequestEntity);
        doNothing().when(ingestionEventPublisher).publish(any());

        IngestionRequestEntity actualIngestionRequestEntity = ingestionRequestService.createIngestion(IngestionType.CARRIER, CARRIER_FILE_ID);

        assertEquals(expectedIngestionRequestEntity.getFileId(), actualIngestionRequestEntity.getFileId());
        assertEquals(expectedIngestionRequestEntity.getFileName(), actualIngestionRequestEntity.getFileName());
    }

    @DisplayName("create ingestion request failure as provided file id is invalid")
    @Test
    void testCreateIngestionFailureFileNotFound() {
        when(fileStorageService.getFileDetails(any())).thenThrow(WebClientResponseException.NotFound.class);
        try {
            ingestionRequestService.createIngestion(IngestionType.CARRIER, CARRIER_FILE_ID);
            fail("Expected WebClientResponseException.NotFound exception");
        }
        catch (NotFoundAppException e) {
            assertNotNull(e.getLocalizedMessage());
        }
    }

    @DisplayName("create ingestion request failure as request to upload service failed")
    @Test
    void testCreateIngestionFailureServiceUnavailable() {
        when(fileStorageService.getFileDetails(any())).thenThrow(WebClientRequestException.class);
        try {
            ingestionRequestService.createIngestion(IngestionType.CARRIER, CARRIER_FILE_ID);
            fail("Expected ServiceUnavailableAppException exception");
        }
        catch (InternalServerAppException e) {
            assertNotNull(e.getLocalizedMessage());
        }
    }

    @DisplayName("create ingestion request failure as internal communication is unauthorized")
    @Test
    void testCreateIngestionFailureNotAuthorized() {
        when(fileStorageService.getFileDetails(any())).thenThrow(WebClientResponseException.Unauthorized.class);
        try {
            ingestionRequestService.createIngestion(IngestionType.CARRIER, CARRIER_FILE_ID);
            fail("Expected ServiceUnavailableAppException exception");
        }
        catch (InternalServerAppException e) {
            assertNotNull(e.getLocalizedMessage());
        }
    }

    @DisplayName("create ingestion request failure because of an internal app error")
    @Test
    void testCreateIngestionFailureJDBCError() {
        when(fileStorageService.getFileDetails(any())).thenThrow(JDBCConnectionException.class);
        try {
            ingestionRequestService.createIngestion(IngestionType.CARRIER, CARRIER_FILE_ID);
            fail("Expected InternalServerAppException exception");
        }
        catch (InternalServerAppException e) {
            assertNotNull(e.getLocalizedMessage());
        }
    }

}
