/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.carrier;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClientRequestException;

import com.blueyonder.exec.tm.esntl.ingestion.TestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.dp.BatchIngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.dp.BatchIngestionResponseAggregator;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.PartyDpClient;
import com.blueyonder.plat.dp.api.model.EntityErrorResponseModel;
import com.blueyonder.plat.dp.api.model.ErrorMessageTypeModel;
import com.blueyonder.plat.dp.api.model.PostEntityResponseModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CarrierIngestionServiceTest {

    private final CarrierIngestionService ingestionService;

    private final DataStorageService dataStorageService;

    private final DpClient dpClient;

    private PartyDpClient partyDpClient;

    private PostIngestionService postIngestionService;

    private IngestionConfigProperties ingestionConfigProperties;

    CarrierIngestionServiceTest() {
        this.partyDpClient = mock(PartyDpClient.class);
        this.dataStorageService = mock(DataStorageService.class);
        this.dpClient = mock(DpClient.class);
        this.postIngestionService = mock(PostIngestionService.class);
        this.ingestionConfigProperties = mock(IngestionConfigProperties.class);
        CarrierMapper mapper = Mappers.getMapper(CarrierMapper.class);
        CarrierServiceMapper carrierModelMapper = Mappers.getMapper(CarrierServiceMapper.class);
        this.ingestionService = new CarrierIngestionService(dpClient, partyDpClient, dataStorageService, postIngestionService, mapper, carrierModelMapper, ingestionConfigProperties);
    }

    @Test
    void testGetType() {
        assertEquals(IngestionType.CARRIER, ingestionService.getType());
        assertNotNull(ingestionService.getEntitySchema().getEntityDef("Carrier"));
    }

    @Test
    void testFileBasedIngest() {
        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
        IngestionConfigProperties.BatchConfig batchConfig = new IngestionConfigProperties.BatchConfig();
        batchConfig.setBatchSize(25);
        when(ingestionConfigProperties.getBatchConfig()).thenReturn(batchConfig);
        when(partyDpClient.create(any())).thenReturn(Mono.just(mock(PostEntityResponseModel.class)));
        doNothing().when(postIngestionService).processIngestion(any());

        var ingestionRequest = TestUtils.buildIngestionRequest(ingestionService, "Carrier.xlsx");
        var actualDataIngestionDetails = ingestionService.ingest(ingestionRequest);
        verify(partyDpClient, times(1)).create(any());
        assertEquals(dataIngestionDetails, actualDataIngestionDetails);
        assertEquals(ingestionRequest.getRequestId(), dataIngestionDetails.getId());
    }

    @Test
    void testFileBasedIngestError() {
        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
        IngestionConfigProperties.BatchConfig batchConfig = new IngestionConfigProperties.BatchConfig();
        batchConfig.setBatchSize(25);
        when(ingestionConfigProperties.getBatchConfig()).thenReturn(batchConfig);
        when(partyDpClient.create(any())).thenThrow(WebClientRequestException.class);
        doNothing().when(postIngestionService).processIngestion(any());

        ingestionService.ingest(TestUtils.buildIngestionRequest(ingestionService, "Carrier.xlsx"));
        verify(dpClient, times(1)).ingest(any(), anyList());
    }

    @Test
    void BatchIngestionResponseTest() {
        EntityErrorResponseModel errorResponseModel1 = mock(EntityErrorResponseModel.class);
        ErrorMessageTypeModel errorMessageTypeModel1 = new ErrorMessageTypeModel();
        errorMessageTypeModel1.setUserMessage("Validation failed for primaryId AMH6D2GPN27C1. Error: Referential integrity check failed: '$[31].shipFrom.locationId:LTMS-PSR-LID-R33' required but not found. Add entity in the location with locationId = LTMS-PSR-LID-R31");
        when(errorResponseModel1.getErrors()).thenReturn(List.of(errorMessageTypeModel1));

        EntityErrorResponseModel errorResponseModel2 = mock(EntityErrorResponseModel.class);
        ErrorMessageTypeModel errorMessageTypeModel2 = new ErrorMessageTypeModel();
        errorMessageTypeModel2.setUserMessage("Validation failed for primaryId AMH6D2GPN27C2. Error: Referential integrity check failed: '$[32].shipFrom.locationId:LTMS-PSR-LID-R33' required but not found. Add entity in the location with locationId = LTMS-PSR-LID-R32");
        when(errorResponseModel2.getErrors()).thenReturn(List.of(errorMessageTypeModel2));

        var requestId = UUID.randomUUID();
        var ingestionRequest = TestUtils.buildIngestionRequest(ingestionService, "Carrier.xlsx");
        BatchIngestionResponse batchIngestionResponse1 = new BatchIngestionResponse(requestId, 1, ingestionRequest, errorResponseModel1);
        BatchIngestionResponse batchIngestionResponse2 = new BatchIngestionResponse(requestId, 2, ingestionRequest, errorResponseModel2);
        BatchIngestionResponseAggregator aggregator = new BatchIngestionResponseAggregator();
        aggregator.aggregate(batchIngestionResponse1);
        var ingestionResponse = aggregator.aggregate(batchIngestionResponse2);

        assertEquals(2, ingestionResponse.getErrorResponse().size());
        assertFalse(ingestionResponse.getErrorResponse().isEmpty());
        assertNotEquals(Set.of(""), ingestionResponse.getErrorResponse().keySet());
        assertNotNull(batchIngestionResponse1.getBatchId());
        assertNotNull(batchIngestionResponse1.getBatchSeq());
        assertNotNull(batchIngestionResponse1.getEntityErrorResponseModel());
    }

    //    @Test
    //    void testCarrierProcessDpIngest() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForCarrier());
    //            DataIngestionDetails dataIngestionResponse = carrierIngestionService.process(mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(dpClient, times(1)).ingest(any(), anyList());
    //        }
    //    }

    //    @Test
    //    void testCarrierProcessDpIngestError() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.error(new RuntimeException("something went wrong")));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForCarrier());
    //            DataIngestionDetails dataIngestionResponse = carrierIngestionService.process(mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            verify(dataStorageService, times(1)).updateErrorFileDetails(anyString(), anyString(), anyInt());
    //        }
    //    }

    //    @Test
    //    void testCarrierWithEmptyDomain() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(partyDpClient.ingest(anyList())).thenReturn(Mono.just(TestUtils.buildIngestionResponseModel()));
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForCarrier());
    //
    //            DataIngestionDetails dataIngestionResponse = carrierIngestionService.process(mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(postIngestionService).processIngestion(postIngestRequestArgumentCaptor.capture());
    //            PostIngestRequest argumentCaptorValue = postIngestRequestArgumentCaptor.getValue();
    //            assertNotNull(argumentCaptorValue);
    //            assertEquals(DomainType.CARRIER, argumentCaptorValue.getParentEntityType());
    //            assertNotNull(argumentCaptorValue.getChildEntityTypes());
    //        }
    //    }

    //    @Test
    //    void testCarrierWithEmptyRecords() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = TestUtils.buildDomainResultSetMapForCarrier();
    //        resultSetMap.get(DomainType.CARRIER).setEntities(List.of());
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(resultSetMap);
    //
    //            carrierIngestionService.process(mockMultiPartReq());
    //
    //            fail("expected fail");
    //        }
    //        catch (Exception exception) {
    //            assertTrue(exception instanceof ResponseErrorMarkerException);
    //        }
    //    }

    //    @Test
    //    void testCarrierError() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(partyDpClient.ingest(anyList())).thenReturn(Mono.just(TestUtils.buildIngestionResponseModel()));
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.error(new RuntimeException("Failed to ingest")));
    //
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForCarrier());
    //
    //            DataIngestionDetails dataIngestionResponse = carrierIngestionService.process(mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(dpClient, times(1)).ingest(any(), anyList());
    //            verify(dataStorageService, times(1)).updateErrorFileDetails(any(), anyString(), anyInt());
    //        }
    //    }
}
