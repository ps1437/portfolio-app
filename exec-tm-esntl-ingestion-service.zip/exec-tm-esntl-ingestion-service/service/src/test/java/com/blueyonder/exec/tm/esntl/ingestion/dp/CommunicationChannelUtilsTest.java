/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.PartyContactType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CommunicationChannelUtilsTest {

    @Test
    void testMapCommunicationChannel() {
        List<LocationContactType> contactTypes = CommunicationChannelUtils.getLocationContactTypes("email", "website", "1809888", "telefax", "personName");

        assertNotNull(contactTypes);
        List<CommunicationChannelType> communicationChannel = contactTypes.get(0).getCommunicationChannel();
        assertEquals("email", communicationChannel.get(0).getCommunicationValue());
        assertEquals("EMAIL", communicationChannel.get(0).getCommunicationChannelCode().value());
        assertEquals("website", communicationChannel.get(1).getCommunicationValue());
        assertEquals("WEBSITE", communicationChannel.get(1).getCommunicationChannelCode().value());
        assertEquals("1809888", communicationChannel.get(2).getCommunicationValue());
        assertEquals("TELEPHONE", communicationChannel.get(2).getCommunicationChannelCode().value());
        assertEquals("telefax", communicationChannel.get(3).getCommunicationValue());
        assertEquals("TELEFAX", communicationChannel.get(3).getCommunicationChannelCode().value());
    }

    @Test
    void testMapPartyContactTypes() {
        List<PartyContactType> contactTypes = CommunicationChannelUtils.getPartyContactTypes("email", "website", "1809888", "telefax", "personName");

        assertNotNull(contactTypes);
        List<CommunicationChannelType> communicationChannel = contactTypes.get(0).getCommunicationChannel();
        assertEquals("email", communicationChannel.get(0).getCommunicationValue());
        assertEquals("EMAIL", communicationChannel.get(0).getCommunicationChannelCode().value());
        assertEquals("website", communicationChannel.get(1).getCommunicationValue());
        assertEquals("WEBSITE", communicationChannel.get(1).getCommunicationChannelCode().value());
        assertEquals("1809888", communicationChannel.get(2).getCommunicationValue());
        assertEquals("TELEPHONE", communicationChannel.get(2).getCommunicationChannelCode().value());
        assertEquals("telefax", communicationChannel.get(3).getCommunicationValue());
        assertEquals("TELEFAX", communicationChannel.get(3).getCommunicationChannelCode().value());
    }
}
