/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.DataIngestionDetailsModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;

import static com.blueyonder.exec.tm.esntl.ingestion.api.v1.DataIngestionDetailsMapper.mapToDataIngestModelDetails;
import static com.blueyonder.exec.tm.esntl.ingestion.api.v1.DataIngestionDetailsMapper.mapToEntityTypeModel;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class DataIngestionDetailsMapperTest {

    @Test
    void testMapToDataIngestModelDetails() {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setStatus(IngestionStatusModel.PROCESSING.toString());
        dataIngestionDetails.setEntityType("LOCATION");

        DataIngestionDetailsModel dataIngestionDetailsModel = mapToDataIngestModelDetails(dataIngestionDetails);

        assertEquals(dataIngestionDetails.getStatus(), dataIngestionDetailsModel.getStatus().toString());
        assertEquals(EntityTypeModel.valueOf(dataIngestionDetails.getEntityType()).getValue(), dataIngestionDetailsModel.getEntityType());
    }

    @Test
    void testMapToEntityTypeModel() {
        assertNull(mapToEntityTypeModel(null));
        assertNull(mapToEntityTypeModel("test"));
        assertEquals(EntityTypeModel.LOCATION.getValue(), mapToEntityTypeModel("Location"));
        assertEquals(EntityTypeModel.LOCATION.getValue(), mapToEntityTypeModel(EntityTypeModel.LOCATION.toString()));
        assertEquals(EntityTypeModel.LOCATION.getValue(), mapToEntityTypeModel("LOCATION_EXCEL"));
    }
}
