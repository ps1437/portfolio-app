/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import reactor.core.publisher.Mono;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.TestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.LocationDpClient;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

@ExtendWith(MockitoExtension.class)
class LocationIngestionServiceTest {

    private final LocationIngestionService ingestionService;

    private final DataStorageService dataStorageService;

    private final DpClient dpClient;

    private final IngestionConfigProperties ingestionConfigProperties;

    @Captor
    private ArgumentCaptor<IngestionResponse> postIngestRequestArgumentCaptor;

    LocationIngestionServiceTest() {
        LocationDpClient locationDpClient = mock(LocationDpClient.class, withSettings().stubOnly());
        this.dataStorageService = mock(DataStorageService.class);
        PostIngestionService postIngestionService = mock(PostIngestionService.class);
        this.dpClient = mock(DpClient.class);
        LocationMapper mapper = Mappers.getMapper(LocationMapper.class);
        this.ingestionConfigProperties = mock(IngestionConfigProperties.class);
        this.ingestionService = new LocationIngestionService(
                dpClient, locationDpClient, dataStorageService, postIngestionService, mapper, ingestionConfigProperties);
    }

    @Test
    void testGetType() {
        assertEquals(IngestionType.LOCATION, ingestionService.getType());
        assertNotNull(ingestionService.getEntitySchema().getEntityDef("Location"));
    }

    @Test
    void testFileBasedIngest() {
        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
        IngestionConfigProperties.BatchConfig batchConfig = new IngestionConfigProperties.BatchConfig();
        batchConfig.setBatchSize(25);
        when(ingestionConfigProperties.getBatchConfig()).thenReturn(batchConfig);

        ingestionService.ingest(TestUtils.buildIngestionRequest(ingestionService, "Location.xlsx"));
        verify(dpClient, times(1)).ingest(any(), anyList());
    }

    //    @Test
    //    void testLocation() throws IOException, NoSuchFieldException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(locationDpClient.ingest(anyList())).thenReturn(Mono.just(TestUtils.buildIngestionResponseModel()));
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForLocation());
    //
    //            DataIngestionDetails dataIngestionResponse = locationIngestionService.process(TestUtils.mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(dpClient, times(1)).ingest(any(), anyList());
    //        }
    //    }

    //    @Test
    //    void testLocationWithEmptyDomain() throws IOException, NoSuchFieldException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(locationDpClient.ingest(anyList())).thenReturn(Mono.just(TestUtils.buildIngestionResponseModel()));
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForLocation());
    //
    //            DataIngestionDetails dataIngestionResponse = locationIngestionService.process(TestUtils.mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(postIngestionService).processIngestion(postIngestRequestArgumentCaptor.capture());
    //            PostIngestRequest argumentCaptorValue = postIngestRequestArgumentCaptor.getValue();
    //            assertNotNull(argumentCaptorValue);
    //            assertEquals(DomainType.LOCATION, argumentCaptorValue.getParentEntityType());
    //        }
    //    }

    //    @Test
    //    void testLocationWithEmptyRecords() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = TestUtils.buildDomainResultSetMapForLocation();
    //        resultSetMap.get(DomainType.LOCATION).setEntities(List.of());
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(resultSetMap);
    //
    //            locationIngestionService.process(TestUtils.mockMultiPartReq());
    //            fail("expected fail");
    //        }
    //        catch (Exception exception) {
    //            assertTrue(exception instanceof ResponseErrorMarkerException);
    //        }
    //    }

    //    @Test
    //    void testLocationError() throws IOException, NoSuchFieldException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(locationDpClient.ingest(anyList())).thenReturn(Mono.just(TestUtils.buildIngestionResponseModel()));
    //        when(dpClient.ingest(any(), anyList())).thenReturn(Mono.error(new RuntimeException("Failed to ingest")));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetMapForLocation());
    //
    //            DataIngestionDetails dataIngestionResponse = locationIngestionService.process(TestUtils.mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(dpClient, times(1)).ingest(any(), anyList());
    //            verify(dataStorageService, times(1)).updateErrorFileDetails(any(), anyString(), anyInt());
    //        }
    //    }
}
