/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import java.io.IOException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DisplayName("Template Service tests")
@ExtendWith(MockitoExtension.class)
public class TemplateServiceTest {

    private ResourceLoader resourceLoader = new DefaultResourceLoader();

    private TemplateService templateService = new TemplateService(resourceLoader);

    @Test
    void testGetAllTemplates() throws IOException {
        var templates = templateService.getAllTemplates();
        assertNotNull(templates);
        assertNotEquals(0, templates.size());
    }

}
