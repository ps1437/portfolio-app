/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import com.blueyonder.exec.ecom.boot.commons.web.error.BadRequestAppException;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.EntityTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.TemplateTypeModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.TemplateService;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DisplayName("Ingestion Request Template Controller Test")
@ExtendWith(MockitoExtension.class)
class IngestionRequestTemplateControllerTest {

    @Mock
    private TemplateService templateService;

    @InjectMocks
    private IngestionRequestTemplateController ingestionRequestTemplateController;

    @Captor
    private ArgumentCaptor<List<String>> entitiesArgumentCaptor;

    @Captor
    private ArgumentCaptor<List<Resource>> resourceListArgumentCaptor;

    @Captor
    private ArgumentCaptor<ByteArrayOutputStream> byteArrayOutputStreamArgumentCaptor;

    @DisplayName("get supported entity types")
    @Test
    void testGetSupportedEntityTypes() {
        List<EntityTypeModel> expected = Arrays.asList(EntityTypeModel.values());
        var responseEntity = ingestionRequestTemplateController.getSupportedEntityTypes();
        assertIterableEquals(expected, responseEntity.getBody());
    }

    @DisplayName("get all templates")
    @Test
    void testGetAllTemplates() throws IOException {
        Set<TemplateTypeModel> requiredTemplates = Set.of(TemplateTypeModel.ALL);
        Resource template1 = mock(Resource.class);
        Resource template2 = mock(Resource.class);
        var resources = List.of(template1, template2);
        when(templateService.getResources(any())).thenReturn(resources);
        doNothing().when(templateService).zipResources(anyList(), any());

        var responseEntity = ingestionRequestTemplateController.getUploadTemplates(requiredTemplates);
        verify(templateService).getResources(entitiesArgumentCaptor.capture());
        verify(templateService).zipResources(resourceListArgumentCaptor.capture(), byteArrayOutputStreamArgumentCaptor.capture());

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("application/zip", responseEntity.getHeaders().get(HttpHeaders.CONTENT_TYPE).get(0));
        assertIterableEquals(List.of("All"), entitiesArgumentCaptor.getValue());
        assertIterableEquals(resources, resourceListArgumentCaptor.getValue());
        assertDoesNotThrow(() -> byteArrayOutputStreamArgumentCaptor.getValue().close());
    }

    @DisplayName("get carrier template")
    @Test
    void testGetCarrierTemplate() throws IOException {
        Set<TemplateTypeModel> requiredTemplates = Set.of(TemplateTypeModel.CARRIER);
        Resource carrierTemplate = mock(Resource.class);
        when(templateService.getResources(any())).thenReturn(List.of(carrierTemplate));

        var responseEntity = ingestionRequestTemplateController.getUploadTemplates(requiredTemplates);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", responseEntity.getHeaders().get(HttpHeaders.CONTENT_TYPE).get(0));
    }

    @DisplayName("get templates failure")
    @Test
    void testGetTemplatesFailure() {
        Set<TemplateTypeModel> requiredTemplates = Collections.emptySet();
        assertThrows(BadRequestAppException.class, () -> ingestionRequestTemplateController.getUploadTemplates(requiredTemplates));
    }

    @DisplayName("get templates failure")
    @Test
    void testGetTemplatesIOFailure() throws IOException {
        Set<TemplateTypeModel> requiredTemplates = Set.of(TemplateTypeModel.CARRIER, TemplateTypeModel.COMMODITY);
        doThrow(IOException.class).when(templateService).zipResources(any(), any());
        assertThrows(BadRequestAppException.class, () -> ingestionRequestTemplateController.getUploadTemplates(requiredTemplates));
    }

}
