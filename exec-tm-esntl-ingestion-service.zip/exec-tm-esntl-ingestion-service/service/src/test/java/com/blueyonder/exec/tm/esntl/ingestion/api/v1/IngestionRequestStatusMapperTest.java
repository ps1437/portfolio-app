/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.api.v1;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;
import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.ErrorInfoModel;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestStatusEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class IngestionRequestStatusMapperTest {

    private IngestionRequestStatusMapper ingestionRequestStatusMapper = Mappers.getMapper(IngestionRequestStatusMapper.class);

    @Test
    void testToModel() {
        IngestionRequestStatusEntity ingestionRequestStatusEntity = new IngestionRequestStatusEntity();
        ingestionRequestStatusEntity.setRequestId(UUID.randomUUID());
        ingestionRequestStatusEntity.setStatus(IngestionStatus.PROCESSING);
        ingestionRequestStatusEntity.setProcessingStartDate(OffsetDateTime.now());
        var ingestionDetailsModel = ingestionRequestStatusMapper.toIngestionRequestStatusModel(ingestionRequestStatusEntity);

        assertEquals(ingestionRequestStatusEntity.getRequestId(), ingestionDetailsModel.getRequestId());
        assertEquals(ingestionRequestStatusEntity.getStatus().toString(), ingestionDetailsModel.getStatus().toString());
        assertEquals(ingestionRequestStatusEntity.getProcessingStartDate(), ingestionDetailsModel.getProcessingStartDate());
        assertEquals(0, ingestionDetailsModel.getTotalRecordsCount());
        assertEquals(0, ingestionDetailsModel.getSuccessRecordsCount());
        assertNotNull(ingestionDetailsModel.getProcessingStartDate());
        assertNull(ingestionDetailsModel.getProcessingEndDate());
        assertNull(ingestionDetailsModel.getCreatedBy());
        assertNull(ingestionDetailsModel.getLastModifiedBy());
        assertNull(ingestionDetailsModel.getCreatedDate());
        assertNull(ingestionDetailsModel.getLastModifiedDate());

        var instant = Instant.now();
        var expectedOffsetDateTime = OffsetDateTime.parse(instant.toString());
        var actualOffsetDateTime = ingestionRequestStatusMapper.toOffsetDateTime(instant);

        assertEquals(expectedOffsetDateTime, actualOffsetDateTime);
    }

    @Test
    void testToModelPage() {
        IngestionRequestStatusEntity ingestionRequestStatusEntity = new IngestionRequestStatusEntity();
        ingestionRequestStatusEntity.setRequestId(UUID.randomUUID());
        ingestionRequestStatusEntity.setStatus(IngestionStatus.COMPLETED_WITH_ERRORS);
        ingestionRequestStatusEntity.setProcessingStartDate(OffsetDateTime.parse("2023-02-01T01:44:51.6591092+05:30"));
        ingestionRequestStatusEntity.setProcessingEndDate(OffsetDateTime.parse("2023-02-01T01:44:57.6472255+05:30"));
        ingestionRequestStatusEntity.setTotalRecordsCount(200);
        ingestionRequestStatusEntity.setSuccessRecordsCount(178);
        Page<IngestionRequestStatusEntity> ingestionStatusEntityPage = new PageImpl<>(List.of(ingestionRequestStatusEntity));

        var ingestionRequestStatusModelPage = ingestionStatusEntityPage.map(ingestionRequestStatusMapper::toIngestionRequestStatusModel);

        assertTrue(ingestionRequestStatusModelPage.hasContent());
        assertEquals(1, ingestionRequestStatusModelPage.getTotalElements());

        var ingestionDetailsModel = ingestionRequestStatusModelPage.getContent().get(0);
        assertEquals(OffsetDateTime.parse("2023-02-01T01:44:51.6591092+05:30"), ingestionDetailsModel.getProcessingStartDate());
        assertEquals(OffsetDateTime.parse("2023-02-01T01:44:57.6472255+05:30"), ingestionDetailsModel.getProcessingEndDate());
        assertEquals(200, ingestionDetailsModel.getTotalRecordsCount());
        assertEquals(178, ingestionDetailsModel.getSuccessRecordsCount());
        assertNull(ingestionDetailsModel.getCreatedBy());
        assertNull(ingestionDetailsModel.getLastModifiedBy());
        assertNull(ingestionDetailsModel.getCreatedDate());
        assertNull(ingestionDetailsModel.getLastModifiedDate());
    }

    @Test
    void testToErrorInfoModelList() {
        var errorInfo = new ErrorInfo("error-code", "user-message");
        var expected = new ErrorInfoModel();
        expected.setErrorCode("error-code");
        expected.setUserMessage("user-message");
        List<ErrorInfo> errorInfos = List.of(errorInfo);

        assertIterableEquals(List.of(expected), ingestionRequestStatusMapper.toErrorInfoModelList(errorInfos));
    }

}
