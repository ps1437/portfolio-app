/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.messaging;

import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.ecom.boot.outbox.publisher.EventEntityPublisher;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DisplayName("Ingestion event publisher tests")
@ExtendWith(MockitoExtension.class)
class IngestionEventPublisherTest {

    @Mock
    private EventEntityPublisher publisher;

    @Mock
    private IngestionConfigProperties ingestionConfigProperties;

    @InjectMocks
    private IngestionEventPublisher ingestionEventPublisher;

    @DisplayName("publish ingestion event")
    @Test
    void testPublish() {
        IngestionRequestEntity ingestionRequestEntity = mock(IngestionRequestEntity.class);
        when(ingestionRequestEntity.getRequestId()).thenReturn(UUID.randomUUID());
        IngestionConfigProperties.IngestionEventConfig eventConfig = new IngestionConfigProperties.IngestionEventConfig();
        eventConfig.setEventName("ingestion-request");
        eventConfig.setTopicName("test-topic");
        when(ingestionConfigProperties.getEventConfig()).thenReturn(eventConfig);
        when(publisher.saveAndPublishEvent(any())).thenReturn(UUID.randomUUID());

        ingestionEventPublisher.publish(ingestionRequestEntity);

        verify(publisher, times(1)).saveAndPublishEvent(any());
    }

}
