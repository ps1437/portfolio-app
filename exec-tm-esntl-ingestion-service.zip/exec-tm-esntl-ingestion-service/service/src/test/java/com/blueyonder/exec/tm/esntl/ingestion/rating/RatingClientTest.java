/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.junit.jupiter.MockServerExtension;
import org.mockserver.matchers.Times;
import org.mockserver.model.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.CarrierSelectionRulesModel;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@ExtendWith(MockServerExtension.class)
class RatingClientTest {

    public static final String CARRIER_SERVICES_ENDPOINT = "/carrierServiceSelectionRules";

    private final ClientAndServer mockClientAndServer;

    private final RatingClient ratingClient;

    RatingClientTest(ClientAndServer mockClientAndServer) {
        this.mockClientAndServer = mockClientAndServer;
        WebClient webClient = WebClient.builder()
                .baseUrl("http://localhost:" + mockClientAndServer.getLocalPort())
                .build();
        this.ratingClient = new RatingClient(webClient);
    }

    @Test
    void testAcceptRates2xx() {
        mockClientAndServer
                .when(request().withMethod("POST").withPath(CARRIER_SERVICES_ENDPOINT),
                        Times.exactly(1))
                .respond(response()
                        .withStatusCode(200)
                        .withBody(JsonUtils.toJson(buildCarrierServiceSelectionRulesResponse()), MediaType.APPLICATION_JSON));

        assertDoesNotThrow(() -> StepVerifier.create(ratingClient.createCarrierServicesSelectionRules(buildCarrierServiceSelectionRulesResponse()))
                .assertNext(response -> assertNotNull(response.getBody())).verifyComplete());
    }

    private Mono<CarrierSelectionRulesModel> buildCarrierServiceSelectionRulesResponse() {
        CarrierSelectionRulesModel carrierServiceSelectionRulesModel = new CarrierSelectionRulesModel();
        carrierServiceSelectionRulesModel.setCarrierServiceRules(List.of(RatingTestUtils.buildSelectionRulesModel()));
        return Mono.just(carrierServiceSelectionRulesModel);
    }

    @AfterEach
    void reset() {
        mockClientAndServer.reset();
    }
}
