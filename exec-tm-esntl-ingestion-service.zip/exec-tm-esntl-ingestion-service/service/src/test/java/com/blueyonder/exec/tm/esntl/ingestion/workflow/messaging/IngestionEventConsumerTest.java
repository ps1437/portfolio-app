/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.messaging;

import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.Message;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionProcessor;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.jda.security.tenancy.TenancyContext;
import com.jda.security.tenancy.TenancyContextHolder;
import com.jda.security.tenancy.Tenant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DisplayName("Ingestion event consumer tests")
@ExtendWith(MockitoExtension.class)
class IngestionEventConsumerTest {

    @Mock
    private IngestionConfigProperties ingestionConfigProperties;

    @Mock
    private IngestionProcessor ingestionProcessor;

    @InjectMocks
    private IngestionEventConsumer ingestionEventConsumer;

    @DisplayName("consume ingestion request event")
    @Test
    @SuppressWarnings("unchecked")
    void testConsume() {
        Message<byte[]> message = mock(Message.class);
        IngestionRequestEntity ingestionRequestEntity = new IngestionRequestEntity();
        ingestionRequestEntity.setRequestId(UUID.randomUUID());
        TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("by-realm-id", "by-realm", true)));
        byte[] payload = JsonUtils.toJson(ingestionRequestEntity).getBytes();
        when(message.getPayload()).thenReturn(payload);
        doNothing().when(ingestionProcessor).process(any());

        ingestionEventConsumer.consume(message);

        verify(ingestionProcessor, times(1)).process(any());
    }

}
