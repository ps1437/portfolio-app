/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating;

import java.util.UUID;

import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.SelectionRulesModel;

import static com.blueyonder.exec.tm.esntl.ingestion.TestUtils.PODAM_FACTORY;

public class RatingTestUtils {

    public static DataIngestionDetails buildDataIngestionDetails() {
        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
        dataIngestionDetails.setStatus("PROCESSING");
        dataIngestionDetails.setId(UUID.randomUUID());
        return dataIngestionDetails;
    }

    public static SelectionRulesModel buildSelectionRulesModel() {
        return PODAM_FACTORY.manufacturePojo(SelectionRulesModel.class);
    }
}
