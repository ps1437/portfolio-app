/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.transportequipment;

import reactor.core.publisher.Mono;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;

import com.bazaarvoice.jolt.JsonUtils;
import com.blueyonder.exec.tm.esntl.ingestion.TestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.TransportEquipmentDpClient;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;
import com.blueyonder.plat.lui.api.client.v1.UIConfigurationClient;
import com.blueyonder.plat.lui.api.model.v1.PreferenceResponseModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

@ExtendWith(MockitoExtension.class)
class TransportEquipmentIngestionServiceTest {

    private static final String PREFERENCES_JSON = "/preferences.json";

    private final TransportEquipmentIngestionService ingestionService;

    private final DpClient dpClient;

    private final DataStorageService dataStorageService;

    private final UIConfigurationClient uiConfigurationClient;

    private final IngestionConfigProperties ingestionConfigProperties;

    @Captor
    private ArgumentCaptor<String> fileNameCapture;

    @Captor
    private ArgumentCaptor<String> entityTypeCapture;

    TransportEquipmentIngestionServiceTest() {
        this.dpClient = mock(DpClient.class);
        TransportEquipmentDpClient transportEquipmentDpClient = mock(TransportEquipmentDpClient.class, withSettings().stubOnly());
        this.dataStorageService = mock(DataStorageService.class);
        PostIngestionService postIngestionService = mock(PostIngestionService.class);
        this.uiConfigurationClient = mock(UIConfigurationClient.class);
        TransportEquipmentMapper transportEquipmentMapper = Mappers.getMapper(TransportEquipmentMapper.class);
        this.ingestionConfigProperties = mock(IngestionConfigProperties.class);
        this.ingestionService = new TransportEquipmentIngestionService(
                dpClient, transportEquipmentDpClient, dataStorageService, postIngestionService,
                transportEquipmentMapper, uiConfigurationClient, ingestionConfigProperties);
    }

    @Test
    void testGetType() {
        assertEquals(IngestionType.TRANSPORT_EQUIPMENT, ingestionService.getType());
        assertNotNull(ingestionService.getEntitySchema().getEntityDef("Transport Equipment"));
    }

    @Test
    void testFileBasedIngest() {
        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
        when(uiConfigurationClient.getTenantPreferences()).thenReturn(Mono.just(buildPreferenceResponseModel()));
        IngestionConfigProperties.BatchConfig batchConfig = new IngestionConfigProperties.BatchConfig();
        batchConfig.setBatchSize(25);
        when(ingestionConfigProperties.getBatchConfig()).thenReturn(batchConfig);

        ingestionService.ingest(TestUtils.buildIngestionRequest(ingestionService, "Transport_Equipment.xlsx"));
        verify(dpClient, times(1)).ingest(any(), anyList());
    }

    //    @Test
    //    void testProcessEquipmentDpIngest() throws IOException {
    //        ReflectionTestUtils.setField(transportEquipmentIngestionService, "transportEquipmentMapper", Mappers.getMapper(TransportEquipmentMapper.class));
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(uiConfigurationClient.getTenantPreferences()).thenReturn(Mono.just(buildPreferenceResponseModel()));
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(createDomainResultSetMap());
    //            MockMultipartFile mockMultipartFile = TestUtils.mockMultiPartReq();
    //
    //            DataIngestionDetails dataIngestionDetailsResponse = transportEquipmentIngestionService.process(mockMultipartFile);
    //
    //            verify(dataStorageService).saveFileDetails(fileNameCapture.capture(), entityTypeCapture.capture());
    //            assertEquals(dataIngestionDetails, dataIngestionDetailsResponse);
    //            assertEquals(mockMultipartFile.getOriginalFilename(), fileNameCapture.getValue());
    //            verify(dpClient, times(1)).ingest(any(), anyList());
    //        }
    //    }

    //    @Test
    //    void testProcessEquipmentDpIngestError() throws IOException {
    //        ReflectionTestUtils.setField(transportEquipmentIngestionService, "transportEquipmentMapper", Mappers.getMapper(TransportEquipmentMapper.class));
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(uiConfigurationClient.getTenantPreferences()).thenReturn(Mono.just(buildPreferenceResponseModel()));
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(dpClient.ingest(any(), any())).thenReturn(Mono.error(new RuntimeException("Something went wrong")));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(createDomainResultSetMap());
    //            MockMultipartFile mockMultipartFile = TestUtils.mockMultiPartReq();
    //
    //            DataIngestionDetails dataIngestionDetailsResponse = transportEquipmentIngestionService.process(mockMultipartFile);
    //
    //            assertNotNull(dataIngestionDetailsResponse);
    //            verify(dataStorageService, times(1)).updateErrorFileDetails(anyString(), anyString(), anyInt());
    //        }
    //    }

    //    @Test
    //    void testEquipmentProcess() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(uiConfigurationClient.getTenantPreferences()).thenReturn(Mono.just(buildPreferenceResponseModel()));
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(createDomainResultSetMapErrors());
    //            MockMultipartFile mockMultipartFile = TestUtils.mockMultiPartReq();
    //
    //            DataIngestionDetails dataIngestionDetailsResponse = transportEquipmentIngestionService.process(mockMultipartFile);
    //
    //            verify(dataStorageService).saveFileDetails(fileNameCapture.capture(), entityTypeCapture.capture());
    //            assertEquals(dataIngestionDetails, dataIngestionDetailsResponse);
    //            assertEquals(mockMultipartFile.getOriginalFilename(), fileNameCapture.getValue());
    //            verify(postIngestionService, times(1)).processIngestion(any());
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessWithEmptyDomainSet() {
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(new HashMap<>());
    //
    //            assertThrows(ResponseErrorMarkerException.class, () -> transportEquipmentIngestionService.process(TestUtils.mockMultiPartReq()));
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessWithEmptyEntities() {
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //            IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //            ingestionRequestPage.setDomainType(DomainType.TRANSPORT_EQUIPMENT);
    //            ingestionRequestPage.setEntities(List.of());
    //            resultSetMap.put(DomainType.TRANSPORT_EQUIPMENT, ingestionRequestPage);
    //
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(new HashMap<>());
    //
    //            assertThrows(ResponseErrorMarkerException.class, () -> transportEquipmentIngestionService.process(TestUtils.mockMultiPartReq()));
    //        }
    //    }

    //    private Map<DomainType, IngestionRequestPage> createDomainResultSetMapErrors() {
    //        IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //        ingestionRequestPage.setDomainType(DomainType.TRANSPORT_EQUIPMENT);
    //        TransportEquipmentEntity transportEquipment = TestUtils.buildTransportEquipment("1");
    //        transportEquipment.setErrorMessages(List.of("error1", "error2"));
    //        ingestionRequestPage.setEntities(List.of(transportEquipment));
    //
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.TRANSPORT_EQUIPMENT, ingestionRequestPage);
    //        return resultSetMap;
    //    }

    //    private Map<DomainType, IngestionRequestPage> createDomainResultSetMap() {
    //        Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //        resultSetMap.put(DomainType.TRANSPORT_EQUIPMENT, TestUtils.buildTransportEquipmentDomainSet());
    //        return resultSetMap;
    //    }

    private PreferenceResponseModel buildPreferenceResponseModel() {
        Object object = JsonUtils.classpathToObject(PREFERENCES_JSON);
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode jsonNodes = mapper.convertValue(object, ObjectNode.class);
        PreferenceResponseModel preferenceResponseModel = new PreferenceResponseModel();
        preferenceResponseModel.setRealm(jsonNodes);
        return preferenceResponseModel;
    }
}
