/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow.domain;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.ecom.boot.commons.web.error.ErrorInfo;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ErrorInfoAttributeConverterTest {

    private ErrorInfoAttributeConverter errorInfoAttributeConverter = new ErrorInfoAttributeConverter();

    @Test
    void testConvertToDatabaseColumn() {
        String expected = "[{\"errorCode\":\"error-code\",\"userMessage\":\"user-message\"}]";
        ErrorInfo errorInfo = new ErrorInfo("error-code", "user-message", "attr-0", "attr-1");
        var actual = errorInfoAttributeConverter.convertToDatabaseColumn(List.of(errorInfo));
        assertEquals(expected, actual);
    }

    @Test
    void testConvertToEntityAttribute() {
        List<ErrorInfo> expected = List.of(new ErrorInfo("error-code", "user-message", "attr-0", "attr-1"));
        String serializedErrorInfo = "[{\"errorCode\":\"error-code\",\"userMessage\":\"user-message\"}]";
        var actual = errorInfoAttributeConverter.convertToEntityAttribute(serializedErrorInfo);

        assertEquals(expected.get(0).getErrorCode(), actual.get(0).getErrorCode());
        assertEquals(expected.get(0).getLocalizedUserMessage(), actual.get(0).getLocalizedUserMessage());
    }

}
