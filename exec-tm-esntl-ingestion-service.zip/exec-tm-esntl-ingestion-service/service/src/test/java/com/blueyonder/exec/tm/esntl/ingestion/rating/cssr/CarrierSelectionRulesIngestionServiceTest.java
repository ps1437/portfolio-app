/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.rating.cssr;

import reactor.core.publisher.Mono;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.blueyonder.exec.tm.esntl.ingestion.TestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.rating.CssrIngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.rating.RatingClient;
import com.blueyonder.exec.tm.esntl.ingestion.rating.RatingTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.IngestionEntityManager;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.CarrierSelectionResponseModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ErrorMessageModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.ErrorModel;
import com.blueyonder.exec.tm.esntl.rating.api.v1.model.StatusModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CarrierSelectionRulesIngestionServiceTest {

    private final CarrierSelectionRulesIngestionService ingestionService;

    private final DataStorageService dataStorageService;

    private final IngestionEntityManager ingestionEntityManager;

    private final RatingClient ratingClient;

    CarrierSelectionRulesIngestionServiceTest() {
        this.ratingClient = mock(RatingClient.class);
        this.dataStorageService = mock(DataStorageService.class);
        this.ingestionEntityManager = mock(IngestionEntityManager.class);
        PostIngestionService postIngestionService = mock(PostIngestionService.class);
        CarrierSelectionRulesMapper mapper = Mappers.getMapper(CarrierSelectionRulesMapper.class);
        this.ingestionService = new CarrierSelectionRulesIngestionService(ratingClient, dataStorageService, postIngestionService, mapper, ingestionEntityManager);
    }

    public static ResponseEntity<CarrierSelectionResponseModel> buildCarrierSelectionMessageModel() {
        return new ResponseEntity<>(new CarrierSelectionResponseModel(), HttpStatus.OK);
    }

    @Test
    void testGetType() {
        assertEquals(IngestionType.CARRIER_SERVICES_SELECTION_RULES, ingestionService.getType());
        assertNotNull(ingestionService.getEntitySchema().getEntityDef("Carrier Service Selection Rules"));
    }

    @Test
    void testFileBasedIngest() {
        var dataIngestionDetails = RatingTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(ratingClient.createCarrierServicesSelectionRules(any())).thenReturn(Mono.just(buildCarrierSelectionMessageModel()));

        var actualDataIngestionDetails = ingestionService.ingest(TestUtils.buildIngestionRequest(ingestionService, "CarrierServicesSelectionRules.xlsx"));
        verify(ratingClient, times(1)).createCarrierServicesSelectionRules(any());
        verify(ingestionEntityManager, times(1)).updateStatus(any(), any(), anyInt());

        assertEquals(dataIngestionDetails, actualDataIngestionDetails);
    }

    @Test
    void testBuildErrorResponse() {
        var ingestionRequest = TestUtils.buildIngestionRequest(ingestionService, "CarrierServicesSelectionRules.xlsx");
        CarrierSelectionResponseModel carrierSelectionResponseModel = mock(CarrierSelectionResponseModel.class);
        when(carrierSelectionResponseModel.getStatus()).thenReturn(StatusModel.COMPLETED_WITH_VALIDATION_ERRORS);
        var errorModel = new ErrorModel();
        errorModel.setRuleId("rule-id");
        var errorMessageModel = new ErrorMessageModel();
        errorMessageModel.setErrorCode("error-code");
        errorMessageModel.setUserMessage("user-message");
        errorModel.setMessages(List.of(errorMessageModel));
        when(carrierSelectionResponseModel.getErrors()).thenReturn(List.of(errorModel));

        CssrIngestionResponse cssrIngestionResponse = new CssrIngestionResponse(ingestionRequest, carrierSelectionResponseModel);

        assertEquals(1, cssrIngestionResponse.getErrorResponse().size());
        assertEquals("user-message", cssrIngestionResponse.getErrorResponse().get("rule-id").get(0));
    }
}
