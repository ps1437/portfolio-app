/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.zone;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.plat.dp.bydm.ZoneType;

import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildZone;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ZoneMapperTest {

    private final ZoneMapper zoneMapper = Mappers.getMapper(ZoneMapper.class);

    @Test
    void testTransportEquipmentMapper() {
        ZoneEntity zone = buildZone("zoneId_1");

        ZoneType zoneType = zoneMapper.mapToZoneType(zone);
        assertEquals(zone.getZoneIdentification(), zoneType.getZoneIdentification());
        assertEquals(zone.getCountryCode(), zoneType.getCountryCode());
        assertEquals(zone.getDescription(), zoneType.getDescription());
        assertEquals(zone.getGeographicAreas().get(0).getPostalCode(), zoneType.getGeographicArea().get(0).getFromPostalCode());
        assertEquals(zone.getGeographicAreas().get(0).getPostalCode(), zoneType.getGeographicArea().get(0).getToPostalCode());
    }
}
