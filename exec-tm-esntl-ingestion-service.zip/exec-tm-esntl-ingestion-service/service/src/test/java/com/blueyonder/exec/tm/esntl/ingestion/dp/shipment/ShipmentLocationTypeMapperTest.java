/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.blueyonder.exec.tm.esntl.ingestion.commons.ErrorMessagesForRow;
import com.blueyonder.plat.dp.bydm.LocationType;

import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildLocationType;
import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.buildShipmentDataRecord;
import static com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils.createErrorMessagesList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ShipmentLocationTypeMapperTest {

    private final ShipmentLocationTypeMapper shipmentLocationTypeMapper;

    ShipmentLocationTypeMapperTest() {
        ShipmentOriginLocationMapper shipmentOriginLocationMapper = Mappers.getMapper(ShipmentOriginLocationMapper.class);
        ShipmentDestinationLocationMapper shipmentDestinationLocationMapper = Mappers.getMapper(ShipmentDestinationLocationMapper.class);
        this.shipmentLocationTypeMapper = new ShipmentLocationTypeMapper(shipmentOriginLocationMapper, shipmentDestinationLocationMapper);
    }

    @Test
    void checkIfValidShipmentOriginLocationDataPresent() {
        ShipmentEntity shipment = buildShipmentDataRecord("123", 1);

        boolean checkStatus1 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidOriginLocationDataPresent", shipment);
        assertTrue(checkStatus1);
        shipment.setOriginCity(null);
        boolean checkStatus3 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidOriginLocationDataPresent", shipment);
        assertFalse(checkStatus3);
        shipment.setOriginCountryCode(null);
        boolean checkStatus4 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidOriginLocationDataPresent", shipment);
        assertFalse(checkStatus4);
        shipment.setOriginPostalCode(null);
        boolean checkStatus5 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidOriginLocationDataPresent", shipment);
        assertFalse(checkStatus5);
        shipment.setOriginState("");
        boolean checkStatus6 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidOriginLocationDataPresent", shipment);
        assertFalse(checkStatus6);
    }

    @Test
    void checkIfValidShipmentDestinationLocationDataPresent() {
        ShipmentEntity shipment = buildShipmentDataRecord("123", 1);

        boolean checkStatus1 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidDestinationLocationDataPresent", shipment);
        assertTrue(checkStatus1);
        shipment.setDestinationCity(null);
        boolean checkStatus3 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidDestinationLocationDataPresent", shipment);
        assertFalse(checkStatus3);
        shipment.setDestinationCountryCode(null);
        boolean checkStatus4 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidDestinationLocationDataPresent", shipment);
        assertFalse(checkStatus4);
        shipment.setDestinationPostalCode(null);
        boolean checkStatus5 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidDestinationLocationDataPresent", shipment);
        assertFalse(checkStatus5);
        shipment.setDestinationState("");
        boolean checkStatus6 = ReflectionTestUtils.invokeMethod(shipmentLocationTypeMapper, "checkIfValidDestinationLocationDataPresent", shipment);
        assertFalse(checkStatus6);
    }

    @Test
    void mapShipmentAddress() {
        ShipmentEntity shipment = buildShipmentDataRecord("123", 1);
        List<LocationType> locationTypeList = List.of(buildLocationType(shipment.getOriginLocation()), buildLocationType(shipment.getDestinationLocation()));
        Map<String, LocationType> locationTypeMap = locationTypeList.stream().collect(Collectors.toMap(LocationType::getLocationId, entity -> entity));
        shipment.setDestinationCity(null);
        shipment.setOriginCity(null);

        shipmentLocationTypeMapper.mapShipmentAddress(shipment, locationTypeMap);

        assertNotNull(shipment.getOriginCity());
        assertNotNull(shipment.getDestinationCity());
    }

    @Test
    void mapShipmentAddressWhenLocationIdNotPresent() {
        ShipmentEntity shipment = buildShipmentDataRecord("123", 1);
        List<ErrorMessagesForRow> errorMessagesForRows = createErrorMessagesList(1);

        shipmentLocationTypeMapper.mapShipmentAddress(shipment, new HashMap<>());

        String originLocationName = String.join(",", shipment.getOriginStreetAddressOne(),
                shipment.getOriginStreetAddressTwo(), shipment.getOriginStreetAddressThree(), shipment.getOriginCountryCode().value(), shipment.getOriginState(), shipment.getOriginCity(), shipment.getOriginPostalCode());
        assertEquals(originLocationName, shipment.getOriginLocationName());

        String destinationLocationName = String.join(",", shipment.getDestinationStreetAddressOne(),
                shipment.getDestinationStreetAddressTwo(), shipment.getDestinationStreetAddressThree(), shipment.getDestinationCountryCode().value(), shipment.getDestinationState(), shipment.getDestinationCity(), shipment.getDestinationPostalCode());
        assertEquals(destinationLocationName, shipment.getDestinationLocationName());
        assertEquals(1, errorMessagesForRows.size());
    }

    @Test
    void mapShipmentAddressLocationIdNotPresent() {
        ShipmentEntity shipment = buildShipmentDataRecord("123", 1);
        List<ErrorMessagesForRow> errorMessagesForRows = createErrorMessagesList(1);
        shipment.setOriginStreetAddressOne(null);
        shipment.setDestinationStreetAddressOne(null);

        shipmentLocationTypeMapper.mapShipmentAddress(shipment, new HashMap<>());

        String originLocationName = Stream.of(shipment.getOriginStreetAddressOne(),
                        shipment.getOriginStreetAddressTwo(), shipment.getOriginStreetAddressThree(), shipment.getOriginCountryCode().value(),
                        shipment.getOriginState(), shipment.getOriginCity(), shipment.getOriginPostalCode())
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(","));

        assertEquals(originLocationName, shipment.getOriginLocationName());
        String destinationLocationName = Stream.of(shipment.getDestinationStreetAddressOne(),
                        shipment.getDestinationStreetAddressTwo(), shipment.getDestinationStreetAddressThree(), shipment.getDestinationCountryCode().value(),
                        shipment.getDestinationState(), shipment.getDestinationCity(), shipment.getDestinationPostalCode())
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(","));
        assertEquals(destinationLocationName, shipment.getDestinationLocationName());
        assertEquals(1, errorMessagesForRows.size());
    }

    @Test
    void mapShipmentAddressWithInvalidLocationIdDeliveryDate() {
        ShipmentEntity shipment = buildShipmentDataRecord("shipmentId", 1);
        shipment.setDestinationLocation(shipment.getOriginLocation());
        shipment.setDispatchBeginDateTime(shipment.getPlannedBeginDateTime().minusYears(10));
        Map<String, LocationType> locationTypeMap = buildLocationTypeMap(shipment);

        shipmentLocationTypeMapper.mapShipmentAddress(shipment, locationTypeMap);

        assertNotNull(shipment);

    }

    private Map<String, LocationType> buildLocationTypeMap(ShipmentEntity shipment) {
        Map<String, LocationType> locationTypeMap = new HashMap<>();
        locationTypeMap.put(shipment.getOriginLocation(), buildLocationType("locationId"));
        return locationTypeMap;
    }

}
