/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.api.v1.model.IngestionStatusModel;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.DataIngestionDetails;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionMetadataRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DataStorageServiceTest {

    private static final String ENTITY_LOCATION = "Location";

    private static final int TOTAL_RECORD_COUNT = 20;

    private static final int TOTAL_SUCCESS_COUNT = 20;

    private static final int TOTAL_SUCCESS_PARTIAL_COUNT = 10;

    @InjectMocks
    private DataStorageService dataStorageService;

    @Mock
    private IngestionMetadataRepository ingestionMetadataRepository;

    @Captor
    private ArgumentCaptor<DataIngestionDetails> argumentCaptor;

    @Test
    void testUpdateErrorFileDetails() {
        DataIngestionDetails dataIngestionDetails = DpTestUtils.buildDataUploadDetails("Location.xlsx", ENTITY_LOCATION);
        when(ingestionMetadataRepository.findById(any())).thenReturn(Optional.of(dataIngestionDetails));
        FileUploadResponse fileUploadResponse = buildFileUploadResponse();

        dataStorageService.updateErrorFileDetails(UUID.randomUUID(), TOTAL_RECORD_COUNT, fileUploadResponse, TOTAL_SUCCESS_COUNT);

        assertEquals(IngestionStatusModel.COMPLETED.toString(), dataIngestionDetails.getStatus());
        assertNotNull(dataIngestionDetails.getEndDateTime());
        assertEquals("Location_ERROR_2021-12-16T16_17_17.051970900Z.xlsx", dataIngestionDetails.getErrorRecordsFileName());
        assertEquals(TOTAL_RECORD_COUNT, dataIngestionDetails.getTotalRecords());
        assertEquals(TOTAL_SUCCESS_COUNT, dataIngestionDetails.getTotalSuccessRecords());
        verify(ingestionMetadataRepository, times(1)).save(any());
    }

    @Test
    void testUpdateErrorFileDetailsPartialSuccess() {
        DataIngestionDetails dataIngestionDetails = DpTestUtils.buildDataUploadDetails("Location.xlsx", "Location");
        when(ingestionMetadataRepository.findById(any())).thenReturn(Optional.of(dataIngestionDetails));
        FileUploadResponse fileUploadResponse = buildFileUploadResponse();

        dataStorageService.updateErrorFileDetails(UUID.randomUUID(), TOTAL_RECORD_COUNT, fileUploadResponse, TOTAL_SUCCESS_PARTIAL_COUNT);

        assertEquals(IngestionStatusModel.COMPLETED_WITH_ERRORS.toString(), dataIngestionDetails.getStatus());
        assertNotNull(dataIngestionDetails.getEndDateTime());
        assertEquals(TOTAL_RECORD_COUNT, dataIngestionDetails.getTotalRecords());
        assertEquals(LocalDate.now().getYear(), dataIngestionDetails.getEndDateTime().getYear());
        assertEquals((TOTAL_RECORD_COUNT - TOTAL_SUCCESS_PARTIAL_COUNT), dataIngestionDetails.getTotalSuccessRecords());
        assertEquals(fileUploadResponse.getFileId(), dataIngestionDetails.getErrorRecordsFileId());
        assertEquals(fileUploadResponse.getFileName(), dataIngestionDetails.getErrorRecordsFileName());
        verify(ingestionMetadataRepository, times(1)).save(any());
    }

    @Test
    void updateErrorFileDetails() {
        DataIngestionDetails dataIngestionDetails = DpTestUtils.buildDataUploadDetails("Location.xlsx", ENTITY_LOCATION);
        when(ingestionMetadataRepository.findById(any())).thenReturn(Optional.of(dataIngestionDetails));

        dataStorageService.updateErrorFileDetails(UUID.randomUUID(), TOTAL_RECORD_COUNT, TOTAL_SUCCESS_PARTIAL_COUNT);

        assertEquals(IngestionStatusModel.COMPLETED_WITH_ERRORS.toString(), dataIngestionDetails.getStatus());
        assertNotNull(dataIngestionDetails.getEndDateTime());
        assertEquals(TOTAL_RECORD_COUNT, dataIngestionDetails.getTotalRecords());
        assertEquals(LocalDate.now().getYear(), dataIngestionDetails.getEndDateTime().getYear());
        assertEquals((TOTAL_RECORD_COUNT - TOTAL_SUCCESS_PARTIAL_COUNT), dataIngestionDetails.getTotalSuccessRecords());
        assertNull(dataIngestionDetails.getErrorRecordsFileId());
        assertNull(dataIngestionDetails.getErrorRecordsFileName());
        verify(ingestionMetadataRepository, times(1)).save(any());
    }

    @ParameterizedTest
    @CsvSource({ "FAILED,0", "COMPLETED,20" })
    void testUpdateErrorFileDetailsStatus(IngestionStatus dataIngestionStatus, int totalCount) {
        OffsetDateTime dateTime = OffsetDateTime.now(ZoneOffset.UTC);
        DataIngestionDetails dataIngestionDetails = DpTestUtils.buildDataUploadDetails("Location.csv", "Location");
        dataIngestionDetails.setEndDateTime(dateTime);
        when(ingestionMetadataRepository.findById(any())).thenReturn(Optional.of(dataIngestionDetails));

        dataStorageService.updateErrorFileDetails(UUID.randomUUID(), dataIngestionStatus, TOTAL_RECORD_COUNT);

        verify(ingestionMetadataRepository).save(argumentCaptor.capture());
        DataIngestionDetails argumentCaptorValue = argumentCaptor.getValue();
        assertEquals(dataIngestionStatus.toString(), argumentCaptorValue.getStatus());
        assertEquals(totalCount, argumentCaptorValue.getTotalSuccessRecords());
        assertEquals(TOTAL_RECORD_COUNT, argumentCaptorValue.getTotalRecords());
        assertNotNull(argumentCaptorValue.getEndDateTime());
        assertEquals(dateTime.getDayOfMonth(), argumentCaptorValue.getEndDateTime().getDayOfMonth());
    }

    @Test
    void testSaveFileDetails() {
        DataIngestionDetails dataIngestionDetails = DpTestUtils.buildDataUploadDetails("Location.csv", ENTITY_LOCATION);
        when(ingestionMetadataRepository.save(any())).thenReturn(dataIngestionDetails);

        DataIngestionDetails result = dataStorageService.saveFileDetails("Location.csv", ENTITY_LOCATION);

        assertNotNull(result);

        verify(ingestionMetadataRepository).save(argumentCaptor.capture());
        DataIngestionDetails argumentCaptorValue = argumentCaptor.getValue();
        assertEquals(dataIngestionDetails.getEntityType(), argumentCaptorValue.getEntityType());
        assertEquals(IngestionStatusModel.PROCESSING.toString(), argumentCaptorValue.getStatus());
        assertNotNull(argumentCaptorValue.getStartDateTime());
        assertEquals(dataIngestionDetails.getStartDateTime().getSecond(), argumentCaptorValue.getStartDateTime().getSecond());
    }

    private FileUploadResponse buildFileUploadResponse() {
        return new FileUploadResponse("location_test_001", "Location_ERROR_2021-12-16T16_17_17.051970900Z.xlsx");
    }

}
