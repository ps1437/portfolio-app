/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.commons;

import java.util.List;

import javax.persistence.Id;

import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Column;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.Entity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.annotation.OneToMany;

@Entity
public class ParentEntity extends IngestionEntity {

    @Id
    @Column
    private String id;

    @Column
    private String name;

    @OneToMany(joinColumnName = "parentId")
    private List<ChildEntity> childEntities;

    private String postConstructResult;

    private String postGraphConstructResult;

    public ParentEntity() {
        // Default...
    }

    public ParentEntity(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<ChildEntity> getChildEntities() {
        return childEntities;
    }

    public String getPostConstructResult() {
        return postConstructResult;
    }

    public String getPostGraphConstructResult() {
        return postGraphConstructResult;
    }

    @Override
    public void postConstruct() {
        postConstructResult = "some-data";
    }

    @Override
    public void postGraphConstruct() {
        postGraphConstructResult = "some-data";
    }
}
