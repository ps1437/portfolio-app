/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.tm.esntl.ingestion.commons.ChildEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionRequest;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.commons.ParentEntity;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionEntitySchema;
import com.blueyonder.exec.tm.esntl.ingestion.commons.orm.IngestionRequestEntityDef;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpIngestionResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadRequest;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.file.FileStorageService;
import com.blueyonder.plat.dp.api.model.v1.ErrorMessageModel;
import com.blueyonder.plat.dp.api.model.v1.EventTypeModel;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PostIngestionServiceTest {

    private static final IngestionEntityDef DEFAULT_ENTITY_DEF = new IngestionEntityDef(ParentEntity.class);

    private final PostIngestionService postIngestionService;

    private final DataStorageService dataStorageService;

    private final FileStorageService fileStorageService;

    private final IngestionEntityManager ingestionEntityManager;

    @Captor
    private ArgumentCaptor<Integer> totalEntitiesArgCaptor;

    @Captor
    private ArgumentCaptor<Integer> totalSuccessCountArgCaptor;

    @Captor
    private ArgumentCaptor<FileUploadRequest> fileUploadRequestArgCaptor;

    PostIngestionServiceTest() {
        dataStorageService = mock(DataStorageService.class);
        fileStorageService = mock(FileStorageService.class);
        ingestionEntityManager = mock(IngestionEntityManager.class);
        postIngestionService = new PostIngestionService(dataStorageService,
                new IngestionSourceFactory(),
                fileStorageService,
                ingestionEntityManager);
    }

    private static IngestionRequest buildIngestionRequest() {
        Iterator<IngestionEntityDef> itr = IngestionEntitySchema.of(DEFAULT_ENTITY_DEF).getEntityDefs().values().iterator();
        IngestionEntityDef entityDef1 = itr.next();
        IngestionEntityDef entityDef2 = itr.next();
        var requestEntityDef1 = new IngestionRequestEntityDef(entityDef1, true);
        var requestEntityDef2 = new IngestionRequestEntityDef(entityDef2, true);
        return new IngestionRequest("test_source.xlsx", List.of(requestEntityDef1, requestEntityDef2));
    }

    private static IngestionRequest buildSampleIngestionRequest(boolean withError) {
        var request = buildIngestionRequest();

        request.setRequestId(UUID.randomUUID());

        var page1 = request.getRequestPages().get("ParentEntity");

        var p1 = new ParentEntity("id-1", "name-1");
        p1.getMetadata().setExternalReferenceId("external-id-1");
        page1.addEntity(p1);

        var p2 = new ParentEntity("id-2", "name-2");
        p2.getMetadata().setExternalReferenceId("external-id-2");
        page1.addEntity(p2);

        var p3 = new ParentEntity("id-3", "name-3");
        if (withError) {
            p3.getMetadata().addErrorMessage("error");
        }
        page1.addEntity(p3);

        var page2 = request.getRequestPages().get("ChildEntity");
        var c1 = new ChildEntity("id-1", "name-2");
        page2.addEntity(c1);

        return request;
    }

    private static IngestionQueryResponseModel buildIngestionResponseModel() {
        var emm1 = new ErrorMessageModel();
        emm1.setErrorMessage("Validation failed for primaryId external-id-1.");
        var etm = new EventTypeModel();
        etm.setService("validator");
        etm.setStatus("COMPLETED_WITH_ERROR");
        etm.setErrors(List.of(emm1));
        var o = new IngestionQueryResponseModel();
        o.setEvents(List.of(etm));
        return o;
    }

    @Test
    void testProcessIngestion() {
        doNothing().when(dataStorageService).updateErrorFileDetails(
                any(UUID.class), any(IngestionStatus.class), totalEntitiesArgCaptor.capture());

        IngestionRequest request = buildSampleIngestionRequest(false);
        IngestionResponse response = new IngestionResponse(request);
        postIngestionService.processIngestion(response);

        assertEquals(request.getFirstRequestPage().getEntities().size(), totalEntitiesArgCaptor.getValue());
        verify(dataStorageService, times(1))
                .updateErrorFileDetails(any(UUID.class), any(IngestionStatus.class), anyInt());
    }

    @Test
    void testProcessIngestionWithError() {
        doNothing().when(dataStorageService).updateErrorFileDetails(
                any(UUID.class), totalEntitiesArgCaptor.capture(), any(), totalSuccessCountArgCaptor.capture());
        when(fileStorageService.uploadFile(any())).thenReturn(Flux.just(new FileUploadResponse()));

        IngestionRequest request = buildSampleIngestionRequest(true);
        DpIngestionResponse response = new DpIngestionResponse(request, buildIngestionResponseModel());
        postIngestionService.processIngestion(response);

        var page1 = request.getRequestPages().get("ParentEntity");
        var page2 = request.getRequestPages().get("ChildEntity");

        assertTrue(page1.getEntities().stream().anyMatch(e -> e.getMetadata().getErrorMessages()
                .contains("Validation failed for primaryId external-id-1.")));
        assertTrue(page2.getEntities().stream().anyMatch(e -> e.getMetadata().hasError()));

        verify(dataStorageService, times(1))
                .updateErrorFileDetails(any(UUID.class), anyInt(), any(), anyInt());
        assertEquals(page1.getEntities().size(), totalEntitiesArgCaptor.getValue());
        assertEquals(page1.getEntities().size() - 2, totalSuccessCountArgCaptor.getValue());

        verify(fileStorageService, times(1)).uploadFile(any());
    }

    @Test
    void testWriteIngestionErrorAndUpload() {
        IngestionRequest request = buildIngestionRequest();
        request.setRequestId(UUID.randomUUID());
        when(fileStorageService.uploadFile(fileUploadRequestArgCaptor.capture())).thenReturn(Flux.just(
                new FileUploadResponse("fileId1", "test_source_ERROR.xlsx")));

        var publisher = postIngestionService.writeIngestionErrorAndUpload(request);
        assertNotNull(publisher);

        StepVerifier.create(publisher)
                .assertNext(uploadResponse -> {
                    assertNotNull(uploadResponse);
                    assertEquals("fileId1", uploadResponse.getFileId());
                    assertEquals("test_source_ERROR.xlsx", uploadResponse.getFileName());
                }).verifyComplete();

        verify(fileStorageService, times(1)).uploadFile(any());
        FileUploadRequest o = fileUploadRequestArgCaptor.getValue();
        assertNotNull(o);
        assertEquals("test_source_ERROR.xlsx", o.getFileName());
        assertTrue(o.getFileContent().length > 2000);
        assertEquals("xlsx", o.getFileExtension());
    }

}
