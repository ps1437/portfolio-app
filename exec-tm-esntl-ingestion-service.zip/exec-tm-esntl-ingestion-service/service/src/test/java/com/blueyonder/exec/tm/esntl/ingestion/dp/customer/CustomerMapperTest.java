/*
 * Copyright © 2022, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.customer;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;

import com.blueyonder.plat.dp.bydm.CommunicationChannelType;
import com.blueyonder.plat.dp.bydm.FinancialDetails;
import com.blueyonder.plat.dp.bydm.GeographicalCoordinatesType;
import com.blueyonder.plat.dp.bydm.PartyContactType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class CustomerMapperTest {

    private static CustomerEntity randomCustomer;

    private final CustomerMapper customerMapper = Mappers.getMapper(CustomerMapper.class);

    @BeforeAll
    public static void buildCustomerEntity() {
        ((Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api")).setLevel(Level.OFF);
        PodamFactory factory = new PodamFactoryImpl();
        randomCustomer = factory.manufacturePojo(CustomerEntity.class);
    }

    @Test
    void testMapCommunicationChannel() {
        List<PartyContactType> contactTypes = customerMapper.mapCommunicationChannel(randomCustomer);
        assertNotNull(contactTypes);
        List<CommunicationChannelType> communicationChannelTypes = contactTypes.get(0).getCommunicationChannel();
        assertEquals(randomCustomer.getEmail(), communicationChannelTypes.get(0).getCommunicationValue());
        assertEquals(randomCustomer.getWebsite(), communicationChannelTypes.get(1).getCommunicationValue());
        assertEquals(randomCustomer.getTelephone(), communicationChannelTypes.get(2).getCommunicationValue());
        assertEquals(randomCustomer.getTelefax(), communicationChannelTypes.get(3).getCommunicationValue());
        assertEquals(randomCustomer.getPersonName(), contactTypes.get(0).getPersonName());
    }

    @Test
    void testMapGeographicalCoordinates() {
        assertNull(customerMapper.mapToGeographicalCoordinates(new CustomerEntity()));
        GeographicalCoordinatesType geographicalCoordinatesType = customerMapper.mapToGeographicalCoordinates(randomCustomer);
        assertNotNull(geographicalCoordinatesType);
        assertEquals(randomCustomer.getLatitude(), geographicalCoordinatesType.getLatitude());
        assertEquals(randomCustomer.getLongitude(), geographicalCoordinatesType.getLongitude());
    }

    @Test
    void testMapToFinancialInformation() {
        FinancialDetails financialInformation = customerMapper.mapToFinancialInformation(randomCustomer);
        assertNotNull(financialInformation);
        assertEquals(randomCustomer.getDefaultBillToCustomerCode(), financialInformation.getBillTo().getPrimaryId());
    }

    @Test
    void testMapToFinancialInformationWithEmptyBillToInformation() {
        FinancialDetails financialInformation = customerMapper.mapToFinancialInformation(new CustomerEntity());
        assertNull(financialInformation);
    }
}
