package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FreightTermsTest {

    @Test
    void checkAllValues() {
        assertEquals("PP", FreightTerms.PREPAID.value());
        assertEquals("CC", FreightTerms.COLLECT.value());
    }

    @Test
    void testFromValue() {
        assertEquals("PP", FreightTerms.fromValue("PREPAID").value());
    }

    @Test
    void testFromValueException() {
        try {
            FreightTerms.fromValue("test");
        }
        catch (Exception exception) {
            assertTrue(exception instanceof IllegalArgumentException);
        }
    }

}
