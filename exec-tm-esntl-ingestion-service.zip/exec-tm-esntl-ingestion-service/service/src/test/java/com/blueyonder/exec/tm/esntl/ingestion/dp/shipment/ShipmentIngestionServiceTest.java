/*
 * Copyright © 2021, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.dp.shipment;

import reactor.core.publisher.Mono;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.blueyonder.exec.ecom.boot.commons.core.utils.JsonUtils;
import com.blueyonder.exec.tm.esntl.ingestion.TestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.commons.config.IngestionConfigProperties;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpClient;
import com.blueyonder.exec.tm.esntl.ingestion.dp.DpTestUtils;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.DataStorageService;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.PostIngestionService;
import com.blueyonder.plat.dp.api.client.v1.ShipmentDpClient;
import com.blueyonder.plat.dp.api.model.v1.IngestionQueryResponseModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

@ExtendWith(MockitoExtension.class)
class ShipmentIngestionServiceTest {

    private final ShipmentIngestionService ingestionService;

    private final DpClient dpClient;

    private final DataStorageService dataStorageService;

    private final IngestionConfigProperties ingestionConfigProperties;

    ShipmentIngestionServiceTest() {
        this.dpClient = mock(DpClient.class);
        ShipmentDpClient shipmentDpClient = mock(ShipmentDpClient.class, withSettings().stubOnly());
        this.dataStorageService = mock(DataStorageService.class);
        PostIngestionService postIngestionService = mock(PostIngestionService.class);
        ShipmentMapper shipmentMapper = new ShipmentMapper(JsonUtils.objectMapper());
        ShipmentLocationDnfService shipmentLocationDnfService = mock(ShipmentLocationDnfService.class);
        ShipmentPartyDnfService shipmentPartyDnfService = mock(ShipmentPartyDnfService.class);
        this.ingestionConfigProperties = mock(IngestionConfigProperties.class);
        this.ingestionService = new ShipmentIngestionService(
                dpClient, shipmentDpClient, dataStorageService, postIngestionService,
                shipmentMapper, shipmentLocationDnfService, shipmentPartyDnfService, ingestionConfigProperties);
    }

    @Test
    void testGetType() {
        assertEquals(IngestionType.SHIPMENT, ingestionService.getType());
        assertNotNull(ingestionService.getEntitySchema().getEntityDef("Shipment"));
    }

    @Test
    void testFileBasedIngest() {
        var dataIngestionDetails = DpTestUtils.buildDataIngestionDetails();
        when(dataStorageService.saveFileDetails(any(String.class), any(String.class))).thenReturn(dataIngestionDetails);
        when(dpClient.ingest(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
        IngestionConfigProperties.BatchConfig batchConfig = new IngestionConfigProperties.BatchConfig();
        batchConfig.setBatchSize(25);
        when(ingestionConfigProperties.getBatchConfig()).thenReturn(batchConfig);

        ingestionService.ingest(TestUtils.buildIngestionRequest(ingestionService, "Shipment.xlsx"));
        verify(dpClient, times(1)).ingest(any(), anyList());
    }

    //    @Test
    //    void testShipmentProcessDpIngest() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(buildShipmentJsonNode());
    //        when(dpClient.ingestToDpAsJsonNode(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetForShipment(true));
    //
    //            DataIngestionDetails dataIngestionResponse = shipmentIngestionService.process(TestUtils.mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(dpClient, times(1)).ingestToDpAsJsonNode(any(), any());
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessDpIngestError() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(buildShipmentJsonNode());
    //        when(dpClient.ingestToDpAsJsonNode(any(), any())).thenReturn(Mono.error(new RuntimeException("Something went wrong")));
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetForShipment(true));
    //
    //            DataIngestionDetails dataIngestionResponse = shipmentIngestionService.process(TestUtils.mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            verify(dataStorageService, times(1)).updateErrorFileDetails(anyString(), anyString(), anyInt());
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessEmptyValidEntities() throws IOException {
    //        DataIngestionDetails dataIngestionDetails = TestUtils.buildDataIngestionDetails();
    //        when(dataStorageService.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        when(dpClient.ingestToDpAsJsonNode(any(), any())).thenReturn(Mono.just(mock(IngestionQueryResponseModel.class)));
    //        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(buildShipmentJsonNode());
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(TestUtils.buildDomainResultSetForShipment(true));
    //
    //            DataIngestionDetails dataIngestionResponse = shipmentIngestionService.process(TestUtils.mockMultiPartReq());
    //
    //            assertNotNull(dataIngestionResponse);
    //            assertEquals(dataIngestionDetails.getId(), dataIngestionResponse.getId());
    //            assertEquals(dataIngestionDetails.getStatus(), dataIngestionResponse.getStatus());
    //            verify(postIngestionService, times(1)).processIngestion(any());
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessWithEmptyDomainSet() {
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(new HashMap<>());
    //
    //            assertThrows(ResponseErrorMarkerException.class, () -> shipmentIngestionService.process(TestUtils.mockMultiPartReq()));
    //        }
    //    }

    //    @Test
    //    void testShipmentProcessWithEmptyEntities() {
    //        try (MockedStatic<ExcelDataReader> mockedStatic = mockStatic(ExcelDataReader.class)) {
    //            Map<DomainType, IngestionRequestPage> resultSetMap = new HashMap<>();
    //            IngestionRequestPage ingestionRequestPage = new IngestionRequestPage();
    //            ingestionRequestPage.setDomainType(DomainType.SHIPMENT);
    //            ingestionRequestPage.setEntities(List.of());
    //            resultSetMap.put(DomainType.SHIPMENT, ingestionRequestPage);
    //
    //            mockedStatic.when(() -> ExcelDataReader.buildIngestionRest(any(), anyList())).thenReturn(new HashMap<>());
    //
    //            assertThrows(ResponseErrorMarkerException.class, () -> shipmentIngestionService.process(TestUtils.mockMultiPartReq()));
    //        }
    //    }

    // OLD COMMENTED CODE...

    //
    //    @Test
    //    void testWhenNoLocationIdsProvided() throws IOException {
    //
    //        IngestionResponseModel ingestionResponseModel = new IngestionResponseModel();
    //        ingestionResponseModel.setIngestionId("ingestionId");
    //
    //        when(shipmentDpClient.ingest(any(JsonNode.class))).thenReturn(Mono.just(ingestionResponseModel));
    //        when(excelDataReader.processFile(any(), anyList())).thenReturn(createDomainResultSetMap(true, false));
    //        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(buildShipmentJsonNode());
    //        when(commonUtils.getDPIngestionStatus(any())).thenReturn(Mono.just(TestUtils.buildIngestionQueryResponseModel()));
    //
    //        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
    //        dataIngestionDetails.setStatus("PROCESSING");
    //        dataIngestionDetails.setId("ingestionId");
    //        when(commonUtils.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        MultipartFile multipartfile = TestUtils.buildMultiPartRequest("/Shipment_withoutLocation.xlsx", "Shipment_withoutLocation.xlsx", "Shipment_withoutLocation.xlsx");
    //
    //        DataIngestionDetails dataIngestionDetails1 = shipmentIngestionService.process(multipartfile);
    //
    //        assertEquals(dataIngestionDetails, dataIngestionDetails1);
    //        verify(commonUtils).saveFileDetails(fileNameCapture.capture(), entityTypeCapture.capture());
    //        assertEquals("Shipment_withoutLocation.xlsx", fileNameCapture.getValue());
    //        assertEquals("Shipment", entityTypeCapture.getValue());
    //        verify(commonUtils, times(1)).saveFileDetails(fileNameCapture.getValue(), entityTypeCapture.getValue());
    //        verify(objectMapper, times(1)).convertValue(any(), eq(JsonNode.class));
    //        verify(shipmentDpClient, times(1)).ingest(any(JsonNode.class));
    //    }
    //
    //    @Test
    //    void testWhenExceptionEncounteredWhileIngestingData() throws IOException {
    //
    //        IngestionResponseModel ingestionResponseModel = new IngestionResponseModel();
    //        ingestionResponseModel.setIngestionId("ingestionId");
    //
    //        when(shipmentDpClient.ingest(any(JsonNode.class))).thenReturn(Mono.just(ingestionResponseModel));
    //        when(excelDataReader.processFile(any(), anyList())).thenReturn(createDomainResultSetMap(true, false));
    //        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(buildShipmentJsonNode());
    //        when(commonUtils.getDPIngestionStatus(any())).thenReturn(Mono.error(RuntimeException::new));
    //
    //        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
    //        dataIngestionDetails.setStatus("PROCESSING");
    //        dataIngestionDetails.setId("ingestionId");
    //        when(commonUtils.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //        MultipartFile multipartfile = TestUtils.buildMultiPartRequest("/Shipment_withoutLocation.xlsx", "Shipment_withoutLocation.xlsx", "Shipment_withoutLocation.xlsx");
    //
    //        DataIngestionDetails dataIngestionDetails1 = shipmentIngestionService.process(multipartfile);
    //
    //        assertEquals(dataIngestionDetails, dataIngestionDetails1);
    //        verify(commonUtils).saveFileDetails(fileNameCapture.capture(), entityTypeCapture.capture());
    //        assertEquals("Shipment_withoutLocation.xlsx", fileNameCapture.getValue());
    //        assertEquals("Shipment", entityTypeCapture.getValue());
    //        verify(commonUtils, times(1)).saveFileDetails(fileNameCapture.getValue(), entityTypeCapture.getValue());
    //        verify(objectMapper, times(1)).convertValue(any(), eq(JsonNode.class));
    //        verify(shipmentDpClient, times(1)).ingest(any(JsonNode.class));
    //        verify(commonUtils, times(1)).updateFileDetails(anyString(), anyString(), anyInt());
    //    }
    //
    //    @Test
    //    void testShipmentProcessWithNoLogisticUnit() throws IOException {
    //        IngestionResponseModel ingestionResponseModel = new IngestionResponseModel();
    //        ingestionResponseModel.setIngestionId("ingestionId");
    //
    //        when(locationService.queryLocation(any())).thenReturn(Mono.just(List.of(buildLocationType("location1"))));
    //        when(shipmentDpClient.ingest(any(JsonNode.class))).thenReturn(Mono.just(ingestionResponseModel));
    //        when(excelDataReader.processFile(any(), anyList())).thenReturn(createDomainResultSetMap(false));
    //        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(buildShipmentJsonNode());
    //        when(commonUtils.getDPIngestionStatus(any())).thenReturn(Mono.just(TestUtils.buildIngestionQueryResponseModel()));
    //
    //        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
    //        dataIngestionDetails.setStatus("PROCESSING");
    //        dataIngestionDetails.setId("ingestionId");
    //        when(commonUtils.saveFileDetails(any(), any())).thenReturn(dataIngestionDetails);
    //
    //        MultipartFile multipartfile = TestUtils.buildMultiPartRequest("/Shipment.xlsx", "Shipment.xlsx", "Shipment.xlsx");
    //
    //        shipmentIngestionService.process(multipartfile);
    //
    //        verify(commonUtils).saveFileDetails(fileNameCapture.capture(), entityTypeCapture.capture());
    //        assertEquals("Shipment.xlsx", fileNameCapture.getValue());
    //        assertEquals("Shipment", entityTypeCapture.getValue());
    //        verify(commonUtils, times(1)).saveFileDetails(fileNameCapture.getValue(), entityTypeCapture.getValue());
    //    }
    //
    //    @Test
    //    void testGetDomainTypeWithData() {
    //        List<Object[]> shipmentObjects = new ArrayList<>();
    //        shipmentObjects.add(new Object[] { "ship1", "ship2" });
    //        List<Object[]> logisticUnitObjects = new ArrayList<>();
    //        logisticUnitObjects.add(new Object[] { "logis1", "logis2" });
    //
    //        Map<String, List<Object[]>> domainsList = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "getDomainTypeWithData", shipmentObjects, logisticUnitObjects);
    //
    //        assertEquals(2, domainsList.keySet().size());
    //        assertTrue(domainsList.keySet().contains(DomainType.SHIPMENT.getType()));
    //        assertTrue(domainsList.keySet().contains(DomainType.SHIPMENT_LOGISTICS_UNIT.getType()));
    //    }
    //
    //    @Test
    //    void testRetrieveLogisticUnitRecords() {
    //        DomainResultSet domainTypeResultSet = buildDomainResultSetMapForShipment().get(DomainType.SHIPMENT_LOGISTICS_UNIT);
    //
    //        List<ShipmentLogisticUnit> logisticUnits = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "convertResultSetToLogisticUnit", domainTypeResultSet);
    //
    //        assertNotNull(logisticUnits);
    //        assertTrue(logisticUnits.size() > 0);
    //        assertNotNull(logisticUnits.get(0));
    //        assertEquals(0, logisticUnits.get(0).getRowNumber());
    //    }
    //
    //    @Test
    //    void testRetrieveShipmentRecords() {
    //        DomainResultSet domainTypeResultSet = buildDomainResultSetMapForShipment().get(DomainType.SHIPMENT);
    //
    //        List<Shipment> shipments = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "convertResultSetToShipment", domainTypeResultSet);
    //
    //        assertNotNull(shipments);
    //        assertTrue(shipments.size() > 0);
    //        assertNotNull(shipments.get(0));
    //        assertEquals(0, shipments.get(0).getRowNumber());
    //    }
    //
    //    @Test
    //    void testRetrieveValidShipmentRecords() {
    //        DomainResultSet domainTypeResultSet = buildDomainResultSetMapForShipment().get(DomainType.SHIPMENT);
    //        ErrorMessagesForRow errorMessagesForRow = new ErrorMessagesForRow();
    //        errorMessagesForRow.setRowNumber(1);
    //        errorMessagesForRow.setErrors(List.of("ExceptionMsg1", "ExceptionMsg2"));
    //        domainTypeResultSet.setErrors(List.of(errorMessagesForRow));
    //        List<Shipment> shipments = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "convertResultSetToShipment", domainTypeResultSet);
    //        List<ParentEntity> shipmentWithEmptyLocations = shipments.stream().map(record -> {
    //            record.setDestinationCity(null);
    //            record.setOriginCity(null);
    //            return record;
    //        }).toList();
    //
    //        List<String> invalidLogisticUnitSNos = new ArrayList<>();
    //
    //        List<Shipment> shipmentsList = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "filterShipmentRecordsWithoutErrors", domainTypeResultSet, shipmentWithEmptyLocations, invalidLogisticUnitSNos);
    //
    //        assertNotNull(shipmentsList);
    //        assertTrue(shipmentsList.size() > 0);
    //    }
    //
    //    @Test
    //    void testShipmentProcessWithNoRecords() throws IOException {
    //        IngestionResponseModel ingestionResponseModel = new IngestionResponseModel();
    //        ingestionResponseModel.setIngestionId("ingestionId");
    //
    //        when(excelDataReader.processFile(any(), anyList())).thenReturn(new HashMap<>());
    //        DataIngestionDetails dataIngestionDetails = new DataIngestionDetails();
    //        dataIngestionDetails.setStatus("PROCESSING");
    //        dataIngestionDetails.setId("ingestionId");
    //        MultipartFile multipartfile = TestUtils.buildMultiPartRequest("/Shipment_Empty.xlsx", "Shipment_Empty.xlsx", "Shipment_Empty.xlsx");
    //
    //        Assertions.assertThrows(BusinessException.class, () -> shipmentIngestionService.process(multipartfile));
    //    }
    //
    //    @Test
    //    void testFilterInValidLogisticUnitRecord() {
    //        PodamFactory factory = new PodamFactoryImpl();
    //        DomainResultSet resultSet = factory.manufacturePojo(DomainResultSet.class);
    //        ShipmentLogisticUnit logisticUnit = factory.manufacturePojo(ShipmentLogisticUnit.class);
    //
    //        boolean isValid1 = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "filterInValidLogisticUnitRecord", logisticUnit, resultSet);
    //        logisticUnit.setRowNumber(resultSet.getErrors().get(0).getRowNumber());
    //        boolean isValid2 = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "filterInValidLogisticUnitRecord", logisticUnit, resultSet);
    //
    //        assertFalse(isValid1);
    //        assertTrue(isValid2);
    //    }
    //
    //    @Test
    //    void testRetrieveValidLogisticUnitRecords() {
    //        PodamFactory factory = new PodamFactoryImpl();
    //        ShipmentLogisticUnit logisticUnit1 = factory.manufacturePojo(ShipmentLogisticUnit.class);
    //        ShipmentLogisticUnit logisticUnit2 = factory.manufacturePojo(ShipmentLogisticUnit.class);
    //        List<ParentEntity> logisticUnits = List.of(logisticUnit1, logisticUnit2);
    //        List<String> invalidLogisticUnitSNos = List.of(String.valueOf(logisticUnit1.getSerialNumber()));
    //
    //        List<ShipmentLogisticUnit> validLogisticUnits = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "retrieveValidLogisticUnitRecords", logisticUnits, invalidLogisticUnitSNos);
    //        assertNotNull(validLogisticUnits);
    //        assertEquals(validLogisticUnits.get(0).getSerialNumber(), logisticUnit2.getSerialNumber());
    //    }
    //
    //    @Test
    //    void testGetAddressLocationIds() {
    //        Shipment shipment = buildShipment();
    //        List<String> locationIds = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "retrieveLocationIdsFromShipment", List.of(shipment));
    //        assertTrue(locationIds.size() > 0);
    //
    //        shipment.setOriginLocation(null);
    //        shipment.setDestinationLocation(null);
    //        List<String> locationIdsEmpty = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "retrieveLocationIdsFromShipment", List.of(shipment));
    //        assertEquals(0, locationIdsEmpty.size());
    //    }
    //
    //    @Test
    //    void mapShipmentAddressAndSetLogisticUnitsList() {
    //        Shipment shipment = buildShipment();
    //        shipment.setPrimaryId(null);
    //        Map<String, LocationType> locationTypeMap = new HashMap<>();
    //        locationTypeMap.put("loc1", buildLocationType("loc1"));
    //        locationTypeMap.put("loc2", buildLocationType("loc2"));
    //        Map<String, List<ShipmentLogisticUnit>> logisticUnitsMap = new HashMap<>();
    //        logisticUnitsMap.put("1", List.of(buildLogisticUnit("1")));
    //
    //        ReflectionTestUtils.invokeMethod(shipmentIngestionService, "mapShipmentAddressAndSetLogisticUnitsList",
    //                shipment, locationTypeMap, logisticUnitsMap, new ArrayList<ErrorMessagesForRow>());
    //        assertNotNull(shipment.getPrimaryId());
    //        assertEquals(1, shipment.getLogisticUnitsList().size());
    //        verify(shipmentAddressMapper).mapShipmentAddressAndGetErrors(any(), anyMap(), anyList());
    //    }
    //
    //    @Test
    //    void setLogisticUnitsAndMapToShipmentType() {
    //        Shipment shipment = buildShipment();
    //        Map<String, LocationType> locationTypeMap = new HashMap<>();
    //        locationTypeMap.put("loc1", buildLocationType("loc1"));
    //        locationTypeMap.put("loc2", buildLocationType("loc2"));
    //        Map<Integer, List<ShipmentLogisticUnit>> logisticUnitsMap = new HashMap<>();
    //        logisticUnitsMap.put(1, List.of(buildLogisticUnit("1")));
    //
    //        List shipmentRecords = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "setLogisticUnitsAndLocationAndMapToShipmentType",
    //                List.of(shipment), locationTypeMap, logisticUnitsMap, new ArrayList<ErrorMessagesForRow>());
    //
    //        assertNotNull(shipmentRecords);
    //        verify(shipmentAddressMapper).mapShipmentAddressAndGetErrors(any(), anyMap(), anyList());
    //        verify(shipmentMapper, times(1)).mapToShipmentForCreate(any(Shipment.class));
    //        assertTrue(shipmentRecords.size() > 0);
    //
    //        List shipmentRecords1 = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "setLogisticUnitsAndLocationAndMapToShipmentType",
    //                new ArrayList<>(), locationTypeMap, logisticUnitsMap, new ArrayList<ErrorMessagesForRow>());
    //        assertTrue(shipmentRecords1.isEmpty());
    //    }
    //
    //    @Test
    //    void setLogisticUnitsAndMapToShipmentTypeWithEmptyRecords() {
    //        List shipmentRecords = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "setLogisticUnitsAndLocationAndMapToShipmentType",
    //                new ArrayList<>(), new HashMap<>(), new HashMap<>(), new ArrayList<ErrorMessagesForRow>());
    //        assertTrue(shipmentRecords.isEmpty());
    //    }
    //
    //    @Test
    //    void ifShipmentRecordHasNoErrors() {
    //        Shipment shipment = buildShipment();
    //        DomainResultSet shipmentResultSet = buildDomainResultSetMapForShipment().get(DomainType.SHIPMENT);
    //        shipmentResultSet.setErrors(new ArrayList<>());
    //        List<String> invalidLogisticUnitSNos = List.of(String.valueOf(shipment.getSerialNumber()));
    //        int errorSize = shipmentResultSet.getErrors().size();
    //
    //        boolean status1 = ReflectionTestUtils.invokeMethod(shipmentIngestionService, "ifShipmentRecordHasNoErrors", shipment, shipmentResultSet, invalidLogisticUnitSNos);
    //        assertFalse(status1);
    //        assertTrue(shipmentResultSet.getErrors().size() > errorSize);
    //        assertNotNull(shipmentResultSet.getErrors().get(0));
    //        assertTrue(shipmentResultSet.getErrors().get(0).getErrors().size() > 0);
    //        assertEquals(shipmentResultSet.getErrors().get(0).getRowNumber(), shipment.getRowNumber());
    //    }

    public JsonNode buildShipmentJsonNode() throws JsonProcessingException {
        return new ObjectMapper().readTree("{\"shipmentId\":\"shipmentId\"}");
    }
}
