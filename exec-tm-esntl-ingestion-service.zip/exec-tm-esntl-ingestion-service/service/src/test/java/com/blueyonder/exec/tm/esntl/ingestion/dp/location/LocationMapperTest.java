package com.blueyonder.exec.tm.esntl.ingestion.dp.location;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import com.blueyonder.plat.dp.bydm.CommunicationChannelCode;
import com.blueyonder.plat.dp.bydm.DayOfTheWeekEnumerationType;
import com.blueyonder.plat.dp.bydm.LocationAddressType;
import com.blueyonder.plat.dp.bydm.LocationContactType;
import com.blueyonder.plat.dp.bydm.LocationType;
import com.blueyonder.plat.dp.bydm.OperatingHours;

import static com.blueyonder.exec.tm.esntl.ingestion.TestUtils.PODAM_FACTORY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LocationMapperTest {

    private static final String OPENING_TIME_9 = "09:00:00";
    private static final String CLOSING_TIME_5 = "17:00:00";
    private final LocationMapper mapper = Mappers.getMapper(LocationMapper.class);

    @Test
    void testMapBasicLocationAddress() {
        LocationEntity location = PODAM_FACTORY.manufacturePojo(LocationEntity.class);

        LocationType locationType = mapper.mapToLocationType(location);

        assertNotNull(locationType);
        LocationAddressType address = locationType.getBasicLocation().getAddress();
        assertEquals(location.getCountryCode(), address.getCountryCode());
        assertEquals(location.getState(), address.getState());
        assertEquals(location.getCity(), address.getCity());
        assertEquals(location.getStreetAddressOne(), address.getStreetAddressOne());
        assertEquals(location.getStreetAddressTwo(), address.getStreetAddressTwo());
        assertEquals(location.getStreetAddressThree(), address.getStreetAddressThree());
        assertEquals(location.getPostalCode(), address.getPostalCode());

        assertNotNull(address.getGeographicalCoordinates());
        assertEquals(location.getLatitude(), address.getGeographicalCoordinates().getLatitude());
        assertEquals(location.getLongitude(), address.getGeographicalCoordinates().getLongitude());
        verifyEquipmentDetailsForLocation(location, locationType);
    }

    private void verifyEquipmentDetailsForLocation(LocationEntity location, LocationType locationType) {
        assertEquals(location.getFixedLoadingTimeHrs(), locationType.getLogisticDetails().getFixedLoadingDurationInHours());
        assertEquals(location.getMinVariableLoadingTimeHrs(), locationType.getLogisticDetails().getMinimumVariableLoadingDurationInHours());
        assertEquals(location.getMaxVariableLoadingTimeHrs(), locationType.getLogisticDetails().getMaximumVariableLoadingDurationInHours());
        assertEquals(location.getEquipmentRestrictions().get(0).getEquipmentRestrictionCode().toString(), locationType.getLogisticDetails().getTransportEquipmentRestriction().get(0).getRestrictionCode().value());
        assertEquals(location.getEquipmentRestrictions().get(0).getEquipmentType(), locationType.getLogisticDetails().getTransportEquipmentRestriction().get(0).getTransportEquipmentTypeCode());
    }

    @Test
    void testEquipmentDetailsForLocationIfNull() {
        LocationEntity location = PODAM_FACTORY.manufacturePojo(LocationEntity.class);
        location.setFixedLoadingTimeHrs(null);
        location.setMaxVariableLoadingTimeHrs(null);
        location.setMinVariableLoadingTimeHrs(null);

        LocationType locationType = mapper.mapToLocationType(location);

        assertNull(locationType.getLogisticDetails().getFixedLoadingDurationInHours());
        assertNull(locationType.getLogisticDetails().getMinimumVariableLoadingDurationInHours());
        assertNull(locationType.getLogisticDetails().getMaximumVariableLoadingDurationInHours());
        assertEquals(location.getEquipmentRestrictions().get(0).getEquipmentRestrictionCode().toString(), locationType.getLogisticDetails().getTransportEquipmentRestriction().get(0).getRestrictionCode().value());
        assertEquals(location.getEquipmentRestrictions().get(0).getEquipmentType(), locationType.getLogisticDetails().getTransportEquipmentRestriction().get(0).getTransportEquipmentTypeCode());
    }

    @Test
    void testMapCommunicationChannel() {
        PodamFactory factory = new PodamFactoryImpl();
        LocationEntity location = factory.manufacturePojo(LocationEntity.class);

        List<LocationContactType> contacts = mapper.mapCommunicationChannel(location);

        assertNotNull(contacts);
        assertEquals(4, contacts.get(0).getCommunicationChannel().size());
        assertEquals(location.getEmail(), contacts.get(0).getCommunicationChannel().get(0).getCommunicationValue());
        assertEquals(CommunicationChannelCode.EMAIL, contacts.get(0).getCommunicationChannel().get(0).getCommunicationChannelCode());
        assertEquals(contacts.get(0).getPersonName(), location.getPersonName());
    }

    @Test
    void testMapOperationalHoursforWeekdays() {
        OperatingHours operationalHours = mapper.mapOperationalHours(OperationalHours.OPERATIONAL_WEEKDAYS);

        assertNotNull(operationalHours);
        assertEquals(5, operationalHours.getRegularOperatingHours().size());
    }

    @Test
    void testMapOperationalHoursforAlldays() {
        OperatingHours operationalHours = mapper.mapOperationalHours(OperationalHours.OPERATIONAL_ALL_DAYS);

        assertNotNull(operationalHours);
        assertEquals(7, operationalHours.getRegularOperatingHours().size());
    }

    @Test
    void testMapOperationalHoursForAllDays9to5() {
        OperatingHours operationalHours = mapper.mapOperationalHours(OperationalHours.OPERATIONAL_ALL_DAYS_9_TO_5);

        assertNotNull(operationalHours);
        assertEquals(7, operationalHours.getRegularOperatingHours().size());
        assertTrue(operationalHours.getRegularOperatingHours().get(0).getIsOperational());
        assertEquals(DayOfTheWeekEnumerationType.FRIDAY, operationalHours.getRegularOperatingHours().get(0).getDayOfTheWeekCode());
        assertEquals(OPENING_TIME_9, operationalHours.getRegularOperatingHours().get(0).getOpeningTime());
        assertEquals(CLOSING_TIME_5, operationalHours.getRegularOperatingHours().get(0).getClosingTime());
    }

    @Test
    void testMapOperationalHoursForWeekdays9to5() {
        OperatingHours operationalHours = mapper.mapOperationalHours(OperationalHours.OPERATIONAL_WEEKDAYS_9_TO_5);

        assertNotNull(operationalHours);
        assertEquals(5, operationalHours.getRegularOperatingHours().size());
        assertEquals(OPENING_TIME_9, operationalHours.getRegularOperatingHours().get(0).getOpeningTime());
        assertEquals(CLOSING_TIME_5, operationalHours.getRegularOperatingHours().get(0).getClosingTime());
    }
}
