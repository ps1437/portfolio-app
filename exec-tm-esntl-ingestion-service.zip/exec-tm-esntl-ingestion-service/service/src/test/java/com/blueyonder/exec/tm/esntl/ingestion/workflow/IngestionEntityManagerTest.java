/*
 * Copyright © 2023, Blue Yonder Group, Inc. ALL RIGHTS RESERVED.
 * This software is the confidential information of Blue Yonder Group, Inc.,
 * and is licensed as restricted rights software. The use, reproduction, or
 * disclosure of this software is subject to restrictions set forth in your
 * license agreement with Blue Yonder.
 */

package com.blueyonder.exec.tm.esntl.ingestion.workflow;

import java.util.Collections;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.blueyonder.exec.ecom.boot.commons.web.error.ConflictAppException;
import com.blueyonder.exec.ecom.boot.commons.web.error.NotFoundAppException;
import com.blueyonder.exec.tm.esntl.ingestion.commons.IngestionType;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.FileUploadResponse;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionErrorEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionRequestStatusEntity;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.domain.IngestionStatus;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionErrorRepository;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionRequestRepository;
import com.blueyonder.exec.tm.esntl.ingestion.workflow.repository.IngestionRequestStatusRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DisplayName("Ingestion EntityManager Tests")
@ExtendWith(MockitoExtension.class)
class IngestionEntityManagerTest {

    @Mock
    private IngestionRequestRepository ingestionRequestRepository;

    @Mock
    private IngestionRequestStatusRepository ingestionRequestStatusRepository;

    @Mock
    private IngestionErrorRepository ingestionErrorRepository;

    @InjectMocks
    private IngestionEntityManager ingestionEntityManager;

    @Captor
    private ArgumentCaptor<IngestionRequestStatusEntity> ingestionStatusArgumentCaptor;

    @Captor
    private ArgumentCaptor<IngestionErrorEntity> ingestionErrorEntityArgumentCaptor;

    private static final String CARRIER_FILE_ID = "63cec1337b2d4bdd168c408c";

    private static final String CARRIER_FILE_NAME = "Carrier.xlsx";

    @DisplayName("create successful ingestion")
    @Test
    void testCreateIngestionSuccess() {
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        IngestionRequestStatusEntity expectedIngestionRequestStatusEntity = ingestionEntityManager.buildIngestionRequestStatus(expectedIngestionRequestEntity, IngestionStatus.QUEUED, 0, 0);
        expectedIngestionRequestEntity.setRequestId(UUID.randomUUID());
        when(ingestionRequestRepository.findByFileId(any())).thenReturn(Optional.empty());
        when(ingestionRequestRepository.save(any())).thenReturn(expectedIngestionRequestEntity);
        when(ingestionRequestStatusRepository.save(any())).thenReturn(expectedIngestionRequestStatusEntity);
        IngestionRequestEntity actualIngestionRequestEntity = ingestionEntityManager.createIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);

        assertEquals(expectedIngestionRequestEntity.getFileId(), actualIngestionRequestEntity.getFileId());
        assertEquals(expectedIngestionRequestEntity.getFileName(), actualIngestionRequestEntity.getFileName());
        assertNotNull(actualIngestionRequestEntity.getFileId());
        assertNotNull(actualIngestionRequestEntity.getFileName());
        assertNotNull(actualIngestionRequestEntity.getEntityType());

        verify(ingestionRequestStatusRepository).save(ingestionStatusArgumentCaptor.capture());
        IngestionRequestStatusEntity actualIngestionRequestStatusEntity = ingestionStatusArgumentCaptor.getValue();

        assertEquals(expectedIngestionRequestStatusEntity.getStatus(), actualIngestionRequestStatusEntity.getStatus());
        assertNotNull(actualIngestionRequestStatusEntity.getRequestId());
        assertNotNull(actualIngestionRequestStatusEntity.getStatus());
    }

    @DisplayName("failed to create ingestion as there is already a record with the provided fileId")
    @Test
    void testCreateIngestionFailure() {
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        expectedIngestionRequestEntity.setRequestId(UUID.randomUUID());

        when(ingestionRequestRepository.findByFileId(any())).thenReturn(Optional.of(expectedIngestionRequestEntity));

        assertThrows(ConflictAppException.class, () -> ingestionEntityManager.createIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME));
    }

    @DisplayName("get all ingestion requests created")
    @Test
    void testGetIngestions() {
        when(ingestionRequestRepository.findAll(any(Pageable.class))).thenReturn(Page.empty());

        Page<IngestionRequestEntity> page = ingestionEntityManager.getIngestionRequests(Pageable.ofSize(1));

        assertEquals(1, page.getTotalPages());
        assertFalse(page.hasContent());
    }

    @DisplayName("get an ingestion request successfully by id")
    @Test
    void testGetIngestion() {
        UUID uuid = UUID.randomUUID();
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        expectedIngestionRequestEntity.setRequestId(uuid);

        when(ingestionRequestRepository.findByRequestId(any())).thenReturn(Optional.of(expectedIngestionRequestEntity));

        IngestionRequestEntity actualIngestionRequestEntity = ingestionEntityManager.getIngestionRequestById(uuid);

        assertEquals(expectedIngestionRequestEntity.getRequestId(), actualIngestionRequestEntity.getRequestId());
    }

    @DisplayName("failed to get an ingestion request as it is not found")
    @Test
    void testGetIngestionFailure() {
        when(ingestionRequestRepository.findByRequestId(any())).thenReturn(Optional.empty());
        UUID uuid = UUID.randomUUID();
        assertThrows(NotFoundAppException.class, () -> ingestionEntityManager.getIngestionRequestById(uuid));
    }

    @DisplayName("get ingestion status successfully by id")
    @Test
    void testGetIngestionStatus() {
        UUID uuid = UUID.randomUUID();
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        IngestionRequestStatusEntity expectedIngestionRequestStatusEntity = ingestionEntityManager.buildIngestionRequestStatus(expectedIngestionRequestEntity, IngestionStatus.COMPLETED_WITH_ERRORS, 100, 90);
        expectedIngestionRequestStatusEntity.setRequestId(uuid);

        when(ingestionRequestStatusRepository.findByRequestId(any(UUID.class))).thenReturn(Optional.of(expectedIngestionRequestStatusEntity));

        IngestionRequestStatusEntity actualIngestionRequestStatusEntity = ingestionEntityManager.getIngestionRequestStatusById(uuid);

        assertEquals(expectedIngestionRequestStatusEntity.getRequestId(), actualIngestionRequestStatusEntity.getRequestId());
    }

    @DisplayName("failed to get ingestion status as it is not found")
    @Test
    void testGetIngestionStatusFailure() {
        when(ingestionRequestStatusRepository.findByRequestId(any(UUID.class))).thenReturn(Optional.empty());
        UUID uuid = UUID.randomUUID();
        assertThrows(NotFoundAppException.class, () -> ingestionEntityManager.getIngestionRequestStatusById(uuid));
    }

    @DisplayName("get all ingestion statuses created")
    @Test
    void testGetIngestionStatuses() {
        when(ingestionRequestStatusRepository.findAll(any(Pageable.class))).thenReturn(Page.empty());

        Page<IngestionRequestStatusEntity> page = ingestionEntityManager.getIngestionRequestStatuses(Pageable.ofSize(1));

        assertEquals(1, page.getTotalPages());
        assertFalse(page.hasContent());
    }

    @DisplayName("get ingestion error successfully by id")
    @Test
    void testGetIngestionError() {
        UUID uuid = UUID.randomUUID();
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        FileUploadResponse fileUploadResponse = new FileUploadResponse(CARRIER_FILE_ID, CARRIER_FILE_NAME);
        IngestionErrorEntity expectedIngestionErrorEntity = ingestionEntityManager.buildIngestionError(expectedIngestionRequestEntity, fileUploadResponse, Collections.emptyList());
        expectedIngestionErrorEntity.setRequestId(uuid);

        when(ingestionErrorRepository.findByRequestId(any(UUID.class))).thenReturn(Optional.of(expectedIngestionErrorEntity));

        IngestionErrorEntity actualIngestionErrorEntity = ingestionEntityManager.getIngestionError(uuid);

        assertEquals(expectedIngestionErrorEntity.getRequestId(), actualIngestionErrorEntity.getRequestId());
    }

    @DisplayName("failed to get ingestion error as it is not found")
    @Test
    void testGetIngestionErrorFailure() {
        when(ingestionErrorRepository.findByRequestId(any(UUID.class))).thenReturn(Optional.empty());
        UUID uuid = UUID.randomUUID();
        assertThrows(NotFoundAppException.class, () -> ingestionEntityManager.getIngestionError(uuid));
    }

    @DisplayName("create ingestion error")
    @Test
    void testCreateIngestionError() {
        UUID uuid = UUID.randomUUID();
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        expectedIngestionRequestEntity.setRequestId(uuid);

        when(ingestionRequestRepository.findByRequestId(any())).thenReturn(Optional.of(expectedIngestionRequestEntity));

        ingestionEntityManager.createIngestionError(UUID.randomUUID(),
                new FileUploadResponse(CARRIER_FILE_ID, CARRIER_FILE_NAME),
                Collections.emptyList());

        verify(ingestionErrorRepository, times(1)).save(ingestionErrorEntityArgumentCaptor.capture());

        var ingestionErrorEntity = ingestionErrorEntityArgumentCaptor.getValue();
        assertNotNull(ingestionErrorEntity.getRequestId());
        assertNotNull(ingestionErrorEntity.getErrorFileId());
        assertNotNull(ingestionErrorEntity.getErrorFileName());
        assertNotNull(ingestionErrorEntity.getErrors());
        assertNotNull(ingestionErrorEntity.getErrorRecordsCount());
    }

    @DisplayName("update ingestion status")
    @Test
    void testUpdateIngestionStatus() {
        UUID uuid = UUID.randomUUID();
        IngestionRequestEntity expectedIngestionRequestEntity = ingestionEntityManager.buildIngestionRequest(IngestionType.CARRIER, CARRIER_FILE_ID, CARRIER_FILE_NAME);
        expectedIngestionRequestEntity.setRequestId(uuid);
        IngestionRequestStatusEntity expectedIngestionRequestStatusEntity = ingestionEntityManager.buildIngestionRequestStatus(expectedIngestionRequestEntity, IngestionStatus.QUEUED, 0, 0);
        expectedIngestionRequestStatusEntity.setRequestId(uuid);

        when(ingestionRequestRepository.findByRequestId(any())).thenReturn(Optional.of(expectedIngestionRequestEntity));
        when(ingestionRequestStatusRepository.findByRequestId(any(UUID.class))).thenReturn(Optional.of(expectedIngestionRequestStatusEntity));

        ingestionEntityManager.updateStatus(uuid, IngestionStatus.PROCESSING, 100, 90);

        verify(ingestionRequestStatusRepository, times(1)).save(ingestionStatusArgumentCaptor.capture());
        assertEquals(IngestionStatus.PROCESSING, ingestionStatusArgumentCaptor.getValue().getStatus());
        assertNotNull(ingestionStatusArgumentCaptor.getValue().getProcessingStartDate());
        assertEquals(100, ingestionStatusArgumentCaptor.getValue().getTotalRecordsCount());
        assertEquals(90, ingestionStatusArgumentCaptor.getValue().getSuccessRecordsCount());

        ingestionEntityManager.updateStatus(uuid, IngestionStatus.COMPLETED, 100, 90);

        verify(ingestionRequestStatusRepository, times(2)).save(ingestionStatusArgumentCaptor.capture());
        assertEquals(IngestionStatus.COMPLETED, ingestionStatusArgumentCaptor.getValue().getStatus());
        assertNotNull(ingestionStatusArgumentCaptor.getValue().getProcessingEndDate());
        assertEquals(100, ingestionStatusArgumentCaptor.getValue().getTotalRecordsCount());
        assertEquals(90, ingestionStatusArgumentCaptor.getValue().getSuccessRecordsCount());

        when(ingestionRequestStatusRepository.findByRequestId(any(UUID.class))).thenReturn(Optional.empty());

        ingestionEntityManager.updateStatus(uuid, IngestionStatus.FAILED, 100, 90);

        verify(ingestionRequestStatusRepository, times(3)).save(ingestionStatusArgumentCaptor.capture());
        assertEquals(100, ingestionStatusArgumentCaptor.getValue().getTotalRecordsCount());
        assertEquals(90, ingestionStatusArgumentCaptor.getValue().getSuccessRecordsCount());
    }

}
